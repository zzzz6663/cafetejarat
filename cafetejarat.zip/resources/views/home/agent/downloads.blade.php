@extends('masters.home')
@section('main_body')
<div class="content-box">
    <div class="main-title">
        <h3>تماس با ما</h3>
        <a href="{{route('login')}}"></a>
    </div>

    <div class="box-content">

        <a class="linky" href="{{route('agent.panel')}}">
            بازگشت
            <img style="width: 20px" src="/home/images/back.png" alt="">
        </a>
        <br>
        <br>
        <br>

        <div class="messages">
            <div class="row">
                @foreach ($downloads as  $download)
                <div class="col-lg-12" style="margin-bottom:20px">
                    <div>
                        <div class="single-design">
                            <img style="width: 100%" src="{{$download->img()}}" alt="">

                            <h4>          {{$download->title}}</h4>

                            @if($download->content)
                            <p>
                                {{$download->content}}
                            </p>
                            @endif
                            <div class="button-container">
                            <a class="green" href="{{$download->file()}}" >دانلود</a>

                            </div>
                        </div>
                    </div>
                </div>

                @endforeach


            </div>


        </div>



    </div>
    {{-- <div class="col-lg-12" style="margin-bottom: 20px">
        <div>
            <div class="button-container">
                <a href="{{route('agent.panel')}}">برگشت</a>
            </div>
        </div>
    </div> --}}
</div>
@endsection
