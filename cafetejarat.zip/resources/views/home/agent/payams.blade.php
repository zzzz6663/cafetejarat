@extends('masters.home')
@section('main_body')
<div class="content-box">
    <div class="main-title">
        <h3>پیامها</h3>
        <a href="{{route('login')}}"></a>
    </div>

    <div class="box-content">


        <div class="profile-top mb20">
            <div class="img">
                <img src="images/user3.png" alt="">
            </div>
            <div class="lefts">
                <h4>مقداد خداداد</h4>
                <span>تولید کننده پوشاک</span>
            </div>
        </div>
        <div class="messages">
            @foreach ($payams as $payam )
            <div class="message {{$payam->pivot->seen ?'':'bold'}}" style="border: none; ">
                <h4 style="display: inline-block; width:80%;">{{$payam->title}} </h4>
                <div  style="display: inline-block; width:20%;" class="button-container">
                  <a style="width: auto;padding:0 10px" href="{{route('agent.single.payams' ,$payam->id)}}">بیشتر</a>
                </div>
            </div>
            @endforeach


        </div>



    </div>
    <div class="col-lg-12" style="margin-bottom: 20px">
        <div>
            <div class="button-container">
               <a href="{{route('agent.panel')}}">برگشت</a>
            </div>
        </div>
    </div>
</div>
@endsection
