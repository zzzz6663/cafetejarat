@extends('masters.home')
@section('main_body')
<div class="content-box">
    <div class="main-title">
        <h3>طرحها</h3>
        <a href="#"></a>
    </div>

    <div class="box-content">


        <div class="profile-top">
            <div class="img">
                <img src="{{$user->avatar()}}" alt="">
            </div>
            <div class="lefts">
                <h4>
                    {{$user->name}}
                    {{$user->family}}
                </h4>
            </div>

            <div class="button-container">
                <a class="green" href="{{route('agent.panel')}}">   برگشت</a>
            </div>
        </div>

     <div class="videos">
        <div class="row">
            @foreach ($cats as  $cat)

            <div class="col-lg-6" style="margin-bottom:20px">
                <div>
                    <div class="single-designs">
                        <div  class="img" style="background: url('') ;">
                            <img src="{{$cat->image()}}" alt="">
                        </div>
                        <h4>          {{$cat->title}}</h4>
                        <div class="button-container">
                            <a class="green" href="{{route('agent.single.vcat',$cat->id)}}">   مشاهده</a>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach

        </div>
     </div>



    </div>
</div>
@endsection
