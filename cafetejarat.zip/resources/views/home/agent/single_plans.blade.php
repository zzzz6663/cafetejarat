@extends('masters.home')
@section('main_body')
<div class="content-box">
    <div class="main-title">
        <h3>طرحها</h3>
        <a href="#"></a>
    </div>

    <div class="box-content">


        <div class="profile-top mb20">
            <div class="img">
                <img src="{{$user->avatar()}}" alt="">
            </div>
            <div class="lefts">
                <h4>
                      {{$user->name}}
                      {{$user->family}}
                  </h4>
                {{-- <span>تولید کننده پوشاک</span> --}}
            </div>
        </div>

        <div class="design-in">

        <div class="design-info">
            <div class="img">
                <img src="images/19.jpg" alt="">
            </div>
            <div class="lefts">
                <h4> {{$plan->name}}

                    <br>
                       {{$plan->ostan->name}}
                       {{$plan->shahr->name}}
                </h4>
            </div>
        </div>
        <div class="txt">
            <p>
                {{$plan->text}}
            </p>
        </div>
        <div class="design-form">
            <form action="{{route('agent.join.plans',$plan->id)}}" method="POST">
            @csrf
            @method('post')
                <ul>
                    <li>
                        <input type="text" hidden  name="plan_id" value="{{$plan->id}}">
                        <input type="text" hidden  name="producer" value="0">
                        <input type="checkbox" {{$user->plans_pivot($plan->id,'producer')=='1'?'checked':''}} name="producer" value="1">
                         <span>تولید کننده</span>
                    </li>
                    <li>
                        <input type="text" hidden  name="user" value="0">
                        <input type="checkbox" {{$user->plans_pivot($plan->id,'user')=='1'?'checked':''}} name="user" value="1">
                         <span>مصرف کننده</span>
                    </li>
                    <li>
                        <input type="text" hidden  name="investor" value="0">
                        <input type="checkbox" {{$user->plans_pivot($plan->id,'investor')=='1'?'checked':''}} name="investor" value="1">
                         <span>سرمایه گذار</span>
                    </li>
                    <li>
                        <input type="text" hidden  name="facilitator" value="0">
                        <input type="checkbox" {{$user->plans_pivot($plan->id,'facilitator')=='1'?'checked':''}} name="facilitator" value="1">
                         <span>تسهیلگر</span>
                    </li>
                </ul>
                <div class="button-container">
                    <a href="{{route('agent.plans')}}"> برگشت</a>

                    @if($user->plans->contains($plan->id))
                    <button class="green">  به روز رسانی  </button>

                     @else
                    <button class="green">عضویت در طرح</button>

                    @endif
                </div>
            </form>
        </div>
        </div>



    </div>
</div>
@endsection
