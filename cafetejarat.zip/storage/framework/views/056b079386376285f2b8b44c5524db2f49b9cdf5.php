<?php $__env->startSection('main_body'); ?>
<div class="content-box">
    <div class="main-title">
        <h3>طرحها</h3>
        <a href="#"></a>
    </div>

    <div class="box-content">


        <div class="profile-top">
            <div class="img">
                <img src="<?php echo e($user->avatar()); ?>" alt="">
            </div>
            <div class="lefts">
                <h4>
                    <?php echo e($user->name); ?>

                    <?php echo e($user->family); ?>

                </h4>
            </div>

            <div class="button-container">
                <a class="green" href="<?php echo e(route('agent.panel')); ?>">   برگشت</a>
            </div>
        </div>

     <div class="videos">
        <div class="row">
            <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-lg-6" style="margin-bottom:20px">
                <div>
                    <div class="single-designs">
                        <div  class="img" style="background: url('') ;">
                            <img src="<?php echo e($cat->image()); ?>" alt="">
                        </div>
                        <h4>          <?php echo e($cat->title); ?></h4>
                        <div class="button-container">
                            <a class="green" href="<?php echo e(route('agent.single.vcat',$cat->id)); ?>">   مشاهده</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
     </div>



    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\cafetejarat\resources\views/home/agent/cats.blade.php ENDPATH**/ ?>