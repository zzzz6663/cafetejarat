use Morilog\Jalali\Jalalian;
<?php $__env->startComponent('admin.section.content',['title'=>' داشبورد']); ?>
<?php $__env->slot('bread'); ?>
<li class="breadcrumb-item">پنل مدیریت</li>
<?php $__env->endSlot(); ?>

<div class="page-body">
    <div class="container-xl">
        <!-- Page title -->
        <div class="page-header d-print-none">
            <div class="row align-items-center">
                <div class="col">
                    <h2 class="page-title">
                        تراکنش  ها
                        (<?php echo e($bills->total()); ?>)
                    </h2>

                </div>
            </div>
            <form action="<?php echo e(route('admin.bill.all')); ?>" method="get">
                <?php echo csrf_field(); ?>
                <?php echo method_field('get'); ?>
                <div class="row align-items-center">

                    
                    
                    <div class="col-auto ms-auto d-print-none mt-4">
                        <div class="d-flex">

                            <input type="search" name="search" value="<?php echo e(request('search')); ?>" class="form-control d-inline-block w-9 me-3" placeholder="جستجوی نماینده  ">
                            <button class="btn btn-primary">
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-search" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <circle cx="10" cy="10" r="7"></circle>
                                    <line x1="21" y1="21" x2="15" y2="15"></line>
                                </svg>
                                جستوجو
                            </button>

                        </div>
                    </div>

                </div>
            </form>

        </div>
    </div>
</div>
<div class="page-body">
    <div class="container-xl">
        <div class="row row-cards">
           <div class="card">
            <div class="table-responsive">
                <table class="table table-vcenter card-table">
                    <thead>
                        <tr>
                            <th>ردیف </th>
                            <th>نام </th>
                            <th>استان </th>
                            <th>شهر </th>
                            <th>طرح </th>
                            <th>برای </th>
                            <th>نوع</th>
                            <th>تاریخ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $bills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>  <?php echo e($loop->iteration); ?></td>
                            <td>  <?php echo e($bill->user->name); ?> <?php echo e($bill->user->family); ?></td>
                            <td>  <?php echo e($bill->user->ostan?$bill->user->ostan->name:''); ?></td>
                            <td>  <?php echo e($bill->user->shahr?$bill->user->shahr->name:''); ?></td>
                            <td>  <?php echo e($bill->user->plan?$bill->user->plan->name:''); ?></td>
                            <td>  <?php echo e(__('arr.'.$bill->for)); ?>


                            </td>
                            <td>  <?php echo e(__('arr.'.$bill->type)); ?></td>
                            <td>  <?php echo e(\Morilog\Jalali\Jalalian::forge($bill->user->created_at)); ?></td></td>



                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
           </div>
        </div>
        <div class="d-flex mt-4">
            <?php echo e($bills->appends(Request::all())->links('admin.section.pagination')); ?>

        </div>
    </div>
</div>
</div>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\cafetejarat\resources\views/admin/bills/all.blade.php ENDPATH**/ ?>