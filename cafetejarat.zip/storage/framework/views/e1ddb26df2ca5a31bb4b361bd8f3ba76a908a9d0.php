use Morilog\Jalali\Jalalian;
<?php $__env->startComponent('admin.section.content',['title'=>' داشبورد']); ?>
<?php $__env->slot('bread'); ?>
<li class="breadcrumb-item">پنل مدیریت</li>
<?php $__env->endSlot(); ?>

<div class="page-body">
    <div class="container-xl">
        <!-- Page title -->
        <div class="page-header d-print-none">
            <div class="row align-items-center">
                <div class="col">
                    <h2 class="page-title">
                        دانلود  ها
                    </h2>

                </div>
            </div>
            <form action="<?php echo e(route('download.index')); ?>" method="get">
                <?php echo csrf_field(); ?>
                <?php echo method_field('get'); ?>
                <div class="row align-items-center">


                    <div class="col-auto ms-auto d-print-none mt-4">
                        <div class="d-flex">
                            <a class="btn btn-success active w-100" href="<?php echo e(route('download.create')); ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-plus"
                                    width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"
                                    fill="none" stroke-linecap="round" stroke-linejoin="round">
                                    <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                    <line x1="12" y1="5" x2="12" y2="19"></line>
                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                </svg>
                                دانلود  جدید
                            </a>
                        </div>
                    </div>
                    

                </div>
            </form>

        </div>
    </div>
</div>
<div class="page-body">
    <div class="container-xl">
        <div class="row row-cards">
            <div class="card">
                <div class="table-responsive">
                    <table class="table table-vcenter card-table">
                        <thead>
                            <tr>
                                <th>ردیف </th>
                                <th>تایتل </th>
                                <th>محتوا </th>
                                
                                
                                
                                <th>اقدام</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $downloads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $download): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td> <?php echo e($loop->iteration); ?></td>
                                <td> <?php echo e($download->title); ?></td>
                                <td> <?php echo e($download->content); ?></td>
                                <td>
                                    <a class="btn btn-secondary  " href="<?php echo e(route('download.edit',$download->id)); ?>">ویرایش</a>
                                <a href="<?php echo e($download->img()); ?>" class="btn btn-primary  " data-lightbox="roadtrip">عکس</a>
                                <form style="display: inline-block" action="<?php echo e(route('download.destroy',$download->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <input type="submit" class="btn btn-danger " value="حذف"   >
                                </form>
                                </td>


                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="d-flex mt-4">
            <?php echo e($downloads->appends(Request::all())->links('admin.section.pagination')); ?>

        </div>
    </div>
</div>
</div>
</div>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\cafetejarat\resources\views/admin/downloads/all.blade.php ENDPATH**/ ?>