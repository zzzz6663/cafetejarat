<?php $__env->startSection('main_body'); ?>
<div class="content-box">
    <div class="main-title">
        <h3>تماس با ما</h3>
        <a href="<?php echo e(route('login')); ?>"></a>
    </div>

    <div class="box-content">

        <a class="linky" href="<?php echo e(route('agent.panel')); ?>">
            بازگشت
            <img style="width: 20px" src="/home/images/back.png" alt="">
        </a>
        <br>
        <br>
        <br>

        <div class="messages">
            <div class="row">
                <?php $__currentLoopData = $downloads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $download): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-12" style="margin-bottom:20px">
                    <div>
                        <div class="single-design">
                            <img style="width: 100%" src="<?php echo e($download->img()); ?>" alt="">

                            <h4>          <?php echo e($download->title); ?></h4>

                            <?php if($download->content): ?>
                            <p>
                                <?php echo e($download->content); ?>

                            </p>
                            <?php endif; ?>
                            <div class="button-container">
                            <a class="green" href="<?php echo e($download->file()); ?>" >دانلود</a>

                            </div>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>


        </div>



    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\cafetejarat\resources\views/home/agent/downloads.blade.php ENDPATH**/ ?>