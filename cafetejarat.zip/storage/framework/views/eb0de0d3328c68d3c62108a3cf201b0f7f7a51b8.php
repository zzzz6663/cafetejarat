<?php $__env->startComponent('admin.section.content',['title'=>' داشبورد']); ?>
    <?php $__env->slot('bread'); ?>
        <li class="breadcrumb-item">پنل مدیریت</li>
     <?php $__env->endSlot(); ?>

     <div class="page-body">
        <div class="container-xl">
          <div class="row row-deck row-cards">
            <div class="col-sm-6 col-lg-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="subheader">Sales</div>
                    <div class="ms-auto lh-1">
                      <div class="dropdown">
                        <a class="dropdown-toggle text-muted" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Last 7 days</a>
                        <div class="dropdown-menu dropdown-menu-end">
                          <a class="dropdown-item active" href="#">Last 7 days</a>
                          <a class="dropdown-item" href="#">Last 30 days</a>
                          <a class="dropdown-item" href="#">Last 3 months</a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="h1 mb-3">75%</div>
                  <div class="d-flex mb-2">
                    <div>Conversion rate</div>
                    <div class="ms-auto">
                      <span class="text-green d-inline-flex align-items-center lh-1">
                        7% <!-- Download SVG icon from http://tabler-icons.io/i/trending-up -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="3 17 9 11 13 15 21 7" /><polyline points="14 7 21 7 21 14" /></svg>
                      </span>
                    </div>
                  </div>
                  <div class="progress progress-sm">
                    <div class="progress-bar bg-blue" style="width: 75%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
                      <span class="visually-hidden">75% Complete</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="subheader">Revenue</div>
                    <div class="ms-auto lh-1">
                      <div class="dropdown">
                        <a class="dropdown-toggle text-muted" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Last 7 days</a>
                        <div class="dropdown-menu dropdown-menu-end">
                          <a class="dropdown-item active" href="#">Last 7 days</a>
                          <a class="dropdown-item" href="#">Last 30 days</a>
                          <a class="dropdown-item" href="#">Last 3 months</a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="d-flex align-items-baseline">
                    <div class="h1 mb-0 me-2">$4,300</div>
                    <div class="me-auto">
                      <span class="text-green d-inline-flex align-items-center lh-1">
                        8% <!-- Download SVG icon from http://tabler-icons.io/i/trending-up -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="3 17 9 11 13 15 21 7" /><polyline points="14 7 21 7 21 14" /></svg>
                      </span>
                    </div>
                  </div>
                </div>
                <div id="chart-revenue-bg" class="chart-sm"></div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="subheader">New clients</div>
                    <div class="ms-auto lh-1">
                      <div class="dropdown">
                        <a class="dropdown-toggle text-muted" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Last 7 days</a>
                        <div class="dropdown-menu dropdown-menu-end">
                          <a class="dropdown-item active" href="#">Last 7 days</a>
                          <a class="dropdown-item" href="#">Last 30 days</a>
                          <a class="dropdown-item" href="#">Last 3 months</a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="d-flex align-items-baseline">
                    <div class="h1 mb-3 me-2">6,782</div>
                    <div class="me-auto">
                      <span class="text-yellow d-inline-flex align-items-center lh-1">
                        0% <!-- Download SVG icon from http://tabler-icons.io/i/minus -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><line x1="5" y1="12" x2="19" y2="12" /></svg>
                      </span>
                    </div>
                  </div>
                  <div id="chart-new-clients" class="chart-sm"></div>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="subheader">Active users</div>
                    <div class="ms-auto lh-1">
                      <div class="dropdown">
                        <a class="dropdown-toggle text-muted" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Last 7 days</a>
                        <div class="dropdown-menu dropdown-menu-end">
                          <a class="dropdown-item active" href="#">Last 7 days</a>
                          <a class="dropdown-item" href="#">Last 30 days</a>
                          <a class="dropdown-item" href="#">Last 3 months</a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="d-flex align-items-baseline">
                    <div class="h1 mb-3 me-2">2,986</div>
                    <div class="me-auto">
                      <span class="text-green d-inline-flex align-items-center lh-1">
                        4% <!-- Download SVG icon from http://tabler-icons.io/i/trending-up -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="3 17 9 11 13 15 21 7" /><polyline points="14 7 21 7 21 14" /></svg>
                      </span>
                    </div>
                  </div>
                  <div id="chart-active-users" class="chart-sm"></div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="row row-cards">
                <div class="col-12">
                  <div class="card">
                    <div class="card-body">
                      <h3 class="card-title">Traffic summary</h3>
                      <div id="chart-mentions" class="chart-lg"></div>
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="card">
                    <div class="card-body">
                      <p class="mb-3">Using Storage <strong>6854.45 MB </strong>of 8 GB</p>
                      <div class="progress progress-separated mb-3">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 44%"></div>
                        <div class="progress-bar bg-info" role="progressbar" style="width: 19%"></div>
                        <div class="progress-bar bg-success" role="progressbar" style="width: 9%"></div>
                      </div>
                      <div class="row">
                        <div class="col-auto d-flex align-items-center pe-2">
                          <span class="legend me-2 bg-primary"></span>
                          <span>Regular</span>
                          <span class="d-none d-md-inline d-lg-none d-xxl-inline ms-2 text-muted">915MB</span>
                        </div>
                        <div class="col-auto d-flex align-items-center px-2">
                          <span class="legend me-2 bg-info"></span>
                          <span>System</span>
                          <span class="d-none d-md-inline d-lg-none d-xxl-inline ms-2 text-muted">415MB</span>
                        </div>
                        <div class="col-auto d-flex align-items-center px-2">
                          <span class="legend me-2 bg-success"></span>
                          <span>Shared</span>
                          <span class="d-none d-md-inline d-lg-none d-xxl-inline ms-2 text-muted">201MB</span>
                        </div>
                        <div class="col-auto d-flex align-items-center ps-2">
                          <span class="legend me-2"></span>
                          <span>Free</span>
                          <span class="d-none d-md-inline d-lg-none d-xxl-inline ms-2 text-muted">612MB</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="card">
                    <div class="card-body p-2 text-center">
                      <div class="text-end text-green">
                        <span class="text-green d-inline-flex align-items-center lh-1">
                          6% <!-- Download SVG icon from http://tabler-icons.io/i/trending-up -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="3 17 9 11 13 15 21 7" /><polyline points="14 7 21 7 21 14" /></svg>
                        </span>
                      </div>
                      <div class="h1 m-0">43</div>
                      <div class="text-muted mb-3">New Tickets</div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="card">
                    <div class="card-body p-2 text-center">
                      <div class="text-end text-red">
                        <span class="text-red d-inline-flex align-items-center lh-1">
                          -2% <!-- Download SVG icon from http://tabler-icons.io/i/trending-down -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="3 7 9 13 13 9 21 17" /><polyline points="21 10 21 17 14 17" /></svg>
                        </span>
                      </div>
                      <div class="h1 m-0">95</div>
                      <div class="text-muted mb-3">Daily Earnings</div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="card">
                    <div class="card-body p-2 text-center">
                      <div class="text-end text-green">
                        <span class="text-green d-inline-flex align-items-center lh-1">
                          9% <!-- Download SVG icon from http://tabler-icons.io/i/trending-up -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="3 17 9 11 13 15 21 7" /><polyline points="14 7 21 7 21 14" /></svg>
                        </span>
                      </div>
                      <div class="h1 m-0">7</div>
                      <div class="text-muted mb-3">New Replies</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header border-0">
                  <div class="card-title">Development activity</div>
                </div>
                <div class="position-relative">
                  <div class="position-absolute top-0 left-0 px-3 mt-1 w-50">
                    <div class="row g-2">
                      <div class="col-auto">
                        <div class="chart-sparkline chart-sparkline-square" id="sparkline-activity"></div>
                      </div>
                      <div class="col">
                        <div>Today's Earning: $4,262.40</div>
                        <div class="text-muted"><!-- Download SVG icon from http://tabler-icons.io/i/trending-up -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-inline text-green" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="3 17 9 11 13 15 21 7" /><polyline points="14 7 21 7 21 14" /></svg>
                          +5% more than yesterday</div>
                      </div>
                    </div>
                  </div>
                  <div id="chart-development-activity"></div>
                </div>
                <div class="card-table table-responsive">
                  <table class="table table-vcenter">
                    <thead>
                      <tr>
                        <th>User</th>
                        <th>Commit</th>
                        <th>Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td class="w-1">
                          <span class="avatar avatar-sm" style="background-image: url(./static/avatars/000m.jpg)"></span>
                        </td>
                        <td class="td-truncate">
                          <div class="text-truncate">
                            Fix dart Sass compatibility (#29755)
                          </div>
                        </td>
                        <td class="text-nowrap text-muted">28 Nov 2019</td>
                      </tr>
                      <tr>
                        <td class="w-1">
                          <span class="avatar avatar-sm">JL</span>
                        </td>
                        <td class="td-truncate">
                          <div class="text-truncate">
                            Change deprecated html tags to text decoration classes (#29604)
                          </div>
                        </td>
                        <td class="text-nowrap text-muted">27 Nov 2019</td>
                      </tr>
                      <tr>
                        <td class="w-1">
                          <span class="avatar avatar-sm" style="background-image: url(./static/avatars/002m.jpg)"></span>
                        </td>
                        <td class="td-truncate">
                          <div class="text-truncate">
                            justify-content:between ⇒ justify-content:space-between (#29734)
                          </div>
                        </td>
                        <td class="text-nowrap text-muted">26 Nov 2019</td>
                      </tr>
                      <tr>
                        <td class="w-1">
                          <span class="avatar avatar-sm" style="background-image: url(./static/avatars/003m.jpg)"></span>
                        </td>
                        <td class="td-truncate">
                          <div class="text-truncate">
                            Update change-version.js (#29736)
                          </div>
                        </td>
                        <td class="text-nowrap text-muted">26 Nov 2019</td>
                      </tr>
                      <tr>
                        <td class="w-1">
                          <span class="avatar avatar-sm" style="background-image: url(./static/avatars/000f.jpg)"></span>
                        </td>
                        <td class="td-truncate">
                          <div class="text-truncate">
                            Regenerate package-lock.json (#29730)
                          </div>
                        </td>
                        <td class="text-nowrap text-muted">25 Nov 2019</td>
                      </tr>
                      <tr>
                        <td class="w-1">
                          <span class="avatar avatar-sm" style="background-image: url(./static/avatars/001f.jpg)"></span>
                        </td>
                        <td class="td-truncate">
                          <div class="text-truncate">
                            Some minor text tweaks
                          </div>
                        </td>
                        <td class="text-nowrap text-muted">24 Nov 2019</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div class="col-md-8">
              <div class="card" style="height: calc(24rem + 10px)">
                <div class="card-body card-body-scrollable card-body-scrollable-shadow">
                  <div class="divide-y">
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar">JL</span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Jeffie Lewzey</strong> commented on your <strong>"I'm not a witch."</strong> post.
                          </div>
                          <div class="text-muted">yesterday</div>
                        </div>
                        <div class="col-auto align-self-center">
                          <div class="badge bg-primary"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/002m.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            It's <strong>Mallory Hulme</strong>'s birthday. Wish him well!
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                        <div class="col-auto align-self-center">
                          <div class="badge bg-primary"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/003m.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Dunn Slane</strong> posted <strong>"Well, what do you want?"</strong>.
                          </div>
                          <div class="text-muted">today</div>
                        </div>
                        <div class="col-auto align-self-center">
                          <div class="badge bg-primary"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/000f.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Emmy Levet</strong> created a new project <strong>Morning alarm clock</strong>.
                          </div>
                          <div class="text-muted">4 days ago</div>
                        </div>
                        <div class="col-auto align-self-center">
                          <div class="badge bg-primary"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/001f.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Maryjo Lebarree</strong> liked your photo.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar">EP</span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Egan Poetz</strong> registered new client as <strong>Trilia</strong>.
                          </div>
                          <div class="text-muted">yesterday</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/002f.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Kellie Skingley</strong> closed a new deal on project <strong>Pen Pineapple Apple Pen</strong>.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/003f.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Christabel Charlwood</strong> created a new project for <strong>Wikibox</strong>.
                          </div>
                          <div class="text-muted">4 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar">HS</span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Haskel Shelper</strong> change status of <strong>Tabler Icons</strong> from <strong>open</strong> to <strong>closed</strong>.
                          </div>
                          <div class="text-muted">today</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/006m.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Lorry Mion</strong> liked <strong>Tabler UI Kit</strong>.
                          </div>
                          <div class="text-muted">yesterday</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/004f.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Leesa Beaty</strong> posted new video.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/007m.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Perren Keemar</strong> and 3 others followed you.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar">SA</span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Sunny Airey</strong> upload 3 new photos to category <strong>Inspirations</strong>.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/009m.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Geoffry Flaunders</strong> made a <strong>$10</strong> donation.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/010m.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Thatcher Keel</strong> created a profile.
                          </div>
                          <div class="text-muted">3 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/005f.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Dyann Escala</strong> hosted the event <strong>Tabler UI Birthday</strong>.
                          </div>
                          <div class="text-muted">4 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/006f.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Avivah Mugleston</strong> mentioned you on <strong>Best of 2020</strong>.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar">AA</span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Arlie Armstead</strong> sent a Review Request to <strong>Amanda Blake</strong>.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="row row-cards">
                <div class="col-12">
                  <div class="card card-sm">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-auto">
                          <span class="bg-blue text-white avatar"><!-- Download SVG icon from http://tabler-icons.io/i/currency-dollar -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M16.7 8a3 3 0 0 0 -2.7 -2h-4a3 3 0 0 0 0 6h4a3 3 0 0 1 0 6h-4a3 3 0 0 1 -2.7 -2" /><path d="M12 3v3m0 12v3" /></svg>
                          </span>
                        </div>
                        <div class="col">
                          <div class="font-weight-medium">
                            132 Sales
                          </div>
                          <div class="text-muted">
                            12 waiting payments
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="card card-sm">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-auto">
                          <span class="bg-green text-white avatar"><!-- Download SVG icon from http://tabler-icons.io/i/shopping-cart -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="6" cy="19" r="2" /><circle cx="17" cy="19" r="2" /><path d="M17 17h-11v-14h-2" /><path d="M6 5l14 1l-1 7h-13" /></svg>
                          </span>
                        </div>
                        <div class="col">
                          <div class="font-weight-medium">
                            78 Orders
                          </div>
                          <div class="text-muted">
                            32 shipped
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="card card-sm">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-auto">
                          <span class="bg-yellow text-white avatar"><!-- Download SVG icon from http://tabler-icons.io/i/users -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><circle cx="9" cy="7" r="4" /><path d="M3 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /><path d="M21 21v-2a4 4 0 0 0 -3 -3.85" /></svg>
                          </span>
                        </div>
                        <div class="col">
                          <div class="font-weight-medium">
                            1352 Members
                          </div>
                          <div class="text-muted">
                            163 registered today
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="card card-sm">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-auto">
                          <span class="bg-twitter text-white avatar"><!-- Download SVG icon from http://tabler-icons.io/i/brand-twitter -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M22 4.01c-1 .49 -1.98 .689 -3 .99c-1.121 -1.265 -2.783 -1.335 -4.38 -.737s-2.643 2.06 -2.62 3.737v1c-3.245 .083 -6.135 -1.395 -8 -4c0 0 -4.182 7.433 4 11c-1.872 1.247 -3.739 2.088 -6 2c3.308 1.803 6.913 2.423 10.034 1.517c3.58 -1.04 6.522 -3.723 7.651 -7.742a13.84 13.84 0 0 0 .497 -3.753c-.002 -.249 1.51 -2.772 1.818 -4.013z" /></svg>
                          </span>
                        </div>
                        <div class="col">
                          <div class="font-weight-medium">
                            623 Shares
                          </div>
                          <div class="text-muted">
                            16 today
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="card card-sm">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-auto">
                          <span class="bg-facebook text-white avatar"><!-- Download SVG icon from http://tabler-icons.io/i/brand-facebook -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3" /></svg>
                          </span>
                        </div>
                        <div class="col">
                          <div class="font-weight-medium">
                            132 Likes
                          </div>
                          <div class="text-muted">
                            21 today
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12 col-lg-8">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Most Visited Pages</h3>
                </div>
                <div class="card-table table-responsive">
                  <table class="table table-vcenter">
                    <thead>
                      <tr>
                        <th>Page name</th>
                        <th>Visitors</th>
                        <th>Unique</th>
                        <th colspan="2">Bounce rate</th>
                      </tr>
                    </thead>
                    <tr>
                      <td>
                        /about.html
                        <a href="#" class="ms-1" aria-label="Open website"><!-- Download SVG icon from http://tabler-icons.io/i/link -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10 14a3.5 3.5 0 0 0 5 0l4 -4a3.5 3.5 0 0 0 -5 -5l-.5 .5" /><path d="M14 10a3.5 3.5 0 0 0 -5 0l-4 4a3.5 3.5 0 0 0 5 5l.5 -.5" /></svg>
                        </a>
                      </td>
                      <td class="text-muted">4,896</td>
                      <td class="text-muted">3,654</td>
                      <td class="text-muted">82.54%</td>
                      <td class="text-end w-1">
                        <div class="chart-sparkline chart-sparkline-sm" id="sparkline-bounce-rate-1"></div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        /special-promo.html
                        <a href="#" class="ms-1" aria-label="Open website"><!-- Download SVG icon from http://tabler-icons.io/i/link -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10 14a3.5 3.5 0 0 0 5 0l4 -4a3.5 3.5 0 0 0 -5 -5l-.5 .5" /><path d="M14 10a3.5 3.5 0 0 0 -5 0l-4 4a3.5 3.5 0 0 0 5 5l.5 -.5" /></svg>
                        </a>
                      </td>
                      <td class="text-muted">3,652</td>
                      <td class="text-muted">3,215</td>
                      <td class="text-muted">76.29%</td>
                      <td class="text-end w-1">
                        <div class="chart-sparkline chart-sparkline-sm" id="sparkline-bounce-rate-2"></div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        /news/1,new-ui-kit.html
                        <a href="#" class="ms-1" aria-label="Open website"><!-- Download SVG icon from http://tabler-icons.io/i/link -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10 14a3.5 3.5 0 0 0 5 0l4 -4a3.5 3.5 0 0 0 -5 -5l-.5 .5" /><path d="M14 10a3.5 3.5 0 0 0 -5 0l-4 4a3.5 3.5 0 0 0 5 5l.5 -.5" /></svg>
                        </a>
                      </td>
                      <td class="text-muted">3,256</td>
                      <td class="text-muted">2,865</td>
                      <td class="text-muted">72.65%</td>
                      <td class="text-end w-1">
                        <div class="chart-sparkline chart-sparkline-sm" id="sparkline-bounce-rate-3"></div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        /lorem-ipsum-dolor-sit-amet-very-long-url.html
                        <a href="#" class="ms-1" aria-label="Open website"><!-- Download SVG icon from http://tabler-icons.io/i/link -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10 14a3.5 3.5 0 0 0 5 0l4 -4a3.5 3.5 0 0 0 -5 -5l-.5 .5" /><path d="M14 10a3.5 3.5 0 0 0 -5 0l-4 4a3.5 3.5 0 0 0 5 5l.5 -.5" /></svg>
                        </a>
                      </td>
                      <td class="text-muted">986</td>
                      <td class="text-muted">865</td>
                      <td class="text-muted">44.89%</td>
                      <td class="text-end w-1">
                        <div class="chart-sparkline chart-sparkline-sm" id="sparkline-bounce-rate-4"></div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        /colors.html
                        <a href="#" class="ms-1" aria-label="Open website"><!-- Download SVG icon from http://tabler-icons.io/i/link -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10 14a3.5 3.5 0 0 0 5 0l4 -4a3.5 3.5 0 0 0 -5 -5l-.5 .5" /><path d="M14 10a3.5 3.5 0 0 0 -5 0l-4 4a3.5 3.5 0 0 0 5 5l.5 -.5" /></svg>
                        </a>
                      </td>
                      <td class="text-muted">912</td>
                      <td class="text-muted">822</td>
                      <td class="text-muted">41.12%</td>
                      <td class="text-end w-1">
                        <div class="chart-sparkline chart-sparkline-sm" id="sparkline-bounce-rate-5"></div>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        /docs/index.html
                        <a href="#" class="ms-1" aria-label="Open website"><!-- Download SVG icon from http://tabler-icons.io/i/link -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M10 14a3.5 3.5 0 0 0 5 0l4 -4a3.5 3.5 0 0 0 -5 -5l-.5 .5" /><path d="M14 10a3.5 3.5 0 0 0 -5 0l-4 4a3.5 3.5 0 0 0 5 5l.5 -.5" /></svg>
                        </a>
                      </td>
                      <td class="text-muted">855</td>
                      <td class="text-muted">798</td>
                      <td class="text-muted">32.65%</td>
                      <td class="text-end w-1">
                        <div class="chart-sparkline chart-sparkline-sm" id="sparkline-bounce-rate-6"></div>
                      </td>
                    </tr>
                  </table>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4">
              <a href="https://github.com/sponsors/codecalm" class="card card-sponsor" target="_blank" rel="noopener" style="background-image: url(./static/sponsor-banner-homepage.svg)" aria-label="Sponsor Tabler!">
                <div class="card-body"></div>
              </a>
            </div>
            <div class="col-md-6 col-lg-4">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Social Media Traffic</h3>
                </div>
                <table class="table card-table table-vcenter">
                  <thead>
                    <tr>
                      <th>Network</th>
                      <th colspan="2">Visitors</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Instagram</td>
                      <td>3,550</td>
                      <td class="w-50">
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-primary" style="width: 71.0%"></div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>Twitter</td>
                      <td>1,798</td>
                      <td class="w-50">
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-primary" style="width: 35.96%"></div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>Facebook</td>
                      <td>1,245</td>
                      <td class="w-50">
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-primary" style="width: 24.9%"></div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>TikTok</td>
                      <td>986</td>
                      <td class="w-50">
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-primary" style="width: 19.72%"></div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>Pinterest</td>
                      <td>854</td>
                      <td class="w-50">
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-primary" style="width: 17.08%"></div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>VK</td>
                      <td>650</td>
                      <td class="w-50">
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-primary" style="width: 13.0%"></div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>Pinterest</td>
                      <td>420</td>
                      <td class="w-50">
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-primary" style="width: 8.4%"></div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="col-md-12 col-lg-8">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Tasks</h3>
                </div>
                <div class="table-responsive">
                  <table class="table card-table table-vcenter">
                    <tr>
                      <td class="w-1 pe-0">
                        <input type="checkbox" class="form-check-input m-0 align-middle" aria-label="Select task" checked >
                      </td>
                      <td class="w-100">
                        <a href="#" class="text-reset">Extend the data model.</a>
                      </td>
                      <td class="text-nowrap text-muted">
                        <!-- Download SVG icon from http://tabler-icons.io/i/calendar -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><rect x="4" y="5" width="16" height="16" rx="2" /><line x1="16" y1="3" x2="16" y2="7" /><line x1="8" y1="3" x2="8" y2="7" /><line x1="4" y1="11" x2="20" y2="11" /><line x1="11" y1="15" x2="12" y2="15" /><line x1="12" y1="15" x2="12" y2="18" /></svg>
                        January 01, 2019
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/check -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l5 5l10 -10" /></svg>
                          2/7
                        </a>
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/message -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4" /><line x1="8" y1="9" x2="16" y2="9" /><line x1="8" y1="13" x2="14" y2="13" /></svg>
                          3</a>
                      </td>
                      <td>
                        <span class="avatar avatar-sm" style="background-image: url(./static/avatars/000m.jpg)"></span>
                      </td>
                    </tr>
                    <tr>
                      <td class="w-1 pe-0">
                        <input type="checkbox" class="form-check-input m-0 align-middle" aria-label="Select task" >
                      </td>
                      <td class="w-100">
                        <a href="#" class="text-reset">Verify the event flow.</a>
                      </td>
                      <td class="text-nowrap text-muted">
                        <!-- Download SVG icon from http://tabler-icons.io/i/calendar -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><rect x="4" y="5" width="16" height="16" rx="2" /><line x1="16" y1="3" x2="16" y2="7" /><line x1="8" y1="3" x2="8" y2="7" /><line x1="4" y1="11" x2="20" y2="11" /><line x1="11" y1="15" x2="12" y2="15" /><line x1="12" y1="15" x2="12" y2="18" /></svg>
                        January 01, 2019
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/check -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l5 5l10 -10" /></svg>
                          3/10
                        </a>
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/message -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4" /><line x1="8" y1="9" x2="16" y2="9" /><line x1="8" y1="13" x2="14" y2="13" /></svg>
                          6</a>
                      </td>
                      <td>
                        <span class="avatar avatar-sm">JL</span>
                      </td>
                    </tr>
                    <tr>
                      <td class="w-1 pe-0">
                        <input type="checkbox" class="form-check-input m-0 align-middle" aria-label="Select task" >
                      </td>
                      <td class="w-100">
                        <a href="#" class="text-reset">Database backup and maintenance</a>
                      </td>
                      <td class="text-nowrap text-muted">
                        <!-- Download SVG icon from http://tabler-icons.io/i/calendar -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><rect x="4" y="5" width="16" height="16" rx="2" /><line x1="16" y1="3" x2="16" y2="7" /><line x1="8" y1="3" x2="8" y2="7" /><line x1="4" y1="11" x2="20" y2="11" /><line x1="11" y1="15" x2="12" y2="15" /><line x1="12" y1="15" x2="12" y2="18" /></svg>
                        January 01, 2019
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/check -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l5 5l10 -10" /></svg>
                          0/6
                        </a>
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/message -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4" /><line x1="8" y1="9" x2="16" y2="9" /><line x1="8" y1="13" x2="14" y2="13" /></svg>
                          1</a>
                      </td>
                      <td>
                        <span class="avatar avatar-sm" style="background-image: url(./static/avatars/002m.jpg)"></span>
                      </td>
                    </tr>
                    <tr>
                      <td class="w-1 pe-0">
                        <input type="checkbox" class="form-check-input m-0 align-middle" aria-label="Select task" checked >
                      </td>
                      <td class="w-100">
                        <a href="#" class="text-reset">Identify the implementation team.</a>
                      </td>
                      <td class="text-nowrap text-muted">
                        <!-- Download SVG icon from http://tabler-icons.io/i/calendar -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><rect x="4" y="5" width="16" height="16" rx="2" /><line x1="16" y1="3" x2="16" y2="7" /><line x1="8" y1="3" x2="8" y2="7" /><line x1="4" y1="11" x2="20" y2="11" /><line x1="11" y1="15" x2="12" y2="15" /><line x1="12" y1="15" x2="12" y2="18" /></svg>
                        January 01, 2019
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/check -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l5 5l10 -10" /></svg>
                          6/10
                        </a>
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/message -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4" /><line x1="8" y1="9" x2="16" y2="9" /><line x1="8" y1="13" x2="14" y2="13" /></svg>
                          12</a>
                      </td>
                      <td>
                        <span class="avatar avatar-sm" style="background-image: url(./static/avatars/003m.jpg)"></span>
                      </td>
                    </tr>
                    <tr>
                      <td class="w-1 pe-0">
                        <input type="checkbox" class="form-check-input m-0 align-middle" aria-label="Select task" >
                      </td>
                      <td class="w-100">
                        <a href="#" class="text-reset">Define users and workflow</a>
                      </td>
                      <td class="text-nowrap text-muted">
                        <!-- Download SVG icon from http://tabler-icons.io/i/calendar -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><rect x="4" y="5" width="16" height="16" rx="2" /><line x1="16" y1="3" x2="16" y2="7" /><line x1="8" y1="3" x2="8" y2="7" /><line x1="4" y1="11" x2="20" y2="11" /><line x1="11" y1="15" x2="12" y2="15" /><line x1="12" y1="15" x2="12" y2="18" /></svg>
                        January 01, 2019
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/check -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l5 5l10 -10" /></svg>
                          3/7
                        </a>
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/message -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4" /><line x1="8" y1="9" x2="16" y2="9" /><line x1="8" y1="13" x2="14" y2="13" /></svg>
                          5</a>
                      </td>
                      <td>
                        <span class="avatar avatar-sm" style="background-image: url(./static/avatars/000f.jpg)"></span>
                      </td>
                    </tr>
                    <tr>
                      <td class="w-1 pe-0">
                        <input type="checkbox" class="form-check-input m-0 align-middle" aria-label="Select task" checked >
                      </td>
                      <td class="w-100">
                        <a href="#" class="text-reset">Check Pull Requests</a>
                      </td>
                      <td class="text-nowrap text-muted">
                        <!-- Download SVG icon from http://tabler-icons.io/i/calendar -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><rect x="4" y="5" width="16" height="16" rx="2" /><line x1="16" y1="3" x2="16" y2="7" /><line x1="8" y1="3" x2="8" y2="7" /><line x1="4" y1="11" x2="20" y2="11" /><line x1="11" y1="15" x2="12" y2="15" /><line x1="12" y1="15" x2="12" y2="18" /></svg>
                        January 01, 2019
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/check -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M5 12l5 5l10 -10" /></svg>
                          2/9
                        </a>
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/message -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4" /><line x1="8" y1="9" x2="16" y2="9" /><line x1="8" y1="13" x2="14" y2="13" /></svg>
                          3</a>
                      </td>
                      <td>
                        <span class="avatar avatar-sm" style="background-image: url(./static/avatars/001f.jpg)"></span>
                      </td>
                    </tr>
                  </table>
                </div>
              </div>
            </div>
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Invoices</h3>
                </div>
                <div class="card-body border-bottom py-3">
                  <div class="d-flex">
                    <div class="text-muted">
                      Show
                      <div class="mx-2 d-inline-block">
                        <input type="text" class="form-control form-control-sm" value="8" size="3" aria-label="Invoices count">
                      </div>
                      entries
                    </div>
                    <div class="ms-auto text-muted">
                      Search:
                      <div class="ms-2 d-inline-block">
                        <input type="text" class="form-control form-control-sm" aria-label="Search invoice">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table card-table table-vcenter text-nowrap datatable">
                    <thead>
                      <tr>
                        <th class="w-1"><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select all invoices"></th>
                        <th class="w-1">No. <!-- Download SVG icon from http://tabler-icons.io/i/chevron-up -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-sm text-dark icon-thick" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="6 15 12 9 18 15" /></svg>
                        </th>
                        <th>Invoice Subject</th>
                        <th>Client</th>
                        <th>VAT No.</th>
                        <th>Created</th>
                        <th>Status</th>
                        <th>Price</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001401</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">Design Works</a></td>
                        <td>
                          <span class="flag flag-country-us"></span>
                          Carlson Limited
                        </td>
                        <td>
                          87956621
                        </td>
                        <td>
                          15 Dec 2017
                        </td>
                        <td>
                          <span class="badge bg-success me-1"></span> Paid
                        </td>
                        <td>$887</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001402</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">UX Wireframes</a></td>
                        <td>
                          <span class="flag flag-country-gb"></span>
                          Adobe
                        </td>
                        <td>
                          87956421
                        </td>
                        <td>
                          12 Apr 2017
                        </td>
                        <td>
                          <span class="badge bg-warning me-1"></span> Pending
                        </td>
                        <td>$1200</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001403</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">New Dashboard</a></td>
                        <td>
                          <span class="flag flag-country-de"></span>
                          Bluewolf
                        </td>
                        <td>
                          87952621
                        </td>
                        <td>
                          23 Oct 2017
                        </td>
                        <td>
                          <span class="badge bg-warning me-1"></span> Pending
                        </td>
                        <td>$534</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001404</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">Landing Page</a></td>
                        <td>
                          <span class="flag flag-country-br"></span>
                          Salesforce
                        </td>
                        <td>
                          87953421
                        </td>
                        <td>
                          2 Sep 2017
                        </td>
                        <td>
                          <span class="badge bg-secondary me-1"></span> Due in 2 Weeks
                        </td>
                        <td>$1500</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001405</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">Marketing Templates</a></td>
                        <td>
                          <span class="flag flag-country-pl"></span>
                          Printic
                        </td>
                        <td>
                          87956621
                        </td>
                        <td>
                          29 Jan 2018
                        </td>
                        <td>
                          <span class="badge bg-danger me-1"></span> Paid Today
                        </td>
                        <td>$648</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001406</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">Sales Presentation</a></td>
                        <td>
                          <span class="flag flag-country-br"></span>
                          Tabdaq
                        </td>
                        <td>
                          87956621
                        </td>
                        <td>
                          4 Feb 2018
                        </td>
                        <td>
                          <span class="badge bg-secondary me-1"></span> Due in 3 Weeks
                        </td>
                        <td>$300</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001407</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">Logo & Print</a></td>
                        <td>
                          <span class="flag flag-country-us"></span>
                          Apple
                        </td>
                        <td>
                          87956621
                        </td>
                        <td>
                          22 Mar 2018
                        </td>
                        <td>
                          <span class="badge bg-success me-1"></span> Paid Today
                        </td>
                        <td>$2500</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001408</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">Icons</a></td>
                        <td>
                          <span class="flag flag-country-pl"></span>
                          Tookapic
                        </td>
                        <td>
                          87956621
                        </td>
                        <td>
                          13 May 2018
                        </td>
                        <td>
                          <span class="badge bg-success me-1"></span> Paid Today
                        </td>
                        <td>$940</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="card-footer d-flex align-items-center">
                  <p class="m-0 text-muted">Showing <span>1</span> to <span>8</span> of <span>16</span> entries</p>
                  <ul class="pagination m-0 ms-auto">
                    <li class="page-item disabled">
                      <a class="page-link" href="#" tabindex="-1" aria-disabled="true">
                        <!-- Download SVG icon from http://tabler-icons.io/i/chevron-left -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="15 6 9 12 15 18" /></svg>
                        prev
                      </a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                    <li class="page-item active"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item"><a class="page-link" href="#">4</a></li>
                    <li class="page-item"><a class="page-link" href="#">5</a></li>
                    <li class="page-item">
                      <a class="page-link" href="#">
                        next <!-- Download SVG icon from http://tabler-icons.io/i/chevron-right -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><polyline points="9 6 15 12 9 18" /></svg>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
        <div class="container-xl">
          <div class="row row-deck row-cards">
            <div class="col-sm-6 col-lg-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="subheader">Sales</div>
                    <div class="ms-auto lh-1">
                      <div class="dropdown">
                        <a class="dropdown-toggle text-muted" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Last 7 days</a>
                        <div class="dropdown-menu dropdown-menu-end">
                          <a class="dropdown-item active" href="#">Last 7 days</a>
                          <a class="dropdown-item" href="#">Last 30 days</a>
                          <a class="dropdown-item" href="#">Last 3 months</a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="h1 mb-3">75%</div>
                  <div class="d-flex mb-2">
                    <div>Conversion rate</div>
                    <div class="ms-auto">
                      <span class="text-green d-inline-flex align-items-center lh-1">
                        7% <!-- Download SVG icon from http://tabler-icons.io/i/trending-up -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="3 17 9 11 13 15 21 7"></polyline><polyline points="14 7 21 7 21 14"></polyline></svg>
                      </span>
                    </div>
                  </div>
                  <div class="progress progress-sm">
                    <div class="progress-bar bg-blue" style="width: 75%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">
                      <span class="visually-hidden">75% Complete</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-3">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center">
                    <div class="subheader">Revenue</div>
                    <div class="ms-auto lh-1">
                      <div class="dropdown">
                        <a class="dropdown-toggle text-muted" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Last 7 days</a>
                        <div class="dropdown-menu dropdown-menu-end">
                          <a class="dropdown-item active" href="#">Last 7 days</a>
                          <a class="dropdown-item" href="#">Last 30 days</a>
                          <a class="dropdown-item" href="#">Last 3 months</a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="d-flex align-items-baseline">
                    <div class="h1 mb-0 me-2">$4,300</div>
                    <div class="me-auto">
                      <span class="text-green d-inline-flex align-items-center lh-1">
                        8% <!-- Download SVG icon from http://tabler-icons.io/i/trending-up -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="3 17 9 11 13 15 21 7"></polyline><polyline points="14 7 21 7 21 14"></polyline></svg>
                      </span>
                    </div>
                  </div>
                </div>
                <div id="chart-revenue-bg" class="chart-sm" style="min-height: 40px;"><div id="apexchartstw4bjvbr" class="apexcharts-canvas apexchartstw4bjvbr apexcharts-theme-light" style="width: 251px; height: 40px;"><svg id="SvgjsSvg2649" width="251" height="40" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;"><g id="SvgjsG2651" class="apexcharts-inner apexcharts-graphical" transform="translate(0, 0)"><defs id="SvgjsDefs2650"><clipPath id="gridRectMasktw4bjvbr"><rect id="SvgjsRect2687" width="257" height="42" x="-3" y="-1" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath><clipPath id="forecastMasktw4bjvbr"></clipPath><clipPath id="nonForecastMasktw4bjvbr"></clipPath><clipPath id="gridRectMarkerMasktw4bjvbr"><rect id="SvgjsRect2688" width="255" height="44" x="-2" y="-2" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath></defs><line id="SvgjsLine2656" x1="0" y1="0" x2="0" y2="40" stroke="#b6b6b6" stroke-dasharray="3" stroke-linecap="butt" class="apexcharts-xcrosshairs" x="0" y="0" width="1" height="40" fill="#b1b9c4" filter="none" fill-opacity="0.9" stroke-width="1"></line><g id="SvgjsG2695" class="apexcharts-xaxis" transform="translate(0, 0)"><g id="SvgjsG2696" class="apexcharts-xaxis-texts-g" transform="translate(0, -4)"></g></g><g id="SvgjsG2703" class="apexcharts-grid"><g id="SvgjsG2704" class="apexcharts-gridlines-horizontal" style="display: none;"><line id="SvgjsLine2706" x1="0" y1="0" x2="251" y2="0" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2707" x1="0" y1="8" x2="251" y2="8" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2708" x1="0" y1="16" x2="251" y2="16" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2709" x1="0" y1="24" x2="251" y2="24" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2710" x1="0" y1="32" x2="251" y2="32" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2711" x1="0" y1="40" x2="251" y2="40" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line></g><g id="SvgjsG2705" class="apexcharts-gridlines-vertical" style="display: none;"></g><line id="SvgjsLine2713" x1="0" y1="40" x2="251" y2="40" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line><line id="SvgjsLine2712" x1="0" y1="1" x2="0" y2="40" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line></g><g id="SvgjsG2689" class="apexcharts-area-series apexcharts-plot-series"><g id="SvgjsG2690" class="apexcharts-series" seriesName="Profits" data:longestSeries="true" rel="1" data:realIndex="0"><path id="SvgjsPath2693" d="M 0 40L 0 25.2C 3.0293103448275858 25.2 5.625862068965517 26 8.655172413793103 26C 11.684482758620689 26 14.28103448275862 22.4 17.310344827586206 22.4C 20.339655172413792 22.4 22.936206896551724 28.8 25.96551724137931 28.8C 28.994827586206895 28.8 31.591379310344827 25.6 34.62068965517241 25.6C 37.65 25.6 40.24655172413793 30.4 43.275862068965516 30.4C 46.3051724137931 30.4 48.90172413793103 14 51.93103448275862 14C 54.960344827586205 14 57.55689655172414 27.6 60.58620689655172 27.6C 63.61551724137931 27.6 66.21206896551723 25.2 69.24137931034483 25.2C 72.27068965517242 25.2 74.86724137931034 24.4 77.89655172413794 24.4C 80.92586206896551 24.4 83.52241379310345 15.2 86.55172413793103 15.2C 89.58103448275862 15.2 92.17758620689655 19.6 95.20689655172414 19.6C 98.23620689655172 19.6 100.83275862068966 26 103.86206896551724 26C 106.89137931034483 26 109.48793103448276 23.6 112.51724137931035 23.6C 115.54655172413793 23.6 118.14310344827587 26 121.17241379310344 26C 124.20172413793102 26 126.79827586206896 29.2 129.82758620689654 29.2C 132.85689655172413 29.2 135.45344827586206 2.799999999999997 138.48275862068965 2.799999999999997C 141.51206896551724 2.799999999999997 144.10862068965517 18.8 147.13793103448276 18.8C 150.16724137931035 18.8 152.76379310344828 15.600000000000001 155.79310344827587 15.600000000000001C 158.82241379310346 15.600000000000001 161.4189655172414 29.2 164.44827586206898 29.2C 167.47758620689655 29.2 170.0741379310345 18.4 173.10344827586206 18.4C 176.13275862068966 18.4 178.72931034482758 22.8 181.75862068965517 22.8C 184.78793103448277 22.8 187.3844827586207 32.4 190.41379310344828 32.4C 193.44310344827588 32.4 196.0396551724138 21.6 199.0689655172414 21.6C 202.098275862069 21.6 204.69482758620688 24.4 207.72413793103448 24.4C 210.75344827586207 24.4 213.35 15.2 216.3793103448276 15.2C 219.40862068965518 15.2 222.0051724137931 19.6 225.0344827586207 19.6C 228.0637931034483 19.6 230.66034482758621 26 233.6896551724138 26C 236.71896551724137 26 239.31551724137933 23.6 242.3448275862069 23.6C 245.37413793103448 23.6 247.9706896551724 13.2 251 13.2C 251 13.2 251 13.2 251 40M 251 13.2z" fill="rgba(32,107,196,0.16)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-area" index="0" clip-path="url(#gridRectMasktw4bjvbr)" pathTo="M 0 40L 0 25.2C 3.0293103448275858 25.2 5.625862068965517 26 8.655172413793103 26C 11.684482758620689 26 14.28103448275862 22.4 17.310344827586206 22.4C 20.339655172413792 22.4 22.936206896551724 28.8 25.96551724137931 28.8C 28.994827586206895 28.8 31.591379310344827 25.6 34.62068965517241 25.6C 37.65 25.6 40.24655172413793 30.4 43.275862068965516 30.4C 46.3051724137931 30.4 48.90172413793103 14 51.93103448275862 14C 54.960344827586205 14 57.55689655172414 27.6 60.58620689655172 27.6C 63.61551724137931 27.6 66.21206896551723 25.2 69.24137931034483 25.2C 72.27068965517242 25.2 74.86724137931034 24.4 77.89655172413794 24.4C 80.92586206896551 24.4 83.52241379310345 15.2 86.55172413793103 15.2C 89.58103448275862 15.2 92.17758620689655 19.6 95.20689655172414 19.6C 98.23620689655172 19.6 100.83275862068966 26 103.86206896551724 26C 106.89137931034483 26 109.48793103448276 23.6 112.51724137931035 23.6C 115.54655172413793 23.6 118.14310344827587 26 121.17241379310344 26C 124.20172413793102 26 126.79827586206896 29.2 129.82758620689654 29.2C 132.85689655172413 29.2 135.45344827586206 2.799999999999997 138.48275862068965 2.799999999999997C 141.51206896551724 2.799999999999997 144.10862068965517 18.8 147.13793103448276 18.8C 150.16724137931035 18.8 152.76379310344828 15.600000000000001 155.79310344827587 15.600000000000001C 158.82241379310346 15.600000000000001 161.4189655172414 29.2 164.44827586206898 29.2C 167.47758620689655 29.2 170.0741379310345 18.4 173.10344827586206 18.4C 176.13275862068966 18.4 178.72931034482758 22.8 181.75862068965517 22.8C 184.78793103448277 22.8 187.3844827586207 32.4 190.41379310344828 32.4C 193.44310344827588 32.4 196.0396551724138 21.6 199.0689655172414 21.6C 202.098275862069 21.6 204.69482758620688 24.4 207.72413793103448 24.4C 210.75344827586207 24.4 213.35 15.2 216.3793103448276 15.2C 219.40862068965518 15.2 222.0051724137931 19.6 225.0344827586207 19.6C 228.0637931034483 19.6 230.66034482758621 26 233.6896551724138 26C 236.71896551724137 26 239.31551724137933 23.6 242.3448275862069 23.6C 245.37413793103448 23.6 247.9706896551724 13.2 251 13.2C 251 13.2 251 13.2 251 40M 251 13.2z" pathFrom="M -1 40L -1 40L 8.655172413793103 40L 17.310344827586206 40L 25.96551724137931 40L 34.62068965517241 40L 43.275862068965516 40L 51.93103448275862 40L 60.58620689655172 40L 69.24137931034483 40L 77.89655172413794 40L 86.55172413793103 40L 95.20689655172414 40L 103.86206896551724 40L 112.51724137931035 40L 121.17241379310344 40L 129.82758620689654 40L 138.48275862068965 40L 147.13793103448276 40L 155.79310344827587 40L 164.44827586206898 40L 173.10344827586206 40L 181.75862068965517 40L 190.41379310344828 40L 199.0689655172414 40L 207.72413793103448 40L 216.3793103448276 40L 225.0344827586207 40L 233.6896551724138 40L 242.3448275862069 40L 251 40"></path><path id="SvgjsPath2694" d="M 0 25.2C 3.0293103448275858 25.2 5.625862068965517 26 8.655172413793103 26C 11.684482758620689 26 14.28103448275862 22.4 17.310344827586206 22.4C 20.339655172413792 22.4 22.936206896551724 28.8 25.96551724137931 28.8C 28.994827586206895 28.8 31.591379310344827 25.6 34.62068965517241 25.6C 37.65 25.6 40.24655172413793 30.4 43.275862068965516 30.4C 46.3051724137931 30.4 48.90172413793103 14 51.93103448275862 14C 54.960344827586205 14 57.55689655172414 27.6 60.58620689655172 27.6C 63.61551724137931 27.6 66.21206896551723 25.2 69.24137931034483 25.2C 72.27068965517242 25.2 74.86724137931034 24.4 77.89655172413794 24.4C 80.92586206896551 24.4 83.52241379310345 15.2 86.55172413793103 15.2C 89.58103448275862 15.2 92.17758620689655 19.6 95.20689655172414 19.6C 98.23620689655172 19.6 100.83275862068966 26 103.86206896551724 26C 106.89137931034483 26 109.48793103448276 23.6 112.51724137931035 23.6C 115.54655172413793 23.6 118.14310344827587 26 121.17241379310344 26C 124.20172413793102 26 126.79827586206896 29.2 129.82758620689654 29.2C 132.85689655172413 29.2 135.45344827586206 2.799999999999997 138.48275862068965 2.799999999999997C 141.51206896551724 2.799999999999997 144.10862068965517 18.8 147.13793103448276 18.8C 150.16724137931035 18.8 152.76379310344828 15.600000000000001 155.79310344827587 15.600000000000001C 158.82241379310346 15.600000000000001 161.4189655172414 29.2 164.44827586206898 29.2C 167.47758620689655 29.2 170.0741379310345 18.4 173.10344827586206 18.4C 176.13275862068966 18.4 178.72931034482758 22.8 181.75862068965517 22.8C 184.78793103448277 22.8 187.3844827586207 32.4 190.41379310344828 32.4C 193.44310344827588 32.4 196.0396551724138 21.6 199.0689655172414 21.6C 202.098275862069 21.6 204.69482758620688 24.4 207.72413793103448 24.4C 210.75344827586207 24.4 213.35 15.2 216.3793103448276 15.2C 219.40862068965518 15.2 222.0051724137931 19.6 225.0344827586207 19.6C 228.0637931034483 19.6 230.66034482758621 26 233.6896551724138 26C 236.71896551724137 26 239.31551724137933 23.6 242.3448275862069 23.6C 245.37413793103448 23.6 247.9706896551724 13.2 251 13.2" fill="none" fill-opacity="1" stroke="#206bc4" stroke-opacity="1" stroke-linecap="round" stroke-width="2" stroke-dasharray="0" class="apexcharts-area" index="0" clip-path="url(#gridRectMasktw4bjvbr)" pathTo="M 0 25.2C 3.0293103448275858 25.2 5.625862068965517 26 8.655172413793103 26C 11.684482758620689 26 14.28103448275862 22.4 17.310344827586206 22.4C 20.339655172413792 22.4 22.936206896551724 28.8 25.96551724137931 28.8C 28.994827586206895 28.8 31.591379310344827 25.6 34.62068965517241 25.6C 37.65 25.6 40.24655172413793 30.4 43.275862068965516 30.4C 46.3051724137931 30.4 48.90172413793103 14 51.93103448275862 14C 54.960344827586205 14 57.55689655172414 27.6 60.58620689655172 27.6C 63.61551724137931 27.6 66.21206896551723 25.2 69.24137931034483 25.2C 72.27068965517242 25.2 74.86724137931034 24.4 77.89655172413794 24.4C 80.92586206896551 24.4 83.52241379310345 15.2 86.55172413793103 15.2C 89.58103448275862 15.2 92.17758620689655 19.6 95.20689655172414 19.6C 98.23620689655172 19.6 100.83275862068966 26 103.86206896551724 26C 106.89137931034483 26 109.48793103448276 23.6 112.51724137931035 23.6C 115.54655172413793 23.6 118.14310344827587 26 121.17241379310344 26C 124.20172413793102 26 126.79827586206896 29.2 129.82758620689654 29.2C 132.85689655172413 29.2 135.45344827586206 2.799999999999997 138.48275862068965 2.799999999999997C 141.51206896551724 2.799999999999997 144.10862068965517 18.8 147.13793103448276 18.8C 150.16724137931035 18.8 152.76379310344828 15.600000000000001 155.79310344827587 15.600000000000001C 158.82241379310346 15.600000000000001 161.4189655172414 29.2 164.44827586206898 29.2C 167.47758620689655 29.2 170.0741379310345 18.4 173.10344827586206 18.4C 176.13275862068966 18.4 178.72931034482758 22.8 181.75862068965517 22.8C 184.78793103448277 22.8 187.3844827586207 32.4 190.41379310344828 32.4C 193.44310344827588 32.4 196.0396551724138 21.6 199.0689655172414 21.6C 202.098275862069 21.6 204.69482758620688 24.4 207.72413793103448 24.4C 210.75344827586207 24.4 213.35 15.2 216.3793103448276 15.2C 219.40862068965518 15.2 222.0051724137931 19.6 225.0344827586207 19.6C 228.0637931034483 19.6 230.66034482758621 26 233.6896551724138 26C 236.71896551724137 26 239.31551724137933 23.6 242.3448275862069 23.6C 245.37413793103448 23.6 247.9706896551724 13.2 251 13.2" pathFrom="M -1 40L -1 40L 8.655172413793103 40L 17.310344827586206 40L 25.96551724137931 40L 34.62068965517241 40L 43.275862068965516 40L 51.93103448275862 40L 60.58620689655172 40L 69.24137931034483 40L 77.89655172413794 40L 86.55172413793103 40L 95.20689655172414 40L 103.86206896551724 40L 112.51724137931035 40L 121.17241379310344 40L 129.82758620689654 40L 138.48275862068965 40L 147.13793103448276 40L 155.79310344827587 40L 164.44827586206898 40L 173.10344827586206 40L 181.75862068965517 40L 190.41379310344828 40L 199.0689655172414 40L 207.72413793103448 40L 216.3793103448276 40L 225.0344827586207 40L 233.6896551724138 40L 242.3448275862069 40L 251 40"></path><g id="SvgjsG2691" class="apexcharts-series-markers-wrap" data:realIndex="0"><g class="apexcharts-series-markers"><circle id="SvgjsCircle2719" r="0" cx="0" cy="0" class="apexcharts-marker wv4x7k5b5 no-pointer-events" stroke="#ffffff" fill="#206bc4" fill-opacity="1" stroke-width="2" stroke-opacity="0.9" default-marker-size="0"></circle></g></g></g><g id="SvgjsG2692" class="apexcharts-datalabels" data:realIndex="0"></g></g><line id="SvgjsLine2714" x1="0" y1="0" x2="251" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" stroke-linecap="butt" class="apexcharts-ycrosshairs"></line><line id="SvgjsLine2715" x1="0" y1="0" x2="251" y2="0" stroke-dasharray="0" stroke-width="0" stroke-linecap="butt" class="apexcharts-ycrosshairs-hidden"></line><g id="SvgjsG2716" class="apexcharts-yaxis-annotations"></g><g id="SvgjsG2717" class="apexcharts-xaxis-annotations"></g><g id="SvgjsG2718" class="apexcharts-point-annotations"></g></g><rect id="SvgjsRect2655" width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe"></rect><g id="SvgjsG2702" class="apexcharts-yaxis" rel="0" transform="translate(-18, 0)"></g><g id="SvgjsG2652" class="apexcharts-annotations"></g></svg><div class="apexcharts-legend" style="max-height: 20px;"></div><div class="apexcharts-tooltip apexcharts-theme-light"><div class="apexcharts-tooltip-title" style="font-family: inherit; font-size: 12px;"></div><div class="apexcharts-tooltip-series-group" style="order: 1;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(32, 107, 196);"></span><div class="apexcharts-tooltip-text" style="font-family: inherit; font-size: 12px;"><div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-y-label"></span><span class="apexcharts-tooltip-text-y-value"></span></div><div class="apexcharts-tooltip-goals-group"><span class="apexcharts-tooltip-text-goals-label"></span><span class="apexcharts-tooltip-text-goals-value"></span></div><div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div></div></div></div><div class="apexcharts-yaxistooltip apexcharts-yaxistooltip-0 apexcharts-yaxistooltip-left apexcharts-theme-light"><div class="apexcharts-yaxistooltip-text"></div></div></div></div>
              <div class="resize-triggers"><div class="expand-trigger"><div style="width: 252px; height: 137px;"></div></div><div class="contract-trigger"></div></div></div>
            </div>
            <div class="col-sm-6 col-lg-3">
              <div class="card">
                <div class="card-body" style="position: relative;">
                  <div class="d-flex align-items-center">
                    <div class="subheader">New clients</div>
                    <div class="ms-auto lh-1">
                      <div class="dropdown">
                        <a class="dropdown-toggle text-muted" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Last 7 days</a>
                        <div class="dropdown-menu dropdown-menu-end">
                          <a class="dropdown-item active" href="#">Last 7 days</a>
                          <a class="dropdown-item" href="#">Last 30 days</a>
                          <a class="dropdown-item" href="#">Last 3 months</a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="d-flex align-items-baseline">
                    <div class="h1 mb-3 me-2">6,782</div>
                    <div class="me-auto">
                      <span class="text-yellow d-inline-flex align-items-center lh-1">
                        0% <!-- Download SVG icon from http://tabler-icons.io/i/minus -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                      </span>
                    </div>
                  </div>
                  <div id="chart-new-clients" class="chart-sm" style="min-height: 40px;"><div id="apexcharts0h8hkr5tj" class="apexcharts-canvas apexcharts0h8hkr5tj apexcharts-theme-light" style="width: 219px; height: 40px;"><svg id="SvgjsSvg2722" width="219" height="40" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;"><g id="SvgjsG2724" class="apexcharts-inner apexcharts-graphical" transform="translate(0, 0)"><defs id="SvgjsDefs2723"><clipPath id="gridRectMask0h8hkr5tj"><rect id="SvgjsRect2760" width="225" height="42" x="-3" y="-1" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath><clipPath id="forecastMask0h8hkr5tj"></clipPath><clipPath id="nonForecastMask0h8hkr5tj"></clipPath><clipPath id="gridRectMarkerMask0h8hkr5tj"><rect id="SvgjsRect2761" width="223" height="44" x="-2" y="-2" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath></defs><line id="SvgjsLine2729" x1="14.603448275862068" y1="0" x2="14.603448275862068" y2="40" stroke="#b6b6b6" stroke-dasharray="3" stroke-linecap="butt" class="apexcharts-xcrosshairs" x="14.603448275862068" y="0" width="1" height="40" fill="#b1b9c4" filter="none" fill-opacity="0.9" stroke-width="1"></line><g id="SvgjsG2771" class="apexcharts-xaxis" transform="translate(0, 0)"><g id="SvgjsG2772" class="apexcharts-xaxis-texts-g" transform="translate(0, -4)"></g></g><g id="SvgjsG2779" class="apexcharts-grid"><g id="SvgjsG2780" class="apexcharts-gridlines-horizontal" style="display: none;"><line id="SvgjsLine2782" x1="0" y1="0" x2="219" y2="0" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2783" x1="0" y1="8" x2="219" y2="8" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2784" x1="0" y1="16" x2="219" y2="16" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2785" x1="0" y1="24" x2="219" y2="24" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2786" x1="0" y1="32" x2="219" y2="32" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2787" x1="0" y1="40" x2="219" y2="40" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line></g><g id="SvgjsG2781" class="apexcharts-gridlines-vertical" style="display: none;"></g><line id="SvgjsLine2789" x1="0" y1="40" x2="219" y2="40" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line><line id="SvgjsLine2788" x1="0" y1="1" x2="0" y2="40" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line></g><g id="SvgjsG2762" class="apexcharts-line-series apexcharts-plot-series"><g id="SvgjsG2763" class="apexcharts-series" seriesName="May" data:longestSeries="true" rel="1" data:realIndex="0"><path id="SvgjsPath2766" d="M 0 25.2C 2.6431034482758617 25.2 4.908620689655172 26 7.551724137931034 26C 10.194827586206895 26 12.460344827586205 22.4 15.103448275862068 22.4C 17.74655172413793 22.4 20.01206896551724 28.8 22.655172413793103 28.8C 25.298275862068962 28.8 27.563793103448276 25.6 30.206896551724135 25.6C 32.849999999999994 25.6 35.11551724137931 30.4 37.75862068965517 30.4C 40.40172413793103 30.4 42.66724137931034 14 45.310344827586206 14C 47.953448275862065 14 50.21896551724138 27.6 52.86206896551724 27.6C 55.5051724137931 27.6 57.77068965517241 25.2 60.41379310344827 25.2C 63.05689655172413 25.2 65.32241379310344 24.4 67.9655172413793 24.4C 70.60862068965517 24.4 72.87413793103447 15.2 75.51724137931033 15.2C 78.1603448275862 15.2 80.4258620689655 19.6 83.06896551724137 19.6C 85.71206896551723 19.6 87.97758620689655 26 90.62068965517241 26C 93.26379310344828 26 95.52931034482758 23.6 98.17241379310344 23.6C 100.81551724137931 23.6 103.08103448275861 26 105.72413793103448 26C 108.36724137931034 26 110.63275862068964 29.2 113.27586206896551 29.2C 115.91896551724138 29.2 118.18448275862067 2.799999999999997 120.82758620689654 2.799999999999997C 123.47068965517241 2.799999999999997 125.73620689655172 18.8 128.3793103448276 18.8C 131.02241379310345 18.8 133.28793103448274 15.600000000000001 135.9310344827586 15.600000000000001C 138.57413793103447 15.600000000000001 140.83965517241379 29.2 143.48275862068965 29.2C 146.12586206896552 29.2 148.3913793103448 18.4 151.03448275862067 18.4C 153.67758620689654 18.4 155.94310344827585 22.8 158.58620689655172 22.8C 161.22931034482758 22.8 163.49482758620687 38.4 166.13793103448273 38.4C 168.7810344827586 38.4 171.0465517241379 21.6 173.68965517241378 21.6C 176.33275862068965 21.6 178.59827586206896 24.4 181.24137931034483 24.4C 183.8844827586207 24.4 186.14999999999998 15.2 188.79310344827584 15.2C 191.4362068965517 15.2 193.70172413793102 19.6 196.3448275862069 19.6C 198.98793103448276 19.6 201.25344827586204 26 203.8965517241379 26C 206.53965517241377 26 208.8051724137931 23.6 211.44827586206895 23.6C 214.09137931034482 23.6 216.3568965517241 13.2 218.99999999999997 13.2" fill="none" fill-opacity="1" stroke="rgba(32,107,196,1)" stroke-opacity="1" stroke-linecap="round" stroke-width="2" stroke-dasharray="0" class="apexcharts-line" index="0" clip-path="url(#gridRectMask0h8hkr5tj)" pathTo="M 0 25.2C 2.6431034482758617 25.2 4.908620689655172 26 7.551724137931034 26C 10.194827586206895 26 12.460344827586205 22.4 15.103448275862068 22.4C 17.74655172413793 22.4 20.01206896551724 28.8 22.655172413793103 28.8C 25.298275862068962 28.8 27.563793103448276 25.6 30.206896551724135 25.6C 32.849999999999994 25.6 35.11551724137931 30.4 37.75862068965517 30.4C 40.40172413793103 30.4 42.66724137931034 14 45.310344827586206 14C 47.953448275862065 14 50.21896551724138 27.6 52.86206896551724 27.6C 55.5051724137931 27.6 57.77068965517241 25.2 60.41379310344827 25.2C 63.05689655172413 25.2 65.32241379310344 24.4 67.9655172413793 24.4C 70.60862068965517 24.4 72.87413793103447 15.2 75.51724137931033 15.2C 78.1603448275862 15.2 80.4258620689655 19.6 83.06896551724137 19.6C 85.71206896551723 19.6 87.97758620689655 26 90.62068965517241 26C 93.26379310344828 26 95.52931034482758 23.6 98.17241379310344 23.6C 100.81551724137931 23.6 103.08103448275861 26 105.72413793103448 26C 108.36724137931034 26 110.63275862068964 29.2 113.27586206896551 29.2C 115.91896551724138 29.2 118.18448275862067 2.799999999999997 120.82758620689654 2.799999999999997C 123.47068965517241 2.799999999999997 125.73620689655172 18.8 128.3793103448276 18.8C 131.02241379310345 18.8 133.28793103448274 15.600000000000001 135.9310344827586 15.600000000000001C 138.57413793103447 15.600000000000001 140.83965517241379 29.2 143.48275862068965 29.2C 146.12586206896552 29.2 148.3913793103448 18.4 151.03448275862067 18.4C 153.67758620689654 18.4 155.94310344827585 22.8 158.58620689655172 22.8C 161.22931034482758 22.8 163.49482758620687 38.4 166.13793103448273 38.4C 168.7810344827586 38.4 171.0465517241379 21.6 173.68965517241378 21.6C 176.33275862068965 21.6 178.59827586206896 24.4 181.24137931034483 24.4C 183.8844827586207 24.4 186.14999999999998 15.2 188.79310344827584 15.2C 191.4362068965517 15.2 193.70172413793102 19.6 196.3448275862069 19.6C 198.98793103448276 19.6 201.25344827586204 26 203.8965517241379 26C 206.53965517241377 26 208.8051724137931 23.6 211.44827586206895 23.6C 214.09137931034482 23.6 216.3568965517241 13.2 218.99999999999997 13.2" pathFrom="M -1 40L -1 40L 7.551724137931034 40L 15.103448275862068 40L 22.655172413793103 40L 30.206896551724135 40L 37.75862068965517 40L 45.310344827586206 40L 52.86206896551724 40L 60.41379310344827 40L 67.9655172413793 40L 75.51724137931033 40L 83.06896551724137 40L 90.62068965517241 40L 98.17241379310344 40L 105.72413793103448 40L 113.27586206896551 40L 120.82758620689654 40L 128.3793103448276 40L 135.9310344827586 40L 143.48275862068965 40L 151.03448275862067 40L 158.58620689655172 40L 166.13793103448273 40L 173.68965517241378 40L 181.24137931034483 40L 188.79310344827584 40L 196.3448275862069 40L 203.8965517241379 40L 211.44827586206895 40L 218.99999999999997 40"></path><g id="SvgjsG2764" class="apexcharts-series-markers-wrap" data:realIndex="0"><g class="apexcharts-series-markers"><circle id="SvgjsCircle2795" r="0" cx="15.103448275862068" cy="22.4" class="apexcharts-marker w6oo0aba0l no-pointer-events" stroke="#ffffff" fill="#206bc4" fill-opacity="1" stroke-width="2" stroke-opacity="0.9" default-marker-size="0"></circle></g></g></g><g id="SvgjsG2767" class="apexcharts-series" seriesName="April" data:longestSeries="true" rel="2" data:realIndex="1"><path id="SvgjsPath2770" d="M 0 2.799999999999997C 2.6431034482758617 2.799999999999997 4.908620689655172 18.4 7.551724137931034 18.4C 10.194827586206895 18.4 12.460344827586205 19.6 15.103448275862068 19.6C 17.74655172413793 19.6 20.01206896551724 30.4 22.655172413793103 30.4C 25.298275862068962 30.4 27.563793103448276 26 30.206896551724135 26C 32.849999999999994 26 35.11551724137931 26 37.75862068965517 26C 40.40172413793103 26 42.66724137931034 27.6 45.310344827586206 27.6C 47.953448275862065 27.6 50.21896551724138 13.2 52.86206896551724 13.2C 55.5051724137931 13.2 57.77068965517241 32.4 60.41379310344827 32.4C 63.05689655172413 32.4 65.32241379310344 22.8 67.9655172413793 22.8C 70.60862068965517 22.8 72.87413793103447 28.8 75.51724137931033 28.8C 78.1603448275862 28.8 80.4258620689655 25.6 83.06896551724137 25.6C 85.71206896551723 25.6 87.97758620689655 15.2 90.62068965517241 15.2C 93.26379310344828 15.2 95.52931034482758 15.600000000000001 98.17241379310344 15.600000000000001C 100.81551724137931 15.600000000000001 103.08103448275861 29.2 105.72413793103448 29.2C 108.36724137931034 29.2 110.63275862068964 24.4 113.27586206896551 24.4C 115.91896551724138 24.4 118.18448275862067 26 120.82758620689654 26C 123.47068965517241 26 125.73620689655172 23.6 128.3793103448276 23.6C 131.02241379310345 23.6 133.28793103448274 29.2 135.9310344827586 29.2C 138.57413793103447 29.2 140.83965517241379 26 143.48275862068965 26C 146.12586206896552 26 148.3913793103448 19.6 151.03448275862067 19.6C 153.67758620689654 19.6 155.94310344827585 21.6 158.58620689655172 21.6C 161.22931034482758 21.6 163.49482758620687 15.2 166.13793103448273 15.2C 168.7810344827586 15.2 171.0465517241379 25.2 173.68965517241378 25.2C 176.33275862068965 25.2 178.59827586206896 22.4 181.24137931034483 22.4C 183.8844827586207 22.4 186.14999999999998 18.8 188.79310344827584 18.8C 191.4362068965517 18.8 193.70172413793102 23.6 196.3448275862069 23.6C 198.98793103448276 23.6 201.25344827586204 14 203.8965517241379 14C 206.53965517241377 14 208.8051724137931 24.4 211.44827586206895 24.4C 214.09137931034482 24.4 216.3568965517241 25.2 218.99999999999997 25.2" fill="none" fill-opacity="1" stroke="rgba(168,174,183,1)" stroke-opacity="1" stroke-linecap="round" stroke-width="1" stroke-dasharray="3" class="apexcharts-line" index="1" clip-path="url(#gridRectMask0h8hkr5tj)" pathTo="M 0 2.799999999999997C 2.6431034482758617 2.799999999999997 4.908620689655172 18.4 7.551724137931034 18.4C 10.194827586206895 18.4 12.460344827586205 19.6 15.103448275862068 19.6C 17.74655172413793 19.6 20.01206896551724 30.4 22.655172413793103 30.4C 25.298275862068962 30.4 27.563793103448276 26 30.206896551724135 26C 32.849999999999994 26 35.11551724137931 26 37.75862068965517 26C 40.40172413793103 26 42.66724137931034 27.6 45.310344827586206 27.6C 47.953448275862065 27.6 50.21896551724138 13.2 52.86206896551724 13.2C 55.5051724137931 13.2 57.77068965517241 32.4 60.41379310344827 32.4C 63.05689655172413 32.4 65.32241379310344 22.8 67.9655172413793 22.8C 70.60862068965517 22.8 72.87413793103447 28.8 75.51724137931033 28.8C 78.1603448275862 28.8 80.4258620689655 25.6 83.06896551724137 25.6C 85.71206896551723 25.6 87.97758620689655 15.2 90.62068965517241 15.2C 93.26379310344828 15.2 95.52931034482758 15.600000000000001 98.17241379310344 15.600000000000001C 100.81551724137931 15.600000000000001 103.08103448275861 29.2 105.72413793103448 29.2C 108.36724137931034 29.2 110.63275862068964 24.4 113.27586206896551 24.4C 115.91896551724138 24.4 118.18448275862067 26 120.82758620689654 26C 123.47068965517241 26 125.73620689655172 23.6 128.3793103448276 23.6C 131.02241379310345 23.6 133.28793103448274 29.2 135.9310344827586 29.2C 138.57413793103447 29.2 140.83965517241379 26 143.48275862068965 26C 146.12586206896552 26 148.3913793103448 19.6 151.03448275862067 19.6C 153.67758620689654 19.6 155.94310344827585 21.6 158.58620689655172 21.6C 161.22931034482758 21.6 163.49482758620687 15.2 166.13793103448273 15.2C 168.7810344827586 15.2 171.0465517241379 25.2 173.68965517241378 25.2C 176.33275862068965 25.2 178.59827586206896 22.4 181.24137931034483 22.4C 183.8844827586207 22.4 186.14999999999998 18.8 188.79310344827584 18.8C 191.4362068965517 18.8 193.70172413793102 23.6 196.3448275862069 23.6C 198.98793103448276 23.6 201.25344827586204 14 203.8965517241379 14C 206.53965517241377 14 208.8051724137931 24.4 211.44827586206895 24.4C 214.09137931034482 24.4 216.3568965517241 25.2 218.99999999999997 25.2" pathFrom="M -1 40L -1 40L 7.551724137931034 40L 15.103448275862068 40L 22.655172413793103 40L 30.206896551724135 40L 37.75862068965517 40L 45.310344827586206 40L 52.86206896551724 40L 60.41379310344827 40L 67.9655172413793 40L 75.51724137931033 40L 83.06896551724137 40L 90.62068965517241 40L 98.17241379310344 40L 105.72413793103448 40L 113.27586206896551 40L 120.82758620689654 40L 128.3793103448276 40L 135.9310344827586 40L 143.48275862068965 40L 151.03448275862067 40L 158.58620689655172 40L 166.13793103448273 40L 173.68965517241378 40L 181.24137931034483 40L 188.79310344827584 40L 196.3448275862069 40L 203.8965517241379 40L 211.44827586206895 40L 218.99999999999997 40"></path><g id="SvgjsG2768" class="apexcharts-series-markers-wrap" data:realIndex="1"><g class="apexcharts-series-markers"><circle id="SvgjsCircle2796" r="0" cx="15.103448275862068" cy="19.6" class="apexcharts-marker w4qvart63 no-pointer-events" stroke="#ffffff" fill="#a8aeb7" fill-opacity="1" stroke-width="2" stroke-opacity="0.9" default-marker-size="0"></circle></g></g></g><g id="SvgjsG2765" class="apexcharts-datalabels" data:realIndex="0"></g><g id="SvgjsG2769" class="apexcharts-datalabels" data:realIndex="1"></g></g><line id="SvgjsLine2790" x1="0" y1="0" x2="219" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" stroke-linecap="butt" class="apexcharts-ycrosshairs"></line><line id="SvgjsLine2791" x1="0" y1="0" x2="219" y2="0" stroke-dasharray="0" stroke-width="0" stroke-linecap="butt" class="apexcharts-ycrosshairs-hidden"></line><g id="SvgjsG2792" class="apexcharts-yaxis-annotations"></g><g id="SvgjsG2793" class="apexcharts-xaxis-annotations"></g><g id="SvgjsG2794" class="apexcharts-point-annotations"></g></g><rect id="SvgjsRect2728" width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe"></rect><g id="SvgjsG2778" class="apexcharts-yaxis" rel="0" transform="translate(-18, 0)"></g><g id="SvgjsG2725" class="apexcharts-annotations"></g></svg><div class="apexcharts-legend" style="max-height: 20px;"></div><div class="apexcharts-tooltip apexcharts-theme-light" style="left: 26.1034px; top: 0px;"><div class="apexcharts-tooltip-title" style="font-family: inherit; font-size: 12px;">22 Jun</div><div class="apexcharts-tooltip-series-group apexcharts-active" style="order: 1; display: flex;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(32, 107, 196);"></span><div class="apexcharts-tooltip-text" style="font-family: inherit; font-size: 12px;"><div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-y-label">May: </span><span class="apexcharts-tooltip-text-y-value">44</span></div><div class="apexcharts-tooltip-goals-group"><span class="apexcharts-tooltip-text-goals-label"></span><span class="apexcharts-tooltip-text-goals-value"></span></div><div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div></div></div><div class="apexcharts-tooltip-series-group apexcharts-active" style="order: 2; display: flex;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(168, 174, 183);"></span><div class="apexcharts-tooltip-text" style="font-family: inherit; font-size: 12px;"><div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-y-label">April: </span><span class="apexcharts-tooltip-text-y-value">51</span></div><div class="apexcharts-tooltip-goals-group"><span class="apexcharts-tooltip-text-goals-label"></span><span class="apexcharts-tooltip-text-goals-value"></span></div><div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div></div></div></div><div class="apexcharts-yaxistooltip apexcharts-yaxistooltip-0 apexcharts-yaxistooltip-left apexcharts-theme-light"><div class="apexcharts-yaxistooltip-text"></div></div></div></div>
                <div class="resize-triggers"><div class="expand-trigger"><div style="width: 252px; height: 137px;"></div></div><div class="contract-trigger"></div></div></div>
              </div>
            </div>
            <div class="col-sm-6 col-lg-3">
              <div class="card">
                <div class="card-body" style="position: relative;">
                  <div class="d-flex align-items-center">
                    <div class="subheader">Active users</div>
                    <div class="ms-auto lh-1">
                      <div class="dropdown">
                        <a class="dropdown-toggle text-muted" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Last 7 days</a>
                        <div class="dropdown-menu dropdown-menu-end">
                          <a class="dropdown-item active" href="#">Last 7 days</a>
                          <a class="dropdown-item" href="#">Last 30 days</a>
                          <a class="dropdown-item" href="#">Last 3 months</a>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="d-flex align-items-baseline">
                    <div class="h1 mb-3 me-2">2,986</div>
                    <div class="me-auto">
                      <span class="text-green d-inline-flex align-items-center lh-1">
                        4% <!-- Download SVG icon from http://tabler-icons.io/i/trending-up -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="3 17 9 11 13 15 21 7"></polyline><polyline points="14 7 21 7 21 14"></polyline></svg>
                      </span>
                    </div>
                  </div>
                  <div id="chart-active-users" class="chart-sm" style="min-height: 40px;"><div id="apexchartsk4a1nbk6" class="apexcharts-canvas apexchartsk4a1nbk6 apexcharts-theme-light" style="width: 219px; height: 40px;"><svg id="SvgjsSvg2797" width="219" height="40" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;"><g id="SvgjsG2799" class="apexcharts-inner apexcharts-graphical" transform="translate(11.517241379310345, 0)"><defs id="SvgjsDefs2798"><linearGradient id="SvgjsLinearGradient2803" x1="0" y1="0" x2="0" y2="1"><stop id="SvgjsStop2804" stop-opacity="0.4" stop-color="rgba(216,227,240,0.4)" offset="0"></stop><stop id="SvgjsStop2805" stop-opacity="0.5" stop-color="rgba(190,209,230,0.5)" offset="1"></stop><stop id="SvgjsStop2806" stop-opacity="0.5" stop-color="rgba(190,209,230,0.5)" offset="1"></stop></linearGradient><clipPath id="gridRectMaskk4a1nbk6"><rect id="SvgjsRect2838" width="223" height="40" x="-9.517241379310345" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath><clipPath id="forecastMaskk4a1nbk6"></clipPath><clipPath id="nonForecastMaskk4a1nbk6"></clipPath><clipPath id="gridRectMarkerMaskk4a1nbk6"><rect id="SvgjsRect2839" width="207.9655172413793" height="44" x="-2" y="-2" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath></defs><rect id="SvgjsRect2807" width="3.516646848989298" height="40" x="0" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke-dasharray="3" fill="url(#SvgjsLinearGradient2803)" class="apexcharts-xcrosshairs" y2="40" filter="none" fill-opacity="0.9"></rect><g id="SvgjsG2904" class="apexcharts-xaxis" transform="translate(0, 0)"><g id="SvgjsG2905" class="apexcharts-xaxis-texts-g" transform="translate(0, -4)"></g></g><g id="SvgjsG2911" class="apexcharts-grid"><g id="SvgjsG2912" class="apexcharts-gridlines-horizontal" style="display: none;"><line id="SvgjsLine2914" x1="-7.517241379310345" y1="0" x2="211.48275862068965" y2="0" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2915" x1="-7.517241379310345" y1="8" x2="211.48275862068965" y2="8" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2916" x1="-7.517241379310345" y1="16" x2="211.48275862068965" y2="16" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2917" x1="-7.517241379310345" y1="24" x2="211.48275862068965" y2="24" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2918" x1="-7.517241379310345" y1="32" x2="211.48275862068965" y2="32" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine2919" x1="-7.517241379310345" y1="40" x2="211.48275862068965" y2="40" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line></g><g id="SvgjsG2913" class="apexcharts-gridlines-vertical" style="display: none;"></g><line id="SvgjsLine2921" x1="0" y1="40" x2="203.9655172413793" y2="40" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line><line id="SvgjsLine2920" x1="0" y1="1" x2="0" y2="40" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line></g><g id="SvgjsG2840" class="apexcharts-bar-series apexcharts-plot-series"><g id="SvgjsG2841" class="apexcharts-series" rel="1" seriesName="Profits" data:realIndex="0"><path id="SvgjsPath2845" d="M -1.758323424494649 40L -1.758323424494649 25.2Q -1.758323424494649 25.2 -1.758323424494649 25.2L 1.758323424494649 25.2Q 1.758323424494649 25.2 1.758323424494649 25.2L 1.758323424494649 25.2L 1.758323424494649 40L 1.758323424494649 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M -1.758323424494649 40L -1.758323424494649 25.2Q -1.758323424494649 25.2 -1.758323424494649 25.2L 1.758323424494649 25.2Q 1.758323424494649 25.2 1.758323424494649 25.2L 1.758323424494649 25.2L 1.758323424494649 40L 1.758323424494649 40z" pathFrom="M -1.758323424494649 40L -1.758323424494649 40L 1.758323424494649 40L 1.758323424494649 40L 1.758323424494649 40L 1.758323424494649 40L 1.758323424494649 40L -1.758323424494649 40" cy="25.2" cx="1.758323424494649" j="0" val="37" barHeight="14.8" barWidth="3.516646848989298"></path><path id="SvgjsPath2847" d="M 5.274970273483947 40L 5.274970273483947 26Q 5.274970273483947 26 5.274970273483947 26L 8.791617122473244 26Q 8.791617122473244 26 8.791617122473244 26L 8.791617122473244 26L 8.791617122473244 40L 8.791617122473244 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 5.274970273483947 40L 5.274970273483947 26Q 5.274970273483947 26 5.274970273483947 26L 8.791617122473244 26Q 8.791617122473244 26 8.791617122473244 26L 8.791617122473244 26L 8.791617122473244 40L 8.791617122473244 40z" pathFrom="M 5.274970273483947 40L 5.274970273483947 40L 8.791617122473244 40L 8.791617122473244 40L 8.791617122473244 40L 8.791617122473244 40L 8.791617122473244 40L 5.274970273483947 40" cy="26" cx="8.791617122473244" j="1" val="35" barHeight="14" barWidth="3.516646848989298"></path><path id="SvgjsPath2849" d="M 12.308263971462544 40L 12.308263971462544 22.4Q 12.308263971462544 22.4 12.308263971462544 22.4L 15.824910820451842 22.4Q 15.824910820451842 22.4 15.824910820451842 22.4L 15.824910820451842 22.4L 15.824910820451842 40L 15.824910820451842 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 12.308263971462544 40L 12.308263971462544 22.4Q 12.308263971462544 22.4 12.308263971462544 22.4L 15.824910820451842 22.4Q 15.824910820451842 22.4 15.824910820451842 22.4L 15.824910820451842 22.4L 15.824910820451842 40L 15.824910820451842 40z" pathFrom="M 12.308263971462544 40L 12.308263971462544 40L 15.824910820451842 40L 15.824910820451842 40L 15.824910820451842 40L 15.824910820451842 40L 15.824910820451842 40L 12.308263971462544 40" cy="22.4" cx="15.824910820451842" j="2" val="44" barHeight="17.6" barWidth="3.516646848989298"></path><path id="SvgjsPath2851" d="M 19.34155766944114 40L 19.34155766944114 28.8Q 19.34155766944114 28.8 19.34155766944114 28.8L 22.85820451843044 28.8Q 22.85820451843044 28.8 22.85820451843044 28.8L 22.85820451843044 28.8L 22.85820451843044 40L 22.85820451843044 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 19.34155766944114 40L 19.34155766944114 28.8Q 19.34155766944114 28.8 19.34155766944114 28.8L 22.85820451843044 28.8Q 22.85820451843044 28.8 22.85820451843044 28.8L 22.85820451843044 28.8L 22.85820451843044 40L 22.85820451843044 40z" pathFrom="M 19.34155766944114 40L 19.34155766944114 40L 22.85820451843044 40L 22.85820451843044 40L 22.85820451843044 40L 22.85820451843044 40L 22.85820451843044 40L 19.34155766944114 40" cy="28.8" cx="22.85820451843044" j="3" val="28" barHeight="11.2" barWidth="3.516646848989298"></path><path id="SvgjsPath2853" d="M 26.374851367419737 40L 26.374851367419737 25.6Q 26.374851367419737 25.6 26.374851367419737 25.6L 29.891498216409033 25.6Q 29.891498216409033 25.6 29.891498216409033 25.6L 29.891498216409033 25.6L 29.891498216409033 40L 29.891498216409033 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 26.374851367419737 40L 26.374851367419737 25.6Q 26.374851367419737 25.6 26.374851367419737 25.6L 29.891498216409033 25.6Q 29.891498216409033 25.6 29.891498216409033 25.6L 29.891498216409033 25.6L 29.891498216409033 40L 29.891498216409033 40z" pathFrom="M 26.374851367419737 40L 26.374851367419737 40L 29.891498216409033 40L 29.891498216409033 40L 29.891498216409033 40L 29.891498216409033 40L 29.891498216409033 40L 26.374851367419737 40" cy="25.6" cx="29.891498216409033" j="4" val="36" barHeight="14.4" barWidth="3.516646848989298"></path><path id="SvgjsPath2855" d="M 33.40814506539834 40L 33.40814506539834 30.4Q 33.40814506539834 30.4 33.40814506539834 30.4L 36.92479191438763 30.4Q 36.92479191438763 30.4 36.92479191438763 30.4L 36.92479191438763 30.4L 36.92479191438763 40L 36.92479191438763 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 33.40814506539834 40L 33.40814506539834 30.4Q 33.40814506539834 30.4 33.40814506539834 30.4L 36.92479191438763 30.4Q 36.92479191438763 30.4 36.92479191438763 30.4L 36.92479191438763 30.4L 36.92479191438763 40L 36.92479191438763 40z" pathFrom="M 33.40814506539834 40L 33.40814506539834 40L 36.92479191438763 40L 36.92479191438763 40L 36.92479191438763 40L 36.92479191438763 40L 36.92479191438763 40L 33.40814506539834 40" cy="30.4" cx="36.92479191438763" j="5" val="24" barHeight="9.6" barWidth="3.516646848989298"></path><path id="SvgjsPath2857" d="M 40.44143876337693 40L 40.44143876337693 14Q 40.44143876337693 14 40.44143876337693 14L 43.958085612366226 14Q 43.958085612366226 14 43.958085612366226 14L 43.958085612366226 14L 43.958085612366226 40L 43.958085612366226 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 40.44143876337693 40L 40.44143876337693 14Q 40.44143876337693 14 40.44143876337693 14L 43.958085612366226 14Q 43.958085612366226 14 43.958085612366226 14L 43.958085612366226 14L 43.958085612366226 40L 43.958085612366226 40z" pathFrom="M 40.44143876337693 40L 40.44143876337693 40L 43.958085612366226 40L 43.958085612366226 40L 43.958085612366226 40L 43.958085612366226 40L 43.958085612366226 40L 40.44143876337693 40" cy="14" cx="43.958085612366226" j="6" val="65" barHeight="26" barWidth="3.516646848989298"></path><path id="SvgjsPath2859" d="M 47.47473246135553 40L 47.47473246135553 27.6Q 47.47473246135553 27.6 47.47473246135553 27.6L 50.991379310344826 27.6Q 50.991379310344826 27.6 50.991379310344826 27.6L 50.991379310344826 27.6L 50.991379310344826 40L 50.991379310344826 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 47.47473246135553 40L 47.47473246135553 27.6Q 47.47473246135553 27.6 47.47473246135553 27.6L 50.991379310344826 27.6Q 50.991379310344826 27.6 50.991379310344826 27.6L 50.991379310344826 27.6L 50.991379310344826 40L 50.991379310344826 40z" pathFrom="M 47.47473246135553 40L 47.47473246135553 40L 50.991379310344826 40L 50.991379310344826 40L 50.991379310344826 40L 50.991379310344826 40L 50.991379310344826 40L 47.47473246135553 40" cy="27.6" cx="50.991379310344826" j="7" val="31" barHeight="12.4" barWidth="3.516646848989298"></path><path id="SvgjsPath2861" d="M 54.50802615933412 40L 54.50802615933412 25.2Q 54.50802615933412 25.2 54.50802615933412 25.2L 58.02467300832342 25.2Q 58.02467300832342 25.2 58.02467300832342 25.2L 58.02467300832342 25.2L 58.02467300832342 40L 58.02467300832342 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 54.50802615933412 40L 54.50802615933412 25.2Q 54.50802615933412 25.2 54.50802615933412 25.2L 58.02467300832342 25.2Q 58.02467300832342 25.2 58.02467300832342 25.2L 58.02467300832342 25.2L 58.02467300832342 40L 58.02467300832342 40z" pathFrom="M 54.50802615933412 40L 54.50802615933412 40L 58.02467300832342 40L 58.02467300832342 40L 58.02467300832342 40L 58.02467300832342 40L 58.02467300832342 40L 54.50802615933412 40" cy="25.2" cx="58.02467300832342" j="8" val="37" barHeight="14.8" barWidth="3.516646848989298"></path><path id="SvgjsPath2863" d="M 61.54131985731272 40L 61.54131985731272 24.4Q 61.54131985731272 24.4 61.54131985731272 24.4L 65.05796670630203 24.4Q 65.05796670630203 24.4 65.05796670630203 24.4L 65.05796670630203 24.4L 65.05796670630203 40L 65.05796670630203 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 61.54131985731272 40L 61.54131985731272 24.4Q 61.54131985731272 24.4 61.54131985731272 24.4L 65.05796670630203 24.4Q 65.05796670630203 24.4 65.05796670630203 24.4L 65.05796670630203 24.4L 65.05796670630203 40L 65.05796670630203 40z" pathFrom="M 61.54131985731272 40L 61.54131985731272 40L 65.05796670630203 40L 65.05796670630203 40L 65.05796670630203 40L 65.05796670630203 40L 65.05796670630203 40L 61.54131985731272 40" cy="24.4" cx="65.05796670630203" j="9" val="39" barHeight="15.6" barWidth="3.516646848989298"></path><path id="SvgjsPath2865" d="M 68.57461355529132 40L 68.57461355529132 15.2Q 68.57461355529132 15.2 68.57461355529132 15.2L 72.09126040428062 15.2Q 72.09126040428062 15.2 72.09126040428062 15.2L 72.09126040428062 15.2L 72.09126040428062 40L 72.09126040428062 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 68.57461355529132 40L 68.57461355529132 15.2Q 68.57461355529132 15.2 68.57461355529132 15.2L 72.09126040428062 15.2Q 72.09126040428062 15.2 72.09126040428062 15.2L 72.09126040428062 15.2L 72.09126040428062 40L 72.09126040428062 40z" pathFrom="M 68.57461355529132 40L 68.57461355529132 40L 72.09126040428062 40L 72.09126040428062 40L 72.09126040428062 40L 72.09126040428062 40L 72.09126040428062 40L 68.57461355529132 40" cy="15.2" cx="72.09126040428062" j="10" val="62" barHeight="24.8" barWidth="3.516646848989298"></path><path id="SvgjsPath2867" d="M 75.60790725326991 40L 75.60790725326991 19.6Q 75.60790725326991 19.6 75.60790725326991 19.6L 79.12455410225921 19.6Q 79.12455410225921 19.6 79.12455410225921 19.6L 79.12455410225921 19.6L 79.12455410225921 40L 79.12455410225921 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 75.60790725326991 40L 75.60790725326991 19.6Q 75.60790725326991 19.6 75.60790725326991 19.6L 79.12455410225921 19.6Q 79.12455410225921 19.6 79.12455410225921 19.6L 79.12455410225921 19.6L 79.12455410225921 40L 79.12455410225921 40z" pathFrom="M 75.60790725326991 40L 75.60790725326991 40L 79.12455410225921 40L 79.12455410225921 40L 79.12455410225921 40L 79.12455410225921 40L 79.12455410225921 40L 75.60790725326991 40" cy="19.6" cx="79.12455410225921" j="11" val="51" barHeight="20.4" barWidth="3.516646848989298"></path><path id="SvgjsPath2869" d="M 82.6412009512485 40L 82.6412009512485 26Q 82.6412009512485 26 82.6412009512485 26L 86.1578478002378 26Q 86.1578478002378 26 86.1578478002378 26L 86.1578478002378 26L 86.1578478002378 40L 86.1578478002378 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 82.6412009512485 40L 82.6412009512485 26Q 82.6412009512485 26 82.6412009512485 26L 86.1578478002378 26Q 86.1578478002378 26 86.1578478002378 26L 86.1578478002378 26L 86.1578478002378 40L 86.1578478002378 40z" pathFrom="M 82.6412009512485 40L 82.6412009512485 40L 86.1578478002378 40L 86.1578478002378 40L 86.1578478002378 40L 86.1578478002378 40L 86.1578478002378 40L 82.6412009512485 40" cy="26" cx="86.1578478002378" j="12" val="35" barHeight="14" barWidth="3.516646848989298"></path><path id="SvgjsPath2871" d="M 89.67449464922711 40L 89.67449464922711 23.6Q 89.67449464922711 23.6 89.67449464922711 23.6L 93.19114149821641 23.6Q 93.19114149821641 23.6 93.19114149821641 23.6L 93.19114149821641 23.6L 93.19114149821641 40L 93.19114149821641 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 89.67449464922711 40L 89.67449464922711 23.6Q 89.67449464922711 23.6 89.67449464922711 23.6L 93.19114149821641 23.6Q 93.19114149821641 23.6 93.19114149821641 23.6L 93.19114149821641 23.6L 93.19114149821641 40L 93.19114149821641 40z" pathFrom="M 89.67449464922711 40L 89.67449464922711 40L 93.19114149821641 40L 93.19114149821641 40L 93.19114149821641 40L 93.19114149821641 40L 93.19114149821641 40L 89.67449464922711 40" cy="23.6" cx="93.19114149821641" j="13" val="41" barHeight="16.4" barWidth="3.516646848989298"></path><path id="SvgjsPath2873" d="M 96.7077883472057 40L 96.7077883472057 26Q 96.7077883472057 26 96.7077883472057 26L 100.224435196195 26Q 100.224435196195 26 100.224435196195 26L 100.224435196195 26L 100.224435196195 40L 100.224435196195 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 96.7077883472057 40L 96.7077883472057 26Q 96.7077883472057 26 96.7077883472057 26L 100.224435196195 26Q 100.224435196195 26 100.224435196195 26L 100.224435196195 26L 100.224435196195 40L 100.224435196195 40z" pathFrom="M 96.7077883472057 40L 96.7077883472057 40L 100.224435196195 40L 100.224435196195 40L 100.224435196195 40L 100.224435196195 40L 100.224435196195 40L 96.7077883472057 40" cy="26" cx="100.224435196195" j="14" val="35" barHeight="14" barWidth="3.516646848989298"></path><path id="SvgjsPath2875" d="M 103.7410820451843 40L 103.7410820451843 29.2Q 103.7410820451843 29.2 103.7410820451843 29.2L 107.2577288941736 29.2Q 107.2577288941736 29.2 107.2577288941736 29.2L 107.2577288941736 29.2L 107.2577288941736 40L 107.2577288941736 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 103.7410820451843 40L 103.7410820451843 29.2Q 103.7410820451843 29.2 103.7410820451843 29.2L 107.2577288941736 29.2Q 107.2577288941736 29.2 107.2577288941736 29.2L 107.2577288941736 29.2L 107.2577288941736 40L 107.2577288941736 40z" pathFrom="M 103.7410820451843 40L 103.7410820451843 40L 107.2577288941736 40L 107.2577288941736 40L 107.2577288941736 40L 107.2577288941736 40L 107.2577288941736 40L 103.7410820451843 40" cy="29.2" cx="107.2577288941736" j="15" val="27" barHeight="10.8" barWidth="3.516646848989298"></path><path id="SvgjsPath2877" d="M 110.77437574316289 40L 110.77437574316289 2.799999999999997Q 110.77437574316289 2.799999999999997 110.77437574316289 2.799999999999997L 114.29102259215219 2.799999999999997Q 114.29102259215219 2.799999999999997 114.29102259215219 2.799999999999997L 114.29102259215219 2.799999999999997L 114.29102259215219 40L 114.29102259215219 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 110.77437574316289 40L 110.77437574316289 2.799999999999997Q 110.77437574316289 2.799999999999997 110.77437574316289 2.799999999999997L 114.29102259215219 2.799999999999997Q 114.29102259215219 2.799999999999997 114.29102259215219 2.799999999999997L 114.29102259215219 2.799999999999997L 114.29102259215219 40L 114.29102259215219 40z" pathFrom="M 110.77437574316289 40L 110.77437574316289 40L 114.29102259215219 40L 114.29102259215219 40L 114.29102259215219 40L 114.29102259215219 40L 114.29102259215219 40L 110.77437574316289 40" cy="2.799999999999997" cx="114.29102259215219" j="16" val="93" barHeight="37.2" barWidth="3.516646848989298"></path><path id="SvgjsPath2879" d="M 117.8076694411415 40L 117.8076694411415 18.8Q 117.8076694411415 18.8 117.8076694411415 18.8L 121.3243162901308 18.8Q 121.3243162901308 18.8 121.3243162901308 18.8L 121.3243162901308 18.8L 121.3243162901308 40L 121.3243162901308 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 117.8076694411415 40L 117.8076694411415 18.8Q 117.8076694411415 18.8 117.8076694411415 18.8L 121.3243162901308 18.8Q 121.3243162901308 18.8 121.3243162901308 18.8L 121.3243162901308 18.8L 121.3243162901308 40L 121.3243162901308 40z" pathFrom="M 117.8076694411415 40L 117.8076694411415 40L 121.3243162901308 40L 121.3243162901308 40L 121.3243162901308 40L 121.3243162901308 40L 121.3243162901308 40L 117.8076694411415 40" cy="18.8" cx="121.3243162901308" j="17" val="53" barHeight="21.2" barWidth="3.516646848989298"></path><path id="SvgjsPath2881" d="M 124.84096313912009 40L 124.84096313912009 15.600000000000001Q 124.84096313912009 15.600000000000001 124.84096313912009 15.600000000000001L 128.3576099881094 15.600000000000001Q 128.3576099881094 15.600000000000001 128.3576099881094 15.600000000000001L 128.3576099881094 15.600000000000001L 128.3576099881094 40L 128.3576099881094 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 124.84096313912009 40L 124.84096313912009 15.600000000000001Q 124.84096313912009 15.600000000000001 124.84096313912009 15.600000000000001L 128.3576099881094 15.600000000000001Q 128.3576099881094 15.600000000000001 128.3576099881094 15.600000000000001L 128.3576099881094 15.600000000000001L 128.3576099881094 40L 128.3576099881094 40z" pathFrom="M 124.84096313912009 40L 124.84096313912009 40L 128.3576099881094 40L 128.3576099881094 40L 128.3576099881094 40L 128.3576099881094 40L 128.3576099881094 40L 124.84096313912009 40" cy="15.600000000000001" cx="128.3576099881094" j="18" val="61" barHeight="24.4" barWidth="3.516646848989298"></path><path id="SvgjsPath2883" d="M 131.8742568370987 40L 131.8742568370987 29.2Q 131.8742568370987 29.2 131.8742568370987 29.2L 135.390903686088 29.2Q 135.390903686088 29.2 135.390903686088 29.2L 135.390903686088 29.2L 135.390903686088 40L 135.390903686088 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 131.8742568370987 40L 131.8742568370987 29.2Q 131.8742568370987 29.2 131.8742568370987 29.2L 135.390903686088 29.2Q 135.390903686088 29.2 135.390903686088 29.2L 135.390903686088 29.2L 135.390903686088 40L 135.390903686088 40z" pathFrom="M 131.8742568370987 40L 131.8742568370987 40L 135.390903686088 40L 135.390903686088 40L 135.390903686088 40L 135.390903686088 40L 135.390903686088 40L 131.8742568370987 40" cy="29.2" cx="135.390903686088" j="19" val="27" barHeight="10.8" barWidth="3.516646848989298"></path><path id="SvgjsPath2885" d="M 138.9075505350773 40L 138.9075505350773 18.4Q 138.9075505350773 18.4 138.9075505350773 18.4L 142.4241973840666 18.4Q 142.4241973840666 18.4 142.4241973840666 18.4L 142.4241973840666 18.4L 142.4241973840666 40L 142.4241973840666 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 138.9075505350773 40L 138.9075505350773 18.4Q 138.9075505350773 18.4 138.9075505350773 18.4L 142.4241973840666 18.4Q 142.4241973840666 18.4 142.4241973840666 18.4L 142.4241973840666 18.4L 142.4241973840666 40L 142.4241973840666 40z" pathFrom="M 138.9075505350773 40L 138.9075505350773 40L 142.4241973840666 40L 142.4241973840666 40L 142.4241973840666 40L 142.4241973840666 40L 142.4241973840666 40L 138.9075505350773 40" cy="18.4" cx="142.4241973840666" j="20" val="54" barHeight="21.6" barWidth="3.516646848989298"></path><path id="SvgjsPath2887" d="M 145.94084423305588 40L 145.94084423305588 22.8Q 145.94084423305588 22.8 145.94084423305588 22.8L 149.45749108204518 22.8Q 149.45749108204518 22.8 149.45749108204518 22.8L 149.45749108204518 22.8L 149.45749108204518 40L 149.45749108204518 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 145.94084423305588 40L 145.94084423305588 22.8Q 145.94084423305588 22.8 145.94084423305588 22.8L 149.45749108204518 22.8Q 149.45749108204518 22.8 149.45749108204518 22.8L 149.45749108204518 22.8L 149.45749108204518 40L 149.45749108204518 40z" pathFrom="M 145.94084423305588 40L 145.94084423305588 40L 149.45749108204518 40L 149.45749108204518 40L 149.45749108204518 40L 149.45749108204518 40L 149.45749108204518 40L 145.94084423305588 40" cy="22.8" cx="149.45749108204518" j="21" val="43" barHeight="17.2" barWidth="3.516646848989298"></path><path id="SvgjsPath2889" d="M 152.97413793103448 40L 152.97413793103448 32.4Q 152.97413793103448 32.4 152.97413793103448 32.4L 156.49078478002377 32.4Q 156.49078478002377 32.4 156.49078478002377 32.4L 156.49078478002377 32.4L 156.49078478002377 40L 156.49078478002377 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 152.97413793103448 40L 152.97413793103448 32.4Q 152.97413793103448 32.4 152.97413793103448 32.4L 156.49078478002377 32.4Q 156.49078478002377 32.4 156.49078478002377 32.4L 156.49078478002377 32.4L 156.49078478002377 40L 156.49078478002377 40z" pathFrom="M 152.97413793103448 40L 152.97413793103448 40L 156.49078478002377 40L 156.49078478002377 40L 156.49078478002377 40L 156.49078478002377 40L 156.49078478002377 40L 152.97413793103448 40" cy="32.4" cx="156.49078478002377" j="22" val="19" barHeight="7.6" barWidth="3.516646848989298"></path><path id="SvgjsPath2891" d="M 160.00743162901307 40L 160.00743162901307 21.6Q 160.00743162901307 21.6 160.00743162901307 21.6L 163.52407847800237 21.6Q 163.52407847800237 21.6 163.52407847800237 21.6L 163.52407847800237 21.6L 163.52407847800237 40L 163.52407847800237 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 160.00743162901307 40L 160.00743162901307 21.6Q 160.00743162901307 21.6 160.00743162901307 21.6L 163.52407847800237 21.6Q 163.52407847800237 21.6 163.52407847800237 21.6L 163.52407847800237 21.6L 163.52407847800237 40L 163.52407847800237 40z" pathFrom="M 160.00743162901307 40L 160.00743162901307 40L 163.52407847800237 40L 163.52407847800237 40L 163.52407847800237 40L 163.52407847800237 40L 163.52407847800237 40L 160.00743162901307 40" cy="21.6" cx="163.52407847800237" j="23" val="46" barHeight="18.4" barWidth="3.516646848989298"></path><path id="SvgjsPath2893" d="M 167.04072532699166 40L 167.04072532699166 24.4Q 167.04072532699166 24.4 167.04072532699166 24.4L 170.55737217598096 24.4Q 170.55737217598096 24.4 170.55737217598096 24.4L 170.55737217598096 24.4L 170.55737217598096 40L 170.55737217598096 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 167.04072532699166 40L 167.04072532699166 24.4Q 167.04072532699166 24.4 167.04072532699166 24.4L 170.55737217598096 24.4Q 170.55737217598096 24.4 170.55737217598096 24.4L 170.55737217598096 24.4L 170.55737217598096 40L 170.55737217598096 40z" pathFrom="M 167.04072532699166 40L 167.04072532699166 40L 170.55737217598096 40L 170.55737217598096 40L 170.55737217598096 40L 170.55737217598096 40L 170.55737217598096 40L 167.04072532699166 40" cy="24.4" cx="170.55737217598096" j="24" val="39" barHeight="15.6" barWidth="3.516646848989298"></path><path id="SvgjsPath2895" d="M 174.07401902497026 40L 174.07401902497026 15.2Q 174.07401902497026 15.2 174.07401902497026 15.2L 177.59066587395955 15.2Q 177.59066587395955 15.2 177.59066587395955 15.2L 177.59066587395955 15.2L 177.59066587395955 40L 177.59066587395955 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 174.07401902497026 40L 174.07401902497026 15.2Q 174.07401902497026 15.2 174.07401902497026 15.2L 177.59066587395955 15.2Q 177.59066587395955 15.2 177.59066587395955 15.2L 177.59066587395955 15.2L 177.59066587395955 40L 177.59066587395955 40z" pathFrom="M 174.07401902497026 40L 174.07401902497026 40L 177.59066587395955 40L 177.59066587395955 40L 177.59066587395955 40L 177.59066587395955 40L 177.59066587395955 40L 174.07401902497026 40" cy="15.2" cx="177.59066587395955" j="25" val="62" barHeight="24.8" barWidth="3.516646848989298"></path><path id="SvgjsPath2897" d="M 181.10731272294888 40L 181.10731272294888 19.6Q 181.10731272294888 19.6 181.10731272294888 19.6L 184.62395957193817 19.6Q 184.62395957193817 19.6 184.62395957193817 19.6L 184.62395957193817 19.6L 184.62395957193817 40L 184.62395957193817 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 181.10731272294888 40L 181.10731272294888 19.6Q 181.10731272294888 19.6 181.10731272294888 19.6L 184.62395957193817 19.6Q 184.62395957193817 19.6 184.62395957193817 19.6L 184.62395957193817 19.6L 184.62395957193817 40L 184.62395957193817 40z" pathFrom="M 181.10731272294888 40L 181.10731272294888 40L 184.62395957193817 40L 184.62395957193817 40L 184.62395957193817 40L 184.62395957193817 40L 184.62395957193817 40L 181.10731272294888 40" cy="19.6" cx="184.62395957193817" j="26" val="51" barHeight="20.4" barWidth="3.516646848989298"></path><path id="SvgjsPath2899" d="M 188.14060642092747 40L 188.14060642092747 26Q 188.14060642092747 26 188.14060642092747 26L 191.65725326991677 26Q 191.65725326991677 26 191.65725326991677 26L 191.65725326991677 26L 191.65725326991677 40L 191.65725326991677 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 188.14060642092747 40L 188.14060642092747 26Q 188.14060642092747 26 188.14060642092747 26L 191.65725326991677 26Q 191.65725326991677 26 191.65725326991677 26L 191.65725326991677 26L 191.65725326991677 40L 191.65725326991677 40z" pathFrom="M 188.14060642092747 40L 188.14060642092747 40L 191.65725326991677 40L 191.65725326991677 40L 191.65725326991677 40L 191.65725326991677 40L 191.65725326991677 40L 188.14060642092747 40" cy="26" cx="191.65725326991677" j="27" val="35" barHeight="14" barWidth="3.516646848989298"></path><path id="SvgjsPath2901" d="M 195.17390011890606 40L 195.17390011890606 23.6Q 195.17390011890606 23.6 195.17390011890606 23.6L 198.69054696789536 23.6Q 198.69054696789536 23.6 198.69054696789536 23.6L 198.69054696789536 23.6L 198.69054696789536 40L 198.69054696789536 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 195.17390011890606 40L 195.17390011890606 23.6Q 195.17390011890606 23.6 195.17390011890606 23.6L 198.69054696789536 23.6Q 198.69054696789536 23.6 198.69054696789536 23.6L 198.69054696789536 23.6L 198.69054696789536 40L 198.69054696789536 40z" pathFrom="M 195.17390011890606 40L 195.17390011890606 40L 198.69054696789536 40L 198.69054696789536 40L 198.69054696789536 40L 198.69054696789536 40L 198.69054696789536 40L 195.17390011890606 40" cy="23.6" cx="198.69054696789536" j="28" val="41" barHeight="16.4" barWidth="3.516646848989298"></path><path id="SvgjsPath2903" d="M 202.20719381688465 40L 202.20719381688465 13.2Q 202.20719381688465 13.2 202.20719381688465 13.2L 205.72384066587395 13.2Q 205.72384066587395 13.2 205.72384066587395 13.2L 205.72384066587395 13.2L 205.72384066587395 40L 205.72384066587395 40z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMaskk4a1nbk6)" pathTo="M 202.20719381688465 40L 202.20719381688465 13.2Q 202.20719381688465 13.2 202.20719381688465 13.2L 205.72384066587395 13.2Q 205.72384066587395 13.2 205.72384066587395 13.2L 205.72384066587395 13.2L 205.72384066587395 40L 205.72384066587395 40z" pathFrom="M 202.20719381688465 40L 202.20719381688465 40L 205.72384066587395 40L 205.72384066587395 40L 205.72384066587395 40L 205.72384066587395 40L 205.72384066587395 40L 202.20719381688465 40" cy="13.2" cx="205.72384066587395" j="29" val="67" barHeight="26.8" barWidth="3.516646848989298"></path><g id="SvgjsG2843" class="apexcharts-bar-goals-markers" style="pointer-events: none"><g id="SvgjsG2844" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2846" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2848" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2850" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2852" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2854" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2856" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2858" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2860" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2862" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2864" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2866" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2868" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2870" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2872" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2874" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2876" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2878" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2880" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2882" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2884" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2886" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2888" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2890" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2892" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2894" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2896" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2898" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2900" className="apexcharts-bar-goals-groups"></g><g id="SvgjsG2902" className="apexcharts-bar-goals-groups"></g></g></g><g id="SvgjsG2842" class="apexcharts-datalabels" data:realIndex="0"></g></g><line id="SvgjsLine2922" x1="-7.517241379310345" y1="0" x2="211.48275862068965" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" stroke-linecap="butt" class="apexcharts-ycrosshairs"></line><line id="SvgjsLine2923" x1="-7.517241379310345" y1="0" x2="211.48275862068965" y2="0" stroke-dasharray="0" stroke-width="0" stroke-linecap="butt" class="apexcharts-ycrosshairs-hidden"></line><g id="SvgjsG2924" class="apexcharts-yaxis-annotations"></g><g id="SvgjsG2925" class="apexcharts-xaxis-annotations"></g><g id="SvgjsG2926" class="apexcharts-point-annotations"></g></g><g id="SvgjsG2910" class="apexcharts-yaxis" rel="0" transform="translate(-18, 0)"></g><g id="SvgjsG2800" class="apexcharts-annotations"></g></svg><div class="apexcharts-legend" style="max-height: 20px;"></div><div class="apexcharts-tooltip apexcharts-theme-light"><div class="apexcharts-tooltip-title" style="font-family: inherit; font-size: 12px;"></div><div class="apexcharts-tooltip-series-group" style="order: 1;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(32, 107, 196);"></span><div class="apexcharts-tooltip-text" style="font-family: inherit; font-size: 12px;"><div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-y-label"></span><span class="apexcharts-tooltip-text-y-value"></span></div><div class="apexcharts-tooltip-goals-group"><span class="apexcharts-tooltip-text-goals-label"></span><span class="apexcharts-tooltip-text-goals-value"></span></div><div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div></div></div></div><div class="apexcharts-yaxistooltip apexcharts-yaxistooltip-0 apexcharts-yaxistooltip-left apexcharts-theme-light"><div class="apexcharts-yaxistooltip-text"></div></div></div></div>
                <div class="resize-triggers"><div class="expand-trigger"><div style="width: 252px; height: 137px;"></div></div><div class="contract-trigger"></div></div></div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="row row-cards">
                <div class="col-12">
                  <div class="card">
                    <div class="card-body" style="position: relative;">
                      <h3 class="card-title">Traffic summary</h3>
                      <div id="chart-mentions" class="chart-lg" style="min-height: 240px;"><div id="apexchartsnf1c0i1uj" class="apexcharts-canvas apexchartsnf1c0i1uj apexcharts-theme-light" style="width: 489px; height: 240px;"><svg id="SvgjsSvg2927" width="489" height="240" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" class="apexcharts-svg apexcharts-zoomable" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;"><g id="SvgjsG2929" class="apexcharts-inner apexcharts-graphical" transform="translate(42.119936342592595, 10)"><defs id="SvgjsDefs2928"><linearGradient id="SvgjsLinearGradient2934" x1="0" y1="0" x2="0" y2="1"><stop id="SvgjsStop2935" stop-opacity="0.4" stop-color="rgba(216,227,240,0.4)" offset="0"></stop><stop id="SvgjsStop2936" stop-opacity="0.5" stop-color="rgba(190,209,230,0.5)" offset="1"></stop><stop id="SvgjsStop2937" stop-opacity="0.5" stop-color="rgba(190,209,230,0.5)" offset="1"></stop></linearGradient><clipPath id="gridRectMasknf1c0i1uj"><rect id="SvgjsRect2945" width="464.14062500000006" height="199.8" x="-11.260561342592592" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath><clipPath id="forecastMasknf1c0i1uj"></clipPath><clipPath id="nonForecastMasknf1c0i1uj"></clipPath><clipPath id="gridRectMarkerMasknf1c0i1uj"><rect id="SvgjsRect2946" width="445.61950231481484" height="203.8" x="-2" y="-2" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath></defs><rect id="SvgjsRect2938" width="6.133604198816873" height="199.8" x="0" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke-dasharray="3" fill="url(#SvgjsLinearGradient2934)" class="apexcharts-xcrosshairs" y2="199.8" filter="none" fill-opacity="0.9"></rect><g id="SvgjsG3065" class="apexcharts-xaxis" transform="translate(0, 0)"><g id="SvgjsG3066" class="apexcharts-xaxis-texts-g" transform="translate(0, -4)"><text id="SvgjsText3068" font-family="inherit" x="49.06883359053498" y="228.8" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: inherit;"><tspan id="SvgjsTspan3069">24 Jun</tspan><title>24 Jun</title></text><text id="SvgjsText3071" font-family="inherit" x="134.93929237397117" y="228.8" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="600" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: inherit;"><tspan id="SvgjsTspan3072">Jul '20</tspan><title>Jul '20</title></text><text id="SvgjsText3074" font-family="inherit" x="220.80975115740733" y="228.8" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: inherit;"><tspan id="SvgjsTspan3075">08 Jul</tspan><title>08 Jul</title></text><text id="SvgjsText3077" font-family="inherit" x="318.94741833847723" y="228.8" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: inherit;"><tspan id="SvgjsTspan3078">16 Jul</tspan><title>16 Jul</title></text><text id="SvgjsText3080" font-family="inherit" x="417.08508551954714" y="228.8" text-anchor="middle" dominant-baseline="auto" font-size="12px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-xaxis-label " style="font-family: inherit;"><tspan id="SvgjsTspan3081">24 Jul</tspan><title>24 Jul</title></text></g></g><g id="SvgjsG3096" class="apexcharts-grid"><g id="SvgjsG3097" class="apexcharts-gridlines-horizontal"><line id="SvgjsLine3109" x1="-9.260561342592592" y1="0" x2="450.88006365740745" y2="0" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3110" x1="-9.260561342592592" y1="39.96" x2="450.88006365740745" y2="39.96" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3111" x1="-9.260561342592592" y1="79.92" x2="450.88006365740745" y2="79.92" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3112" x1="-9.260561342592592" y1="119.88" x2="450.88006365740745" y2="119.88" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3113" x1="-9.260561342592592" y1="159.84" x2="450.88006365740745" y2="159.84" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3114" x1="-9.260561342592592" y1="199.8" x2="450.88006365740745" y2="199.8" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line></g><g id="SvgjsG3098" class="apexcharts-gridlines-vertical"><line id="SvgjsLine3099" x1="49.06883359053498" y1="0" x2="49.06883359053498" y2="199.8" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3101" x1="134.93929237397117" y1="0" x2="134.93929237397117" y2="199.8" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3103" x1="220.80975115740733" y1="0" x2="220.80975115740733" y2="199.8" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3105" x1="318.94741833847723" y1="0" x2="318.94741833847723" y2="199.8" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3107" x1="417.08508551954714" y1="0" x2="417.08508551954714" y2="199.8" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line></g><line id="SvgjsLine3100" x1="49.06883359053498" y1="200.8" x2="49.06883359053498" y2="206.8" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-xaxis-tick"></line><line id="SvgjsLine3102" x1="134.93929237397117" y1="200.8" x2="134.93929237397117" y2="206.8" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-xaxis-tick"></line><line id="SvgjsLine3104" x1="220.80975115740733" y1="200.8" x2="220.80975115740733" y2="206.8" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-xaxis-tick"></line><line id="SvgjsLine3106" x1="318.94741833847723" y1="200.8" x2="318.94741833847723" y2="206.8" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-xaxis-tick"></line><line id="SvgjsLine3108" x1="417.08508551954714" y1="200.8" x2="417.08508551954714" y2="206.8" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-xaxis-tick"></line><line id="SvgjsLine3116" x1="0" y1="199.8" x2="441.61950231481484" y2="199.8" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line><line id="SvgjsLine3115" x1="0" y1="1" x2="0" y2="199.8" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line></g><g id="SvgjsG2947" class="apexcharts-bar-series apexcharts-plot-series"><g id="SvgjsG2948" class="apexcharts-series" seriesName="Web" rel="1" data:realIndex="0"><path id="SvgjsPath2950" d="M -3.0668020994084366 199.8L -3.0668020994084366 197.80200000000002Q -3.0668020994084366 197.80200000000002 -3.0668020994084366 197.80200000000002L 3.0668020994084366 197.80200000000002Q 3.0668020994084366 197.80200000000002 3.0668020994084366 197.80200000000002L 3.0668020994084366 197.80200000000002L 3.0668020994084366 199.8L 3.0668020994084366 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M -3.0668020994084366 199.8L -3.0668020994084366 197.80200000000002Q -3.0668020994084366 197.80200000000002 -3.0668020994084366 197.80200000000002L 3.0668020994084366 197.80200000000002Q 3.0668020994084366 197.80200000000002 3.0668020994084366 197.80200000000002L 3.0668020994084366 197.80200000000002L 3.0668020994084366 199.8L 3.0668020994084366 199.8z" pathFrom="M -3.0668020994084366 199.8L -3.0668020994084366 199.8L 3.0668020994084366 199.8L 3.0668020994084366 199.8L 3.0668020994084366 199.8L 3.0668020994084366 199.8L 3.0668020994084366 199.8L -3.0668020994084366 199.8" cy="197.80200000000002" cx="3.066802099408437" j="0" val="1" barHeight="1.9980000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2951" d="M 9.20040629822531 199.8L 9.20040629822531 199.8Q 9.20040629822531 199.8 9.20040629822531 199.8L 15.334010497042183 199.8Q 15.334010497042183 199.8 15.334010497042183 199.8L 15.334010497042183 199.8L 15.334010497042183 199.8L 15.334010497042183 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 9.20040629822531 199.8L 9.20040629822531 199.8Q 9.20040629822531 199.8 9.20040629822531 199.8L 15.334010497042183 199.8Q 15.334010497042183 199.8 15.334010497042183 199.8L 15.334010497042183 199.8L 15.334010497042183 199.8L 15.334010497042183 199.8z" pathFrom="M 9.20040629822531 199.8L 9.20040629822531 199.8L 15.334010497042183 199.8L 15.334010497042183 199.8L 15.334010497042183 199.8L 15.334010497042183 199.8L 15.334010497042183 199.8L 9.20040629822531 199.8" cy="199.8" cx="15.334010497042183" j="1" val="0" barHeight="0" barWidth="6.133604198816873"></path><path id="SvgjsPath2952" d="M 21.467614695859055 199.8L 21.467614695859055 199.8Q 21.467614695859055 199.8 21.467614695859055 199.8L 27.601218894675927 199.8Q 27.601218894675927 199.8 27.601218894675927 199.8L 27.601218894675927 199.8L 27.601218894675927 199.8L 27.601218894675927 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 21.467614695859055 199.8L 21.467614695859055 199.8Q 21.467614695859055 199.8 21.467614695859055 199.8L 27.601218894675927 199.8Q 27.601218894675927 199.8 27.601218894675927 199.8L 27.601218894675927 199.8L 27.601218894675927 199.8L 27.601218894675927 199.8z" pathFrom="M 21.467614695859055 199.8L 21.467614695859055 199.8L 27.601218894675927 199.8L 27.601218894675927 199.8L 27.601218894675927 199.8L 27.601218894675927 199.8L 27.601218894675927 199.8L 21.467614695859055 199.8" cy="199.8" cx="27.601218894675927" j="2" val="0" barHeight="0" barWidth="6.133604198816873"></path><path id="SvgjsPath2953" d="M 33.73482309349281 199.8L 33.73482309349281 199.8Q 33.73482309349281 199.8 33.73482309349281 199.8L 39.86842729230968 199.8Q 39.86842729230968 199.8 39.86842729230968 199.8L 39.86842729230968 199.8L 39.86842729230968 199.8L 39.86842729230968 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 33.73482309349281 199.8L 33.73482309349281 199.8Q 33.73482309349281 199.8 33.73482309349281 199.8L 39.86842729230968 199.8Q 39.86842729230968 199.8 39.86842729230968 199.8L 39.86842729230968 199.8L 39.86842729230968 199.8L 39.86842729230968 199.8z" pathFrom="M 33.73482309349281 199.8L 33.73482309349281 199.8L 39.86842729230968 199.8L 39.86842729230968 199.8L 39.86842729230968 199.8L 39.86842729230968 199.8L 39.86842729230968 199.8L 33.73482309349281 199.8" cy="199.8" cx="39.86842729230968" j="3" val="0" barHeight="0" barWidth="6.133604198816873"></path><path id="SvgjsPath2954" d="M 46.00203149112655 199.8L 46.00203149112655 199.8Q 46.00203149112655 199.8 46.00203149112655 199.8L 52.13563568994343 199.8Q 52.13563568994343 199.8 52.13563568994343 199.8L 52.13563568994343 199.8L 52.13563568994343 199.8L 52.13563568994343 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 46.00203149112655 199.8L 46.00203149112655 199.8Q 46.00203149112655 199.8 46.00203149112655 199.8L 52.13563568994343 199.8Q 52.13563568994343 199.8 52.13563568994343 199.8L 52.13563568994343 199.8L 52.13563568994343 199.8L 52.13563568994343 199.8z" pathFrom="M 46.00203149112655 199.8L 46.00203149112655 199.8L 52.13563568994343 199.8L 52.13563568994343 199.8L 52.13563568994343 199.8L 52.13563568994343 199.8L 52.13563568994343 199.8L 46.00203149112655 199.8" cy="199.8" cx="52.13563568994343" j="4" val="0" barHeight="0" barWidth="6.133604198816873"></path><path id="SvgjsPath2955" d="M 58.269239888760296 199.8L 58.269239888760296 197.80200000000002Q 58.269239888760296 197.80200000000002 58.269239888760296 197.80200000000002L 64.40284408757717 197.80200000000002Q 64.40284408757717 197.80200000000002 64.40284408757717 197.80200000000002L 64.40284408757717 197.80200000000002L 64.40284408757717 199.8L 64.40284408757717 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 58.269239888760296 199.8L 58.269239888760296 197.80200000000002Q 58.269239888760296 197.80200000000002 58.269239888760296 197.80200000000002L 64.40284408757717 197.80200000000002Q 64.40284408757717 197.80200000000002 64.40284408757717 197.80200000000002L 64.40284408757717 197.80200000000002L 64.40284408757717 199.8L 64.40284408757717 199.8z" pathFrom="M 58.269239888760296 199.8L 58.269239888760296 199.8L 64.40284408757717 199.8L 64.40284408757717 199.8L 64.40284408757717 199.8L 64.40284408757717 199.8L 64.40284408757717 199.8L 58.269239888760296 199.8" cy="197.80200000000002" cx="64.40284408757718" j="5" val="1" barHeight="1.9980000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2956" d="M 70.53644828639405 199.8L 70.53644828639405 197.80200000000002Q 70.53644828639405 197.80200000000002 70.53644828639405 197.80200000000002L 76.67005248521092 197.80200000000002Q 76.67005248521092 197.80200000000002 76.67005248521092 197.80200000000002L 76.67005248521092 197.80200000000002L 76.67005248521092 199.8L 76.67005248521092 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 70.53644828639405 199.8L 70.53644828639405 197.80200000000002Q 70.53644828639405 197.80200000000002 70.53644828639405 197.80200000000002L 76.67005248521092 197.80200000000002Q 76.67005248521092 197.80200000000002 76.67005248521092 197.80200000000002L 76.67005248521092 197.80200000000002L 76.67005248521092 199.8L 76.67005248521092 199.8z" pathFrom="M 70.53644828639405 199.8L 70.53644828639405 199.8L 76.67005248521092 199.8L 76.67005248521092 199.8L 76.67005248521092 199.8L 76.67005248521092 199.8L 76.67005248521092 199.8L 70.53644828639405 199.8" cy="197.80200000000002" cx="76.67005248521092" j="6" val="1" barHeight="1.9980000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2957" d="M 82.80365668402779 199.8L 82.80365668402779 199.8Q 82.80365668402779 199.8 82.80365668402779 199.8L 88.93726088284465 199.8Q 88.93726088284465 199.8 88.93726088284465 199.8L 88.93726088284465 199.8L 88.93726088284465 199.8L 88.93726088284465 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 82.80365668402779 199.8L 82.80365668402779 199.8Q 82.80365668402779 199.8 82.80365668402779 199.8L 88.93726088284465 199.8Q 88.93726088284465 199.8 88.93726088284465 199.8L 88.93726088284465 199.8L 88.93726088284465 199.8L 88.93726088284465 199.8z" pathFrom="M 82.80365668402779 199.8L 82.80365668402779 199.8L 88.93726088284465 199.8L 88.93726088284465 199.8L 88.93726088284465 199.8L 88.93726088284465 199.8L 88.93726088284465 199.8L 82.80365668402779 199.8" cy="199.8" cx="88.93726088284465" j="7" val="0" barHeight="0" barWidth="6.133604198816873"></path><path id="SvgjsPath2958" d="M 95.07086508166154 199.8L 95.07086508166154 199.8Q 95.07086508166154 199.8 95.07086508166154 199.8L 101.2044692804784 199.8Q 101.2044692804784 199.8 101.2044692804784 199.8L 101.2044692804784 199.8L 101.2044692804784 199.8L 101.2044692804784 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 95.07086508166154 199.8L 95.07086508166154 199.8Q 95.07086508166154 199.8 95.07086508166154 199.8L 101.2044692804784 199.8Q 101.2044692804784 199.8 101.2044692804784 199.8L 101.2044692804784 199.8L 101.2044692804784 199.8L 101.2044692804784 199.8z" pathFrom="M 95.07086508166154 199.8L 95.07086508166154 199.8L 101.2044692804784 199.8L 101.2044692804784 199.8L 101.2044692804784 199.8L 101.2044692804784 199.8L 101.2044692804784 199.8L 95.07086508166154 199.8" cy="199.8" cx="101.2044692804784" j="8" val="0" barHeight="0" barWidth="6.133604198816873"></path><path id="SvgjsPath2959" d="M 107.33807347929528 199.8L 107.33807347929528 199.8Q 107.33807347929528 199.8 107.33807347929528 199.8L 113.47167767811214 199.8Q 113.47167767811214 199.8 113.47167767811214 199.8L 113.47167767811214 199.8L 113.47167767811214 199.8L 113.47167767811214 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 107.33807347929528 199.8L 107.33807347929528 199.8Q 107.33807347929528 199.8 107.33807347929528 199.8L 113.47167767811214 199.8Q 113.47167767811214 199.8 113.47167767811214 199.8L 113.47167767811214 199.8L 113.47167767811214 199.8L 113.47167767811214 199.8z" pathFrom="M 107.33807347929528 199.8L 107.33807347929528 199.8L 113.47167767811214 199.8L 113.47167767811214 199.8L 113.47167767811214 199.8L 113.47167767811214 199.8L 113.47167767811214 199.8L 107.33807347929528 199.8" cy="199.8" cx="113.47167767811214" j="9" val="0" barHeight="0" barWidth="6.133604198816873"></path><path id="SvgjsPath2960" d="M 119.60528187692903 199.8L 119.60528187692903 195.804Q 119.60528187692903 195.804 119.60528187692903 195.804L 125.7388860757459 195.804Q 125.7388860757459 195.804 125.7388860757459 195.804L 125.7388860757459 195.804L 125.7388860757459 199.8L 125.7388860757459 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 119.60528187692903 199.8L 119.60528187692903 195.804Q 119.60528187692903 195.804 119.60528187692903 195.804L 125.7388860757459 195.804Q 125.7388860757459 195.804 125.7388860757459 195.804L 125.7388860757459 195.804L 125.7388860757459 199.8L 125.7388860757459 199.8z" pathFrom="M 119.60528187692903 199.8L 119.60528187692903 199.8L 125.7388860757459 199.8L 125.7388860757459 199.8L 125.7388860757459 199.8L 125.7388860757459 199.8L 125.7388860757459 199.8L 119.60528187692903 199.8" cy="195.804" cx="125.7388860757459" j="10" val="2" barHeight="3.9960000000000004" barWidth="6.133604198816873"></path><path id="SvgjsPath2961" d="M 131.87249027456275 199.8L 131.87249027456275 175.824Q 131.87249027456275 175.824 131.87249027456275 175.824L 138.00609447337962 175.824Q 138.00609447337962 175.824 138.00609447337962 175.824L 138.00609447337962 175.824L 138.00609447337962 199.8L 138.00609447337962 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 131.87249027456275 199.8L 131.87249027456275 175.824Q 131.87249027456275 175.824 131.87249027456275 175.824L 138.00609447337962 175.824Q 138.00609447337962 175.824 138.00609447337962 175.824L 138.00609447337962 175.824L 138.00609447337962 199.8L 138.00609447337962 199.8z" pathFrom="M 131.87249027456275 199.8L 131.87249027456275 199.8L 138.00609447337962 199.8L 138.00609447337962 199.8L 138.00609447337962 199.8L 138.00609447337962 199.8L 138.00609447337962 199.8L 131.87249027456275 199.8" cy="175.824" cx="138.00609447337962" j="11" val="12" barHeight="23.976000000000003" barWidth="6.133604198816873"></path><path id="SvgjsPath2962" d="M 144.13969867219652 199.8L 144.13969867219652 189.81Q 144.13969867219652 189.81 144.13969867219652 189.81L 150.27330287101339 189.81Q 150.27330287101339 189.81 150.27330287101339 189.81L 150.27330287101339 189.81L 150.27330287101339 199.8L 150.27330287101339 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 144.13969867219652 199.8L 144.13969867219652 189.81Q 144.13969867219652 189.81 144.13969867219652 189.81L 150.27330287101339 189.81Q 150.27330287101339 189.81 150.27330287101339 189.81L 150.27330287101339 189.81L 150.27330287101339 199.8L 150.27330287101339 199.8z" pathFrom="M 144.13969867219652 199.8L 144.13969867219652 199.8L 150.27330287101339 199.8L 150.27330287101339 199.8L 150.27330287101339 199.8L 150.27330287101339 199.8L 150.27330287101339 199.8L 144.13969867219652 199.8" cy="189.81" cx="150.27330287101339" j="12" val="5" barHeight="9.990000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2963" d="M 156.40690706983025 199.8L 156.40690706983025 183.816Q 156.40690706983025 183.816 156.40690706983025 183.816L 162.54051126864712 183.816Q 162.54051126864712 183.816 162.54051126864712 183.816L 162.54051126864712 183.816L 162.54051126864712 199.8L 162.54051126864712 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 156.40690706983025 199.8L 156.40690706983025 183.816Q 156.40690706983025 183.816 156.40690706983025 183.816L 162.54051126864712 183.816Q 162.54051126864712 183.816 162.54051126864712 183.816L 162.54051126864712 183.816L 162.54051126864712 199.8L 162.54051126864712 199.8z" pathFrom="M 156.40690706983025 199.8L 156.40690706983025 199.8L 162.54051126864712 199.8L 162.54051126864712 199.8L 162.54051126864712 199.8L 162.54051126864712 199.8L 162.54051126864712 199.8L 156.40690706983025 199.8" cy="183.816" cx="162.54051126864712" j="13" val="8" barHeight="15.984000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2964" d="M 168.674115467464 199.8L 168.674115467464 155.844Q 168.674115467464 155.844 168.674115467464 155.844L 174.80771966628086 155.844Q 174.80771966628086 155.844 174.80771966628086 155.844L 174.80771966628086 155.844L 174.80771966628086 199.8L 174.80771966628086 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 168.674115467464 199.8L 168.674115467464 155.844Q 168.674115467464 155.844 168.674115467464 155.844L 174.80771966628086 155.844Q 174.80771966628086 155.844 174.80771966628086 155.844L 174.80771966628086 155.844L 174.80771966628086 199.8L 174.80771966628086 199.8z" pathFrom="M 168.674115467464 199.8L 168.674115467464 199.8L 174.80771966628086 199.8L 174.80771966628086 199.8L 174.80771966628086 199.8L 174.80771966628086 199.8L 174.80771966628086 199.8L 168.674115467464 199.8" cy="155.844" cx="174.80771966628086" j="14" val="22" barHeight="43.956" barWidth="6.133604198816873"></path><path id="SvgjsPath2965" d="M 180.94132386509773 199.8L 180.94132386509773 187.812Q 180.94132386509773 187.812 180.94132386509773 187.812L 187.0749280639146 187.812Q 187.0749280639146 187.812 187.0749280639146 187.812L 187.0749280639146 187.812L 187.0749280639146 199.8L 187.0749280639146 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 180.94132386509773 199.8L 180.94132386509773 187.812Q 180.94132386509773 187.812 180.94132386509773 187.812L 187.0749280639146 187.812Q 187.0749280639146 187.812 187.0749280639146 187.812L 187.0749280639146 187.812L 187.0749280639146 199.8L 187.0749280639146 199.8z" pathFrom="M 180.94132386509773 199.8L 180.94132386509773 199.8L 187.0749280639146 199.8L 187.0749280639146 199.8L 187.0749280639146 199.8L 187.0749280639146 199.8L 187.0749280639146 199.8L 180.94132386509773 199.8" cy="187.812" cx="187.0749280639146" j="15" val="6" barHeight="11.988000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath2966" d="M 193.2085322627315 199.8L 193.2085322627315 183.816Q 193.2085322627315 183.816 193.2085322627315 183.816L 199.34213646154836 183.816Q 199.34213646154836 183.816 199.34213646154836 183.816L 199.34213646154836 183.816L 199.34213646154836 199.8L 199.34213646154836 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 193.2085322627315 199.8L 193.2085322627315 183.816Q 193.2085322627315 183.816 193.2085322627315 183.816L 199.34213646154836 183.816Q 199.34213646154836 183.816 199.34213646154836 183.816L 199.34213646154836 183.816L 199.34213646154836 199.8L 199.34213646154836 199.8z" pathFrom="M 193.2085322627315 199.8L 193.2085322627315 199.8L 199.34213646154836 199.8L 199.34213646154836 199.8L 199.34213646154836 199.8L 199.34213646154836 199.8L 199.34213646154836 199.8L 193.2085322627315 199.8" cy="183.816" cx="199.34213646154836" j="16" val="8" barHeight="15.984000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2967" d="M 205.47574066036523 199.8L 205.47574066036523 187.812Q 205.47574066036523 187.812 205.47574066036523 187.812L 211.6093448591821 187.812Q 211.6093448591821 187.812 211.6093448591821 187.812L 211.6093448591821 187.812L 211.6093448591821 199.8L 211.6093448591821 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 205.47574066036523 199.8L 205.47574066036523 187.812Q 205.47574066036523 187.812 205.47574066036523 187.812L 211.6093448591821 187.812Q 211.6093448591821 187.812 211.6093448591821 187.812L 211.6093448591821 187.812L 211.6093448591821 199.8L 211.6093448591821 199.8z" pathFrom="M 205.47574066036523 199.8L 205.47574066036523 199.8L 211.6093448591821 199.8L 211.6093448591821 199.8L 211.6093448591821 199.8L 211.6093448591821 199.8L 211.6093448591821 199.8L 205.47574066036523 199.8" cy="187.812" cx="211.6093448591821" j="17" val="6" barHeight="11.988000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath2968" d="M 217.74294905799897 199.8L 217.74294905799897 191.80800000000002Q 217.74294905799897 191.80800000000002 217.74294905799897 191.80800000000002L 223.87655325681584 191.80800000000002Q 223.87655325681584 191.80800000000002 223.87655325681584 191.80800000000002L 223.87655325681584 191.80800000000002L 223.87655325681584 199.8L 223.87655325681584 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 217.74294905799897 199.8L 217.74294905799897 191.80800000000002Q 217.74294905799897 191.80800000000002 217.74294905799897 191.80800000000002L 223.87655325681584 191.80800000000002Q 223.87655325681584 191.80800000000002 223.87655325681584 191.80800000000002L 223.87655325681584 191.80800000000002L 223.87655325681584 199.8L 223.87655325681584 199.8z" pathFrom="M 217.74294905799897 199.8L 217.74294905799897 199.8L 223.87655325681584 199.8L 223.87655325681584 199.8L 223.87655325681584 199.8L 223.87655325681584 199.8L 223.87655325681584 199.8L 217.74294905799897 199.8" cy="191.80800000000002" cx="223.87655325681584" j="18" val="4" barHeight="7.992000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath2969" d="M 230.01015745563274 199.8L 230.01015745563274 197.80200000000002Q 230.01015745563274 197.80200000000002 230.01015745563274 197.80200000000002L 236.1437616544496 197.80200000000002Q 236.1437616544496 197.80200000000002 236.1437616544496 197.80200000000002L 236.1437616544496 197.80200000000002L 236.1437616544496 199.8L 236.1437616544496 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 230.01015745563274 199.8L 230.01015745563274 197.80200000000002Q 230.01015745563274 197.80200000000002 230.01015745563274 197.80200000000002L 236.1437616544496 197.80200000000002Q 236.1437616544496 197.80200000000002 236.1437616544496 197.80200000000002L 236.1437616544496 197.80200000000002L 236.1437616544496 199.8L 236.1437616544496 199.8z" pathFrom="M 230.01015745563274 199.8L 230.01015745563274 199.8L 236.1437616544496 199.8L 236.1437616544496 199.8L 236.1437616544496 199.8L 236.1437616544496 199.8L 236.1437616544496 199.8L 230.01015745563274 199.8" cy="197.80200000000002" cx="236.1437616544496" j="19" val="1" barHeight="1.9980000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2970" d="M 242.27736585326647 199.8L 242.27736585326647 183.816Q 242.27736585326647 183.816 242.27736585326647 183.816L 248.41097005208334 183.816Q 248.41097005208334 183.816 248.41097005208334 183.816L 248.41097005208334 183.816L 248.41097005208334 199.8L 248.41097005208334 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 242.27736585326647 199.8L 242.27736585326647 183.816Q 242.27736585326647 183.816 242.27736585326647 183.816L 248.41097005208334 183.816Q 248.41097005208334 183.816 248.41097005208334 183.816L 248.41097005208334 183.816L 248.41097005208334 199.8L 248.41097005208334 199.8z" pathFrom="M 242.27736585326647 199.8L 242.27736585326647 199.8L 248.41097005208334 199.8L 248.41097005208334 199.8L 248.41097005208334 199.8L 248.41097005208334 199.8L 248.41097005208334 199.8L 242.27736585326647 199.8" cy="183.816" cx="248.41097005208334" j="20" val="8" barHeight="15.984000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2971" d="M 254.5445742509002 199.8L 254.5445742509002 151.848Q 254.5445742509002 151.848 254.5445742509002 151.848L 260.6781784497171 151.848Q 260.6781784497171 151.848 260.6781784497171 151.848L 260.6781784497171 151.848L 260.6781784497171 199.8L 260.6781784497171 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 254.5445742509002 199.8L 254.5445742509002 151.848Q 254.5445742509002 151.848 254.5445742509002 151.848L 260.6781784497171 151.848Q 260.6781784497171 151.848 260.6781784497171 151.848L 260.6781784497171 151.848L 260.6781784497171 199.8L 260.6781784497171 199.8z" pathFrom="M 254.5445742509002 199.8L 254.5445742509002 199.8L 260.6781784497171 199.8L 260.6781784497171 199.8L 260.6781784497171 199.8L 260.6781784497171 199.8L 260.6781784497171 199.8L 254.5445742509002 199.8" cy="151.848" cx="260.6781784497171" j="21" val="24" barHeight="47.952000000000005" barWidth="6.133604198816873"></path><path id="SvgjsPath2972" d="M 266.81178264853395 199.8L 266.81178264853395 141.858Q 266.81178264853395 141.858 266.81178264853395 141.858L 272.94538684735085 141.858Q 272.94538684735085 141.858 272.94538684735085 141.858L 272.94538684735085 141.858L 272.94538684735085 199.8L 272.94538684735085 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 266.81178264853395 199.8L 266.81178264853395 141.858Q 266.81178264853395 141.858 266.81178264853395 141.858L 272.94538684735085 141.858Q 272.94538684735085 141.858 272.94538684735085 141.858L 272.94538684735085 141.858L 272.94538684735085 199.8L 272.94538684735085 199.8z" pathFrom="M 266.81178264853395 199.8L 266.81178264853395 199.8L 272.94538684735085 199.8L 272.94538684735085 199.8L 272.94538684735085 199.8L 272.94538684735085 199.8L 272.94538684735085 199.8L 266.81178264853395 199.8" cy="141.858" cx="272.94538684735085" j="22" val="29" barHeight="57.94200000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath2973" d="M 279.0789910461677 199.8L 279.0789910461677 97.902Q 279.0789910461677 97.902 279.0789910461677 97.902L 285.2125952449846 97.902Q 285.2125952449846 97.902 285.2125952449846 97.902L 285.2125952449846 97.902L 285.2125952449846 199.8L 285.2125952449846 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 279.0789910461677 199.8L 279.0789910461677 97.902Q 279.0789910461677 97.902 279.0789910461677 97.902L 285.2125952449846 97.902Q 285.2125952449846 97.902 285.2125952449846 97.902L 285.2125952449846 97.902L 285.2125952449846 199.8L 285.2125952449846 199.8z" pathFrom="M 279.0789910461677 199.8L 279.0789910461677 199.8L 285.2125952449846 199.8L 285.2125952449846 199.8L 285.2125952449846 199.8L 285.2125952449846 199.8L 285.2125952449846 199.8L 279.0789910461677 199.8" cy="97.902" cx="285.2125952449846" j="23" val="51" barHeight="101.89800000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath2974" d="M 291.3461994438015 199.8L 291.3461994438015 119.88Q 291.3461994438015 119.88 291.3461994438015 119.88L 297.4798036426184 119.88Q 297.4798036426184 119.88 297.4798036426184 119.88L 297.4798036426184 119.88L 297.4798036426184 199.8L 297.4798036426184 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 291.3461994438015 199.8L 291.3461994438015 119.88Q 291.3461994438015 119.88 291.3461994438015 119.88L 297.4798036426184 119.88Q 297.4798036426184 119.88 297.4798036426184 119.88L 297.4798036426184 119.88L 297.4798036426184 199.8L 297.4798036426184 199.8z" pathFrom="M 291.3461994438015 199.8L 291.3461994438015 199.8L 297.4798036426184 199.8L 297.4798036426184 199.8L 297.4798036426184 199.8L 297.4798036426184 199.8L 297.4798036426184 199.8L 291.3461994438015 199.8" cy="119.88" cx="297.4798036426184" j="24" val="40" barHeight="79.92000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2975" d="M 303.6134078414352 199.8L 303.6134078414352 105.894Q 303.6134078414352 105.894 303.6134078414352 105.894L 309.7470120402521 105.894Q 309.7470120402521 105.894 309.7470120402521 105.894L 309.7470120402521 105.894L 309.7470120402521 199.8L 309.7470120402521 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 303.6134078414352 199.8L 303.6134078414352 105.894Q 303.6134078414352 105.894 303.6134078414352 105.894L 309.7470120402521 105.894Q 309.7470120402521 105.894 309.7470120402521 105.894L 309.7470120402521 105.894L 309.7470120402521 199.8L 309.7470120402521 199.8z" pathFrom="M 303.6134078414352 199.8L 303.6134078414352 199.8L 309.7470120402521 199.8L 309.7470120402521 199.8L 309.7470120402521 199.8L 309.7470120402521 199.8L 309.7470120402521 199.8L 303.6134078414352 199.8" cy="105.894" cx="309.7470120402521" j="25" val="47" barHeight="93.906" barWidth="6.133604198816873"></path><path id="SvgjsPath2976" d="M 315.88061623906896 199.8L 315.88061623906896 153.846Q 315.88061623906896 153.846 315.88061623906896 153.846L 322.01422043788585 153.846Q 322.01422043788585 153.846 322.01422043788585 153.846L 322.01422043788585 153.846L 322.01422043788585 199.8L 322.01422043788585 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 315.88061623906896 199.8L 315.88061623906896 153.846Q 315.88061623906896 153.846 315.88061623906896 153.846L 322.01422043788585 153.846Q 322.01422043788585 153.846 322.01422043788585 153.846L 322.01422043788585 153.846L 322.01422043788585 199.8L 322.01422043788585 199.8z" pathFrom="M 315.88061623906896 199.8L 315.88061623906896 199.8L 322.01422043788585 199.8L 322.01422043788585 199.8L 322.01422043788585 199.8L 322.01422043788585 199.8L 322.01422043788585 199.8L 315.88061623906896 199.8" cy="153.846" cx="322.01422043788585" j="26" val="23" barHeight="45.95400000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath2977" d="M 328.1478246367027 199.8L 328.1478246367027 147.852Q 328.1478246367027 147.852 328.1478246367027 147.852L 334.2814288355196 147.852Q 334.2814288355196 147.852 334.2814288355196 147.852L 334.2814288355196 147.852L 334.2814288355196 199.8L 334.2814288355196 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 328.1478246367027 199.8L 328.1478246367027 147.852Q 328.1478246367027 147.852 328.1478246367027 147.852L 334.2814288355196 147.852Q 334.2814288355196 147.852 334.2814288355196 147.852L 334.2814288355196 147.852L 334.2814288355196 199.8L 334.2814288355196 199.8z" pathFrom="M 328.1478246367027 199.8L 328.1478246367027 199.8L 334.2814288355196 199.8L 334.2814288355196 199.8L 334.2814288355196 199.8L 334.2814288355196 199.8L 334.2814288355196 199.8L 328.1478246367027 199.8" cy="147.852" cx="334.2814288355196" j="27" val="26" barHeight="51.94800000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath2978" d="M 340.41503303433643 199.8L 340.41503303433643 99.89999999999999Q 340.41503303433643 99.89999999999999 340.41503303433643 99.89999999999999L 346.54863723315333 99.89999999999999Q 346.54863723315333 99.89999999999999 346.54863723315333 99.89999999999999L 346.54863723315333 99.89999999999999L 346.54863723315333 199.8L 346.54863723315333 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 340.41503303433643 199.8L 340.41503303433643 99.89999999999999Q 340.41503303433643 99.89999999999999 340.41503303433643 99.89999999999999L 346.54863723315333 99.89999999999999Q 346.54863723315333 99.89999999999999 346.54863723315333 99.89999999999999L 346.54863723315333 99.89999999999999L 346.54863723315333 199.8L 346.54863723315333 199.8z" pathFrom="M 340.41503303433643 199.8L 340.41503303433643 199.8L 346.54863723315333 199.8L 346.54863723315333 199.8L 346.54863723315333 199.8L 346.54863723315333 199.8L 346.54863723315333 199.8L 340.41503303433643 199.8" cy="99.89999999999999" cx="346.54863723315333" j="28" val="50" barHeight="99.90000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2979" d="M 352.68224143197017 199.8L 352.68224143197017 147.852Q 352.68224143197017 147.852 352.68224143197017 147.852L 358.81584563078707 147.852Q 358.81584563078707 147.852 358.81584563078707 147.852L 358.81584563078707 147.852L 358.81584563078707 199.8L 358.81584563078707 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 352.68224143197017 199.8L 352.68224143197017 147.852Q 352.68224143197017 147.852 352.68224143197017 147.852L 358.81584563078707 147.852Q 358.81584563078707 147.852 358.81584563078707 147.852L 358.81584563078707 147.852L 358.81584563078707 199.8L 358.81584563078707 199.8z" pathFrom="M 352.68224143197017 199.8L 352.68224143197017 199.8L 358.81584563078707 199.8L 358.81584563078707 199.8L 358.81584563078707 199.8L 358.81584563078707 199.8L 358.81584563078707 199.8L 352.68224143197017 199.8" cy="147.852" cx="358.81584563078707" j="29" val="26" barHeight="51.94800000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath2980" d="M 364.9494498296039 199.8L 364.9494498296039 117.882Q 364.9494498296039 117.882 364.9494498296039 117.882L 371.0830540284208 117.882Q 371.0830540284208 117.882 371.0830540284208 117.882L 371.0830540284208 117.882L 371.0830540284208 199.8L 371.0830540284208 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 364.9494498296039 199.8L 364.9494498296039 117.882Q 364.9494498296039 117.882 364.9494498296039 117.882L 371.0830540284208 117.882Q 371.0830540284208 117.882 371.0830540284208 117.882L 371.0830540284208 117.882L 371.0830540284208 199.8L 371.0830540284208 199.8z" pathFrom="M 364.9494498296039 199.8L 364.9494498296039 199.8L 371.0830540284208 199.8L 371.0830540284208 199.8L 371.0830540284208 199.8L 371.0830540284208 199.8L 371.0830540284208 199.8L 364.9494498296039 199.8" cy="117.882" cx="371.0830540284208" j="30" val="41" barHeight="81.918" barWidth="6.133604198816873"></path><path id="SvgjsPath2981" d="M 377.2166582272377 199.8L 377.2166582272377 155.844Q 377.2166582272377 155.844 377.2166582272377 155.844L 383.3502624260546 155.844Q 383.3502624260546 155.844 383.3502624260546 155.844L 383.3502624260546 155.844L 383.3502624260546 199.8L 383.3502624260546 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 377.2166582272377 199.8L 377.2166582272377 155.844Q 377.2166582272377 155.844 377.2166582272377 155.844L 383.3502624260546 155.844Q 383.3502624260546 155.844 383.3502624260546 155.844L 383.3502624260546 155.844L 383.3502624260546 199.8L 383.3502624260546 199.8z" pathFrom="M 377.2166582272377 199.8L 377.2166582272377 199.8L 383.3502624260546 199.8L 383.3502624260546 199.8L 383.3502624260546 199.8L 383.3502624260546 199.8L 383.3502624260546 199.8L 377.2166582272377 199.8" cy="155.844" cx="383.3502624260546" j="31" val="22" barHeight="43.956" barWidth="6.133604198816873"></path><path id="SvgjsPath2982" d="M 389.48386662487144 199.8L 389.48386662487144 107.892Q 389.48386662487144 107.892 389.48386662487144 107.892L 395.61747082368834 107.892Q 395.61747082368834 107.892 395.61747082368834 107.892L 395.61747082368834 107.892L 395.61747082368834 199.8L 395.61747082368834 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 389.48386662487144 199.8L 389.48386662487144 107.892Q 389.48386662487144 107.892 389.48386662487144 107.892L 395.61747082368834 107.892Q 395.61747082368834 107.892 395.61747082368834 107.892L 395.61747082368834 107.892L 395.61747082368834 199.8L 395.61747082368834 199.8z" pathFrom="M 389.48386662487144 199.8L 389.48386662487144 199.8L 395.61747082368834 199.8L 395.61747082368834 199.8L 395.61747082368834 199.8L 395.61747082368834 199.8L 395.61747082368834 199.8L 389.48386662487144 199.8" cy="107.892" cx="395.61747082368834" j="32" val="46" barHeight="91.90800000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2983" d="M 401.7510750225052 199.8L 401.7510750225052 105.894Q 401.7510750225052 105.894 401.7510750225052 105.894L 407.8846792213221 105.894Q 407.8846792213221 105.894 407.8846792213221 105.894L 407.8846792213221 105.894L 407.8846792213221 199.8L 407.8846792213221 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 401.7510750225052 199.8L 401.7510750225052 105.894Q 401.7510750225052 105.894 401.7510750225052 105.894L 407.8846792213221 105.894Q 407.8846792213221 105.894 407.8846792213221 105.894L 407.8846792213221 105.894L 407.8846792213221 199.8L 407.8846792213221 199.8z" pathFrom="M 401.7510750225052 199.8L 401.7510750225052 199.8L 407.8846792213221 199.8L 407.8846792213221 199.8L 407.8846792213221 199.8L 407.8846792213221 199.8L 407.8846792213221 199.8L 401.7510750225052 199.8" cy="105.894" cx="407.8846792213221" j="33" val="47" barHeight="93.906" barWidth="6.133604198816873"></path><path id="SvgjsPath2984" d="M 414.0182834201389 199.8L 414.0182834201389 37.96199999999999Q 414.0182834201389 37.96199999999999 414.0182834201389 37.96199999999999L 420.1518876189558 37.96199999999999Q 420.1518876189558 37.96199999999999 420.1518876189558 37.96199999999999L 420.1518876189558 37.96199999999999L 420.1518876189558 199.8L 420.1518876189558 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 414.0182834201389 199.8L 414.0182834201389 37.96199999999999Q 414.0182834201389 37.96199999999999 414.0182834201389 37.96199999999999L 420.1518876189558 37.96199999999999Q 420.1518876189558 37.96199999999999 420.1518876189558 37.96199999999999L 420.1518876189558 37.96199999999999L 420.1518876189558 199.8L 420.1518876189558 199.8z" pathFrom="M 414.0182834201389 199.8L 414.0182834201389 199.8L 420.1518876189558 199.8L 420.1518876189558 199.8L 420.1518876189558 199.8L 420.1518876189558 199.8L 420.1518876189558 199.8L 414.0182834201389 199.8" cy="37.96199999999999" cx="420.1518876189558" j="34" val="81" barHeight="161.83800000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2985" d="M 426.28549181777265 199.8L 426.28549181777265 107.892Q 426.28549181777265 107.892 426.28549181777265 107.892L 432.41909601658955 107.892Q 432.41909601658955 107.892 432.41909601658955 107.892L 432.41909601658955 107.892L 432.41909601658955 199.8L 432.41909601658955 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 426.28549181777265 199.8L 426.28549181777265 107.892Q 426.28549181777265 107.892 426.28549181777265 107.892L 432.41909601658955 107.892Q 432.41909601658955 107.892 432.41909601658955 107.892L 432.41909601658955 107.892L 432.41909601658955 199.8L 432.41909601658955 199.8z" pathFrom="M 426.28549181777265 199.8L 426.28549181777265 199.8L 432.41909601658955 199.8L 432.41909601658955 199.8L 432.41909601658955 199.8L 432.41909601658955 199.8L 432.41909601658955 199.8L 426.28549181777265 199.8" cy="107.892" cx="432.41909601658955" j="35" val="46" barHeight="91.90800000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2986" d="M 438.5527002154064 199.8L 438.5527002154064 187.812Q 438.5527002154064 187.812 438.5527002154064 187.812L 444.6863044142233 187.812Q 444.6863044142233 187.812 444.6863044142233 187.812L 444.6863044142233 187.812L 444.6863044142233 199.8L 444.6863044142233 199.8z" fill="rgba(32,107,196,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="0" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 438.5527002154064 199.8L 438.5527002154064 187.812Q 438.5527002154064 187.812 438.5527002154064 187.812L 444.6863044142233 187.812Q 444.6863044142233 187.812 444.6863044142233 187.812L 444.6863044142233 187.812L 444.6863044142233 199.8L 444.6863044142233 199.8z" pathFrom="M 438.5527002154064 199.8L 438.5527002154064 199.8L 444.6863044142233 199.8L 444.6863044142233 199.8L 444.6863044142233 199.8L 444.6863044142233 199.8L 444.6863044142233 199.8L 438.5527002154064 199.8" cy="187.812" cx="444.6863044142233" j="36" val="6" barHeight="11.988000000000001" barWidth="6.133604198816873"></path></g><g id="SvgjsG2987" class="apexcharts-series" seriesName="Social" rel="2" data:realIndex="1"><path id="SvgjsPath2989" d="M -3.0668020994084366 197.80200000000002L -3.0668020994084366 193.806Q -3.0668020994084366 193.806 -3.0668020994084366 193.806L 3.0668020994084366 193.806Q 3.0668020994084366 193.806 3.0668020994084366 193.806L 3.0668020994084366 193.806L 3.0668020994084366 197.80200000000002L 3.0668020994084366 197.80200000000002z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M -3.0668020994084366 197.80200000000002L -3.0668020994084366 193.806Q -3.0668020994084366 193.806 -3.0668020994084366 193.806L 3.0668020994084366 193.806Q 3.0668020994084366 193.806 3.0668020994084366 193.806L 3.0668020994084366 193.806L 3.0668020994084366 197.80200000000002L 3.0668020994084366 197.80200000000002z" pathFrom="M -3.0668020994084366 197.80200000000002L -3.0668020994084366 197.80200000000002L 3.0668020994084366 197.80200000000002L 3.0668020994084366 197.80200000000002L 3.0668020994084366 197.80200000000002L 3.0668020994084366 197.80200000000002L 3.0668020994084366 197.80200000000002L -3.0668020994084366 197.80200000000002" cy="193.806" cx="3.066802099408437" j="0" val="2" barHeight="3.9960000000000004" barWidth="6.133604198816873"></path><path id="SvgjsPath2990" d="M 9.20040629822531 199.8L 9.20040629822531 189.81Q 9.20040629822531 189.81 9.20040629822531 189.81L 15.334010497042183 189.81Q 15.334010497042183 189.81 15.334010497042183 189.81L 15.334010497042183 189.81L 15.334010497042183 199.8L 15.334010497042183 199.8z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 9.20040629822531 199.8L 9.20040629822531 189.81Q 9.20040629822531 189.81 9.20040629822531 189.81L 15.334010497042183 189.81Q 15.334010497042183 189.81 15.334010497042183 189.81L 15.334010497042183 189.81L 15.334010497042183 199.8L 15.334010497042183 199.8z" pathFrom="M 9.20040629822531 199.8L 9.20040629822531 199.8L 15.334010497042183 199.8L 15.334010497042183 199.8L 15.334010497042183 199.8L 15.334010497042183 199.8L 15.334010497042183 199.8L 9.20040629822531 199.8" cy="189.81" cx="15.334010497042183" j="1" val="5" barHeight="9.990000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2991" d="M 21.467614695859055 199.8L 21.467614695859055 191.80800000000002Q 21.467614695859055 191.80800000000002 21.467614695859055 191.80800000000002L 27.601218894675927 191.80800000000002Q 27.601218894675927 191.80800000000002 27.601218894675927 191.80800000000002L 27.601218894675927 191.80800000000002L 27.601218894675927 199.8L 27.601218894675927 199.8z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 21.467614695859055 199.8L 21.467614695859055 191.80800000000002Q 21.467614695859055 191.80800000000002 21.467614695859055 191.80800000000002L 27.601218894675927 191.80800000000002Q 27.601218894675927 191.80800000000002 27.601218894675927 191.80800000000002L 27.601218894675927 191.80800000000002L 27.601218894675927 199.8L 27.601218894675927 199.8z" pathFrom="M 21.467614695859055 199.8L 21.467614695859055 199.8L 27.601218894675927 199.8L 27.601218894675927 199.8L 27.601218894675927 199.8L 27.601218894675927 199.8L 27.601218894675927 199.8L 21.467614695859055 199.8" cy="191.80800000000002" cx="27.601218894675927" j="2" val="4" barHeight="7.992000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath2992" d="M 33.73482309349281 199.8L 33.73482309349281 193.806Q 33.73482309349281 193.806 33.73482309349281 193.806L 39.86842729230968 193.806Q 39.86842729230968 193.806 39.86842729230968 193.806L 39.86842729230968 193.806L 39.86842729230968 199.8L 39.86842729230968 199.8z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 33.73482309349281 199.8L 33.73482309349281 193.806Q 33.73482309349281 193.806 33.73482309349281 193.806L 39.86842729230968 193.806Q 39.86842729230968 193.806 39.86842729230968 193.806L 39.86842729230968 193.806L 39.86842729230968 199.8L 39.86842729230968 199.8z" pathFrom="M 33.73482309349281 199.8L 33.73482309349281 199.8L 39.86842729230968 199.8L 39.86842729230968 199.8L 39.86842729230968 199.8L 39.86842729230968 199.8L 39.86842729230968 199.8L 33.73482309349281 199.8" cy="193.806" cx="39.86842729230968" j="3" val="3" barHeight="5.994000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath2993" d="M 46.00203149112655 199.8L 46.00203149112655 193.806Q 46.00203149112655 193.806 46.00203149112655 193.806L 52.13563568994343 193.806Q 52.13563568994343 193.806 52.13563568994343 193.806L 52.13563568994343 193.806L 52.13563568994343 199.8L 52.13563568994343 199.8z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 46.00203149112655 199.8L 46.00203149112655 193.806Q 46.00203149112655 193.806 46.00203149112655 193.806L 52.13563568994343 193.806Q 52.13563568994343 193.806 52.13563568994343 193.806L 52.13563568994343 193.806L 52.13563568994343 199.8L 52.13563568994343 199.8z" pathFrom="M 46.00203149112655 199.8L 46.00203149112655 199.8L 52.13563568994343 199.8L 52.13563568994343 199.8L 52.13563568994343 199.8L 52.13563568994343 199.8L 52.13563568994343 199.8L 46.00203149112655 199.8" cy="193.806" cx="52.13563568994343" j="4" val="3" barHeight="5.994000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath2994" d="M 58.269239888760296 197.80200000000002L 58.269239888760296 195.80400000000003Q 58.269239888760296 195.80400000000003 58.269239888760296 195.80400000000003L 64.40284408757717 195.80400000000003Q 64.40284408757717 195.80400000000003 64.40284408757717 195.80400000000003L 64.40284408757717 195.80400000000003L 64.40284408757717 197.80200000000002L 64.40284408757717 197.80200000000002z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 58.269239888760296 197.80200000000002L 58.269239888760296 195.80400000000003Q 58.269239888760296 195.80400000000003 58.269239888760296 195.80400000000003L 64.40284408757717 195.80400000000003Q 64.40284408757717 195.80400000000003 64.40284408757717 195.80400000000003L 64.40284408757717 195.80400000000003L 64.40284408757717 197.80200000000002L 64.40284408757717 197.80200000000002z" pathFrom="M 58.269239888760296 197.80200000000002L 58.269239888760296 197.80200000000002L 64.40284408757717 197.80200000000002L 64.40284408757717 197.80200000000002L 64.40284408757717 197.80200000000002L 64.40284408757717 197.80200000000002L 64.40284408757717 197.80200000000002L 58.269239888760296 197.80200000000002" cy="195.80400000000003" cx="64.40284408757718" j="5" val="1" barHeight="1.9980000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2995" d="M 70.53644828639405 197.80200000000002L 70.53644828639405 189.81000000000003Q 70.53644828639405 189.81000000000003 70.53644828639405 189.81000000000003L 76.67005248521092 189.81000000000003Q 76.67005248521092 189.81000000000003 76.67005248521092 189.81000000000003L 76.67005248521092 189.81000000000003L 76.67005248521092 197.80200000000002L 76.67005248521092 197.80200000000002z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 70.53644828639405 197.80200000000002L 70.53644828639405 189.81000000000003Q 70.53644828639405 189.81000000000003 70.53644828639405 189.81000000000003L 76.67005248521092 189.81000000000003Q 76.67005248521092 189.81000000000003 76.67005248521092 189.81000000000003L 76.67005248521092 189.81000000000003L 76.67005248521092 197.80200000000002L 76.67005248521092 197.80200000000002z" pathFrom="M 70.53644828639405 197.80200000000002L 70.53644828639405 197.80200000000002L 76.67005248521092 197.80200000000002L 76.67005248521092 197.80200000000002L 76.67005248521092 197.80200000000002L 76.67005248521092 197.80200000000002L 76.67005248521092 197.80200000000002L 70.53644828639405 197.80200000000002" cy="189.81000000000003" cx="76.67005248521092" j="6" val="4" barHeight="7.992000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath2996" d="M 82.80365668402779 199.8L 82.80365668402779 185.81400000000002Q 82.80365668402779 185.81400000000002 82.80365668402779 185.81400000000002L 88.93726088284465 185.81400000000002Q 88.93726088284465 185.81400000000002 88.93726088284465 185.81400000000002L 88.93726088284465 185.81400000000002L 88.93726088284465 199.8L 88.93726088284465 199.8z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 82.80365668402779 199.8L 82.80365668402779 185.81400000000002Q 82.80365668402779 185.81400000000002 82.80365668402779 185.81400000000002L 88.93726088284465 185.81400000000002Q 88.93726088284465 185.81400000000002 88.93726088284465 185.81400000000002L 88.93726088284465 185.81400000000002L 88.93726088284465 199.8L 88.93726088284465 199.8z" pathFrom="M 82.80365668402779 199.8L 82.80365668402779 199.8L 88.93726088284465 199.8L 88.93726088284465 199.8L 88.93726088284465 199.8L 88.93726088284465 199.8L 88.93726088284465 199.8L 82.80365668402779 199.8" cy="185.81400000000002" cx="88.93726088284465" j="7" val="7" barHeight="13.986000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2997" d="M 95.07086508166154 199.8L 95.07086508166154 189.81Q 95.07086508166154 189.81 95.07086508166154 189.81L 101.2044692804784 189.81Q 101.2044692804784 189.81 101.2044692804784 189.81L 101.2044692804784 189.81L 101.2044692804784 199.8L 101.2044692804784 199.8z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 95.07086508166154 199.8L 95.07086508166154 189.81Q 95.07086508166154 189.81 95.07086508166154 189.81L 101.2044692804784 189.81Q 101.2044692804784 189.81 101.2044692804784 189.81L 101.2044692804784 189.81L 101.2044692804784 199.8L 101.2044692804784 199.8z" pathFrom="M 95.07086508166154 199.8L 95.07086508166154 199.8L 101.2044692804784 199.8L 101.2044692804784 199.8L 101.2044692804784 199.8L 101.2044692804784 199.8L 101.2044692804784 199.8L 95.07086508166154 199.8" cy="189.81" cx="101.2044692804784" j="8" val="5" barHeight="9.990000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2998" d="M 107.33807347929528 199.8L 107.33807347929528 197.80200000000002Q 107.33807347929528 197.80200000000002 107.33807347929528 197.80200000000002L 113.47167767811214 197.80200000000002Q 113.47167767811214 197.80200000000002 113.47167767811214 197.80200000000002L 113.47167767811214 197.80200000000002L 113.47167767811214 199.8L 113.47167767811214 199.8z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 107.33807347929528 199.8L 107.33807347929528 197.80200000000002Q 107.33807347929528 197.80200000000002 107.33807347929528 197.80200000000002L 113.47167767811214 197.80200000000002Q 113.47167767811214 197.80200000000002 113.47167767811214 197.80200000000002L 113.47167767811214 197.80200000000002L 113.47167767811214 199.8L 113.47167767811214 199.8z" pathFrom="M 107.33807347929528 199.8L 107.33807347929528 199.8L 113.47167767811214 199.8L 113.47167767811214 199.8L 113.47167767811214 199.8L 113.47167767811214 199.8L 113.47167767811214 199.8L 107.33807347929528 199.8" cy="197.80200000000002" cx="113.47167767811214" j="9" val="1" barHeight="1.9980000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath2999" d="M 119.60528187692903 195.804L 119.60528187692903 191.808Q 119.60528187692903 191.808 119.60528187692903 191.808L 125.7388860757459 191.808Q 125.7388860757459 191.808 125.7388860757459 191.808L 125.7388860757459 191.808L 125.7388860757459 195.804L 125.7388860757459 195.804z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 119.60528187692903 195.804L 119.60528187692903 191.808Q 119.60528187692903 191.808 119.60528187692903 191.808L 125.7388860757459 191.808Q 125.7388860757459 191.808 125.7388860757459 191.808L 125.7388860757459 191.808L 125.7388860757459 195.804L 125.7388860757459 195.804z" pathFrom="M 119.60528187692903 195.804L 119.60528187692903 195.804L 125.7388860757459 195.804L 125.7388860757459 195.804L 125.7388860757459 195.804L 125.7388860757459 195.804L 125.7388860757459 195.804L 119.60528187692903 195.804" cy="191.808" cx="125.7388860757459" j="10" val="2" barHeight="3.9960000000000004" barWidth="6.133604198816873"></path><path id="SvgjsPath3000" d="M 131.87249027456275 175.824L 131.87249027456275 165.834Q 131.87249027456275 165.834 131.87249027456275 165.834L 138.00609447337962 165.834Q 138.00609447337962 165.834 138.00609447337962 165.834L 138.00609447337962 165.834L 138.00609447337962 175.824L 138.00609447337962 175.824z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 131.87249027456275 175.824L 131.87249027456275 165.834Q 131.87249027456275 165.834 131.87249027456275 165.834L 138.00609447337962 165.834Q 138.00609447337962 165.834 138.00609447337962 165.834L 138.00609447337962 165.834L 138.00609447337962 175.824L 138.00609447337962 175.824z" pathFrom="M 131.87249027456275 175.824L 131.87249027456275 175.824L 138.00609447337962 175.824L 138.00609447337962 175.824L 138.00609447337962 175.824L 138.00609447337962 175.824L 138.00609447337962 175.824L 131.87249027456275 175.824" cy="165.834" cx="138.00609447337962" j="11" val="5" barHeight="9.990000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3001" d="M 144.13969867219652 189.81L 144.13969867219652 183.816Q 144.13969867219652 183.816 144.13969867219652 183.816L 150.27330287101339 183.816Q 150.27330287101339 183.816 150.27330287101339 183.816L 150.27330287101339 183.816L 150.27330287101339 189.81L 150.27330287101339 189.81z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 144.13969867219652 189.81L 144.13969867219652 183.816Q 144.13969867219652 183.816 144.13969867219652 183.816L 150.27330287101339 183.816Q 150.27330287101339 183.816 150.27330287101339 183.816L 150.27330287101339 183.816L 150.27330287101339 189.81L 150.27330287101339 189.81z" pathFrom="M 144.13969867219652 189.81L 144.13969867219652 189.81L 150.27330287101339 189.81L 150.27330287101339 189.81L 150.27330287101339 189.81L 150.27330287101339 189.81L 150.27330287101339 189.81L 144.13969867219652 189.81" cy="183.816" cx="150.27330287101339" j="12" val="3" barHeight="5.994000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3002" d="M 156.40690706983025 183.816L 156.40690706983025 179.82Q 156.40690706983025 179.82 156.40690706983025 179.82L 162.54051126864712 179.82Q 162.54051126864712 179.82 162.54051126864712 179.82L 162.54051126864712 179.82L 162.54051126864712 183.816L 162.54051126864712 183.816z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 156.40690706983025 183.816L 156.40690706983025 179.82Q 156.40690706983025 179.82 156.40690706983025 179.82L 162.54051126864712 179.82Q 162.54051126864712 179.82 162.54051126864712 179.82L 162.54051126864712 179.82L 162.54051126864712 183.816L 162.54051126864712 183.816z" pathFrom="M 156.40690706983025 183.816L 156.40690706983025 183.816L 162.54051126864712 183.816L 162.54051126864712 183.816L 162.54051126864712 183.816L 162.54051126864712 183.816L 162.54051126864712 183.816L 156.40690706983025 183.816" cy="179.82" cx="162.54051126864712" j="13" val="2" barHeight="3.9960000000000004" barWidth="6.133604198816873"></path><path id="SvgjsPath3003" d="M 168.674115467464 155.844L 168.674115467464 143.856Q 168.674115467464 143.856 168.674115467464 143.856L 174.80771966628086 143.856Q 174.80771966628086 143.856 174.80771966628086 143.856L 174.80771966628086 143.856L 174.80771966628086 155.844L 174.80771966628086 155.844z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 168.674115467464 155.844L 168.674115467464 143.856Q 168.674115467464 143.856 168.674115467464 143.856L 174.80771966628086 143.856Q 174.80771966628086 143.856 174.80771966628086 143.856L 174.80771966628086 143.856L 174.80771966628086 155.844L 174.80771966628086 155.844z" pathFrom="M 168.674115467464 155.844L 168.674115467464 155.844L 174.80771966628086 155.844L 174.80771966628086 155.844L 174.80771966628086 155.844L 174.80771966628086 155.844L 174.80771966628086 155.844L 168.674115467464 155.844" cy="143.856" cx="174.80771966628086" j="14" val="6" barHeight="11.988000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3004" d="M 180.94132386509773 187.812L 180.94132386509773 173.82600000000002Q 180.94132386509773 173.82600000000002 180.94132386509773 173.82600000000002L 187.0749280639146 173.82600000000002Q 187.0749280639146 173.82600000000002 187.0749280639146 173.82600000000002L 187.0749280639146 173.82600000000002L 187.0749280639146 187.812L 187.0749280639146 187.812z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 180.94132386509773 187.812L 180.94132386509773 173.82600000000002Q 180.94132386509773 173.82600000000002 180.94132386509773 173.82600000000002L 187.0749280639146 173.82600000000002Q 187.0749280639146 173.82600000000002 187.0749280639146 173.82600000000002L 187.0749280639146 173.82600000000002L 187.0749280639146 187.812L 187.0749280639146 187.812z" pathFrom="M 180.94132386509773 187.812L 180.94132386509773 187.812L 187.0749280639146 187.812L 187.0749280639146 187.812L 187.0749280639146 187.812L 187.0749280639146 187.812L 187.0749280639146 187.812L 180.94132386509773 187.812" cy="173.82600000000002" cx="187.0749280639146" j="15" val="7" barHeight="13.986000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3005" d="M 193.2085322627315 183.816L 193.2085322627315 169.83Q 193.2085322627315 169.83 193.2085322627315 169.83L 199.34213646154836 169.83Q 199.34213646154836 169.83 199.34213646154836 169.83L 199.34213646154836 169.83L 199.34213646154836 183.816L 199.34213646154836 183.816z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 193.2085322627315 183.816L 193.2085322627315 169.83Q 193.2085322627315 169.83 193.2085322627315 169.83L 199.34213646154836 169.83Q 199.34213646154836 169.83 199.34213646154836 169.83L 199.34213646154836 169.83L 199.34213646154836 183.816L 199.34213646154836 183.816z" pathFrom="M 193.2085322627315 183.816L 193.2085322627315 183.816L 199.34213646154836 183.816L 199.34213646154836 183.816L 199.34213646154836 183.816L 199.34213646154836 183.816L 199.34213646154836 183.816L 193.2085322627315 183.816" cy="169.83" cx="199.34213646154836" j="16" val="7" barHeight="13.986000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3006" d="M 205.47574066036523 187.812L 205.47574066036523 185.81400000000002Q 205.47574066036523 185.81400000000002 205.47574066036523 185.81400000000002L 211.6093448591821 185.81400000000002Q 211.6093448591821 185.81400000000002 211.6093448591821 185.81400000000002L 211.6093448591821 185.81400000000002L 211.6093448591821 187.812L 211.6093448591821 187.812z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 205.47574066036523 187.812L 205.47574066036523 185.81400000000002Q 205.47574066036523 185.81400000000002 205.47574066036523 185.81400000000002L 211.6093448591821 185.81400000000002Q 211.6093448591821 185.81400000000002 211.6093448591821 185.81400000000002L 211.6093448591821 185.81400000000002L 211.6093448591821 187.812L 211.6093448591821 187.812z" pathFrom="M 205.47574066036523 187.812L 205.47574066036523 187.812L 211.6093448591821 187.812L 211.6093448591821 187.812L 211.6093448591821 187.812L 211.6093448591821 187.812L 211.6093448591821 187.812L 205.47574066036523 187.812" cy="185.81400000000002" cx="211.6093448591821" j="17" val="1" barHeight="1.9980000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3007" d="M 217.74294905799897 191.80800000000002L 217.74294905799897 181.818Q 217.74294905799897 181.818 217.74294905799897 181.818L 223.87655325681584 181.818Q 223.87655325681584 181.818 223.87655325681584 181.818L 223.87655325681584 181.818L 223.87655325681584 191.80800000000002L 223.87655325681584 191.80800000000002z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 217.74294905799897 191.80800000000002L 217.74294905799897 181.818Q 217.74294905799897 181.818 217.74294905799897 181.818L 223.87655325681584 181.818Q 223.87655325681584 181.818 223.87655325681584 181.818L 223.87655325681584 181.818L 223.87655325681584 191.80800000000002L 223.87655325681584 191.80800000000002z" pathFrom="M 217.74294905799897 191.80800000000002L 217.74294905799897 191.80800000000002L 223.87655325681584 191.80800000000002L 223.87655325681584 191.80800000000002L 223.87655325681584 191.80800000000002L 223.87655325681584 191.80800000000002L 223.87655325681584 191.80800000000002L 217.74294905799897 191.80800000000002" cy="181.818" cx="223.87655325681584" j="18" val="5" barHeight="9.990000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3008" d="M 230.01015745563274 197.80200000000002L 230.01015745563274 187.812Q 230.01015745563274 187.812 230.01015745563274 187.812L 236.1437616544496 187.812Q 236.1437616544496 187.812 236.1437616544496 187.812L 236.1437616544496 187.812L 236.1437616544496 197.80200000000002L 236.1437616544496 197.80200000000002z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 230.01015745563274 197.80200000000002L 230.01015745563274 187.812Q 230.01015745563274 187.812 230.01015745563274 187.812L 236.1437616544496 187.812Q 236.1437616544496 187.812 236.1437616544496 187.812L 236.1437616544496 187.812L 236.1437616544496 197.80200000000002L 236.1437616544496 197.80200000000002z" pathFrom="M 230.01015745563274 197.80200000000002L 230.01015745563274 197.80200000000002L 236.1437616544496 197.80200000000002L 236.1437616544496 197.80200000000002L 236.1437616544496 197.80200000000002L 236.1437616544496 197.80200000000002L 236.1437616544496 197.80200000000002L 230.01015745563274 197.80200000000002" cy="187.812" cx="236.1437616544496" j="19" val="5" barHeight="9.990000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3009" d="M 242.27736585326647 183.816L 242.27736585326647 179.82Q 242.27736585326647 179.82 242.27736585326647 179.82L 248.41097005208334 179.82Q 248.41097005208334 179.82 248.41097005208334 179.82L 248.41097005208334 179.82L 248.41097005208334 183.816L 248.41097005208334 183.816z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 242.27736585326647 183.816L 242.27736585326647 179.82Q 242.27736585326647 179.82 242.27736585326647 179.82L 248.41097005208334 179.82Q 248.41097005208334 179.82 248.41097005208334 179.82L 248.41097005208334 179.82L 248.41097005208334 183.816L 248.41097005208334 183.816z" pathFrom="M 242.27736585326647 183.816L 242.27736585326647 183.816L 248.41097005208334 183.816L 248.41097005208334 183.816L 248.41097005208334 183.816L 248.41097005208334 183.816L 248.41097005208334 183.816L 242.27736585326647 183.816" cy="179.82" cx="248.41097005208334" j="20" val="2" barHeight="3.9960000000000004" barWidth="6.133604198816873"></path><path id="SvgjsPath3010" d="M 254.5445742509002 151.848L 254.5445742509002 127.87200000000001Q 254.5445742509002 127.87200000000001 254.5445742509002 127.87200000000001L 260.6781784497171 127.87200000000001Q 260.6781784497171 127.87200000000001 260.6781784497171 127.87200000000001L 260.6781784497171 127.87200000000001L 260.6781784497171 151.848L 260.6781784497171 151.848z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 254.5445742509002 151.848L 254.5445742509002 127.87200000000001Q 254.5445742509002 127.87200000000001 254.5445742509002 127.87200000000001L 260.6781784497171 127.87200000000001Q 260.6781784497171 127.87200000000001 260.6781784497171 127.87200000000001L 260.6781784497171 127.87200000000001L 260.6781784497171 151.848L 260.6781784497171 151.848z" pathFrom="M 254.5445742509002 151.848L 254.5445742509002 151.848L 260.6781784497171 151.848L 260.6781784497171 151.848L 260.6781784497171 151.848L 260.6781784497171 151.848L 260.6781784497171 151.848L 254.5445742509002 151.848" cy="127.87200000000001" cx="260.6781784497171" j="21" val="12" barHeight="23.976000000000003" barWidth="6.133604198816873"></path><path id="SvgjsPath3011" d="M 266.81178264853395 141.858L 266.81178264853395 133.866Q 266.81178264853395 133.866 266.81178264853395 133.866L 272.94538684735085 133.866Q 272.94538684735085 133.866 272.94538684735085 133.866L 272.94538684735085 133.866L 272.94538684735085 141.858L 272.94538684735085 141.858z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 266.81178264853395 141.858L 266.81178264853395 133.866Q 266.81178264853395 133.866 266.81178264853395 133.866L 272.94538684735085 133.866Q 272.94538684735085 133.866 272.94538684735085 133.866L 272.94538684735085 133.866L 272.94538684735085 141.858L 272.94538684735085 141.858z" pathFrom="M 266.81178264853395 141.858L 266.81178264853395 141.858L 272.94538684735085 141.858L 272.94538684735085 141.858L 272.94538684735085 141.858L 272.94538684735085 141.858L 272.94538684735085 141.858L 266.81178264853395 141.858" cy="133.866" cx="272.94538684735085" j="22" val="4" barHeight="7.992000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3012" d="M 279.0789910461677 97.902L 279.0789910461677 85.914Q 279.0789910461677 85.914 279.0789910461677 85.914L 285.2125952449846 85.914Q 285.2125952449846 85.914 285.2125952449846 85.914L 285.2125952449846 85.914L 285.2125952449846 97.902L 285.2125952449846 97.902z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 279.0789910461677 97.902L 279.0789910461677 85.914Q 279.0789910461677 85.914 279.0789910461677 85.914L 285.2125952449846 85.914Q 285.2125952449846 85.914 285.2125952449846 85.914L 285.2125952449846 85.914L 285.2125952449846 97.902L 285.2125952449846 97.902z" pathFrom="M 279.0789910461677 97.902L 279.0789910461677 97.902L 285.2125952449846 97.902L 285.2125952449846 97.902L 285.2125952449846 97.902L 285.2125952449846 97.902L 285.2125952449846 97.902L 279.0789910461677 97.902" cy="85.914" cx="285.2125952449846" j="23" val="6" barHeight="11.988000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3013" d="M 291.3461994438015 119.88L 291.3461994438015 83.916Q 291.3461994438015 83.916 291.3461994438015 83.916L 297.4798036426184 83.916Q 297.4798036426184 83.916 297.4798036426184 83.916L 297.4798036426184 83.916L 297.4798036426184 119.88L 297.4798036426184 119.88z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 291.3461994438015 119.88L 291.3461994438015 83.916Q 291.3461994438015 83.916 291.3461994438015 83.916L 297.4798036426184 83.916Q 297.4798036426184 83.916 297.4798036426184 83.916L 297.4798036426184 83.916L 297.4798036426184 119.88L 297.4798036426184 119.88z" pathFrom="M 291.3461994438015 119.88L 291.3461994438015 119.88L 297.4798036426184 119.88L 297.4798036426184 119.88L 297.4798036426184 119.88L 297.4798036426184 119.88L 297.4798036426184 119.88L 291.3461994438015 119.88" cy="83.916" cx="297.4798036426184" j="24" val="18" barHeight="35.964000000000006" barWidth="6.133604198816873"></path><path id="SvgjsPath3014" d="M 303.6134078414352 105.894L 303.6134078414352 99.9Q 303.6134078414352 99.9 303.6134078414352 99.9L 309.7470120402521 99.9Q 309.7470120402521 99.9 309.7470120402521 99.9L 309.7470120402521 99.9L 309.7470120402521 105.894L 309.7470120402521 105.894z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 303.6134078414352 105.894L 303.6134078414352 99.9Q 303.6134078414352 99.9 303.6134078414352 99.9L 309.7470120402521 99.9Q 309.7470120402521 99.9 309.7470120402521 99.9L 309.7470120402521 99.9L 309.7470120402521 105.894L 309.7470120402521 105.894z" pathFrom="M 303.6134078414352 105.894L 303.6134078414352 105.894L 309.7470120402521 105.894L 309.7470120402521 105.894L 309.7470120402521 105.894L 309.7470120402521 105.894L 309.7470120402521 105.894L 303.6134078414352 105.894" cy="99.9" cx="309.7470120402521" j="25" val="3" barHeight="5.994000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3015" d="M 315.88061623906896 153.846L 315.88061623906896 143.856Q 315.88061623906896 143.856 315.88061623906896 143.856L 322.01422043788585 143.856Q 322.01422043788585 143.856 322.01422043788585 143.856L 322.01422043788585 143.856L 322.01422043788585 153.846L 322.01422043788585 153.846z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 315.88061623906896 153.846L 315.88061623906896 143.856Q 315.88061623906896 143.856 315.88061623906896 143.856L 322.01422043788585 143.856Q 322.01422043788585 143.856 322.01422043788585 143.856L 322.01422043788585 143.856L 322.01422043788585 153.846L 322.01422043788585 153.846z" pathFrom="M 315.88061623906896 153.846L 315.88061623906896 153.846L 322.01422043788585 153.846L 322.01422043788585 153.846L 322.01422043788585 153.846L 322.01422043788585 153.846L 322.01422043788585 153.846L 315.88061623906896 153.846" cy="143.856" cx="322.01422043788585" j="26" val="5" barHeight="9.990000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3016" d="M 328.1478246367027 147.852L 328.1478246367027 143.856Q 328.1478246367027 143.856 328.1478246367027 143.856L 334.2814288355196 143.856Q 334.2814288355196 143.856 334.2814288355196 143.856L 334.2814288355196 143.856L 334.2814288355196 147.852L 334.2814288355196 147.852z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 328.1478246367027 147.852L 328.1478246367027 143.856Q 328.1478246367027 143.856 328.1478246367027 143.856L 334.2814288355196 143.856Q 334.2814288355196 143.856 334.2814288355196 143.856L 334.2814288355196 143.856L 334.2814288355196 147.852L 334.2814288355196 147.852z" pathFrom="M 328.1478246367027 147.852L 328.1478246367027 147.852L 334.2814288355196 147.852L 334.2814288355196 147.852L 334.2814288355196 147.852L 334.2814288355196 147.852L 334.2814288355196 147.852L 328.1478246367027 147.852" cy="143.856" cx="334.2814288355196" j="27" val="2" barHeight="3.9960000000000004" barWidth="6.133604198816873"></path><path id="SvgjsPath3017" d="M 340.41503303433643 99.89999999999999L 340.41503303433643 73.92599999999999Q 340.41503303433643 73.92599999999999 340.41503303433643 73.92599999999999L 346.54863723315333 73.92599999999999Q 346.54863723315333 73.92599999999999 346.54863723315333 73.92599999999999L 346.54863723315333 73.92599999999999L 346.54863723315333 99.89999999999999L 346.54863723315333 99.89999999999999z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 340.41503303433643 99.89999999999999L 340.41503303433643 73.92599999999999Q 340.41503303433643 73.92599999999999 340.41503303433643 73.92599999999999L 346.54863723315333 73.92599999999999Q 346.54863723315333 73.92599999999999 346.54863723315333 73.92599999999999L 346.54863723315333 73.92599999999999L 346.54863723315333 99.89999999999999L 346.54863723315333 99.89999999999999z" pathFrom="M 340.41503303433643 99.89999999999999L 340.41503303433643 99.89999999999999L 346.54863723315333 99.89999999999999L 346.54863723315333 99.89999999999999L 346.54863723315333 99.89999999999999L 346.54863723315333 99.89999999999999L 346.54863723315333 99.89999999999999L 340.41503303433643 99.89999999999999" cy="73.92599999999999" cx="346.54863723315333" j="28" val="13" barHeight="25.974000000000004" barWidth="6.133604198816873"></path><path id="SvgjsPath3018" d="M 352.68224143197017 147.852L 352.68224143197017 117.882Q 352.68224143197017 117.882 352.68224143197017 117.882L 358.81584563078707 117.882Q 358.81584563078707 117.882 358.81584563078707 117.882L 358.81584563078707 117.882L 358.81584563078707 147.852L 358.81584563078707 147.852z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 352.68224143197017 147.852L 352.68224143197017 117.882Q 352.68224143197017 117.882 352.68224143197017 117.882L 358.81584563078707 117.882Q 358.81584563078707 117.882 358.81584563078707 117.882L 358.81584563078707 117.882L 358.81584563078707 147.852L 358.81584563078707 147.852z" pathFrom="M 352.68224143197017 147.852L 352.68224143197017 147.852L 358.81584563078707 147.852L 358.81584563078707 147.852L 358.81584563078707 147.852L 358.81584563078707 147.852L 358.81584563078707 147.852L 352.68224143197017 147.852" cy="117.882" cx="358.81584563078707" j="29" val="15" barHeight="29.970000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3019" d="M 364.9494498296039 117.882L 364.9494498296039 77.922Q 364.9494498296039 77.922 364.9494498296039 77.922L 371.0830540284208 77.922Q 371.0830540284208 77.922 371.0830540284208 77.922L 371.0830540284208 77.922L 371.0830540284208 117.882L 371.0830540284208 117.882z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 364.9494498296039 117.882L 364.9494498296039 77.922Q 364.9494498296039 77.922 364.9494498296039 77.922L 371.0830540284208 77.922Q 371.0830540284208 77.922 371.0830540284208 77.922L 371.0830540284208 77.922L 371.0830540284208 117.882L 371.0830540284208 117.882z" pathFrom="M 364.9494498296039 117.882L 364.9494498296039 117.882L 371.0830540284208 117.882L 371.0830540284208 117.882L 371.0830540284208 117.882L 371.0830540284208 117.882L 371.0830540284208 117.882L 364.9494498296039 117.882" cy="77.922" cx="371.0830540284208" j="30" val="20" barHeight="39.96000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3020" d="M 377.2166582272377 155.844L 377.2166582272377 61.93799999999999Q 377.2166582272377 61.93799999999999 377.2166582272377 61.93799999999999L 383.3502624260546 61.93799999999999Q 383.3502624260546 61.93799999999999 383.3502624260546 61.93799999999999L 383.3502624260546 61.93799999999999L 383.3502624260546 155.844L 383.3502624260546 155.844z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 377.2166582272377 155.844L 377.2166582272377 61.93799999999999Q 377.2166582272377 61.93799999999999 377.2166582272377 61.93799999999999L 383.3502624260546 61.93799999999999Q 383.3502624260546 61.93799999999999 383.3502624260546 61.93799999999999L 383.3502624260546 61.93799999999999L 383.3502624260546 155.844L 383.3502624260546 155.844z" pathFrom="M 377.2166582272377 155.844L 377.2166582272377 155.844L 383.3502624260546 155.844L 383.3502624260546 155.844L 383.3502624260546 155.844L 383.3502624260546 155.844L 383.3502624260546 155.844L 377.2166582272377 155.844" cy="61.93799999999999" cx="383.3502624260546" j="31" val="47" barHeight="93.906" barWidth="6.133604198816873"></path><path id="SvgjsPath3021" d="M 389.48386662487144 107.892L 389.48386662487144 71.928Q 389.48386662487144 71.928 389.48386662487144 71.928L 395.61747082368834 71.928Q 395.61747082368834 71.928 395.61747082368834 71.928L 395.61747082368834 71.928L 395.61747082368834 107.892L 395.61747082368834 107.892z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 389.48386662487144 107.892L 389.48386662487144 71.928Q 389.48386662487144 71.928 389.48386662487144 71.928L 395.61747082368834 71.928Q 395.61747082368834 71.928 395.61747082368834 71.928L 395.61747082368834 71.928L 395.61747082368834 107.892L 395.61747082368834 107.892z" pathFrom="M 389.48386662487144 107.892L 389.48386662487144 107.892L 395.61747082368834 107.892L 395.61747082368834 107.892L 395.61747082368834 107.892L 395.61747082368834 107.892L 395.61747082368834 107.892L 389.48386662487144 107.892" cy="71.928" cx="395.61747082368834" j="32" val="18" barHeight="35.964000000000006" barWidth="6.133604198816873"></path><path id="SvgjsPath3022" d="M 401.7510750225052 105.894L 401.7510750225052 75.924Q 401.7510750225052 75.924 401.7510750225052 75.924L 407.8846792213221 75.924Q 407.8846792213221 75.924 407.8846792213221 75.924L 407.8846792213221 75.924L 407.8846792213221 105.894L 407.8846792213221 105.894z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 401.7510750225052 105.894L 401.7510750225052 75.924Q 401.7510750225052 75.924 401.7510750225052 75.924L 407.8846792213221 75.924Q 407.8846792213221 75.924 407.8846792213221 75.924L 407.8846792213221 75.924L 407.8846792213221 105.894L 407.8846792213221 105.894z" pathFrom="M 401.7510750225052 105.894L 401.7510750225052 105.894L 407.8846792213221 105.894L 407.8846792213221 105.894L 407.8846792213221 105.894L 407.8846792213221 105.894L 407.8846792213221 105.894L 401.7510750225052 105.894" cy="75.924" cx="407.8846792213221" j="33" val="15" barHeight="29.970000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3023" d="M 414.0182834201389 37.96199999999999L 414.0182834201389 15.983999999999988Q 414.0182834201389 15.983999999999988 414.0182834201389 15.983999999999988L 420.1518876189558 15.983999999999988Q 420.1518876189558 15.983999999999988 420.1518876189558 15.983999999999988L 420.1518876189558 15.983999999999988L 420.1518876189558 37.96199999999999L 420.1518876189558 37.96199999999999z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 414.0182834201389 37.96199999999999L 414.0182834201389 15.983999999999988Q 414.0182834201389 15.983999999999988 414.0182834201389 15.983999999999988L 420.1518876189558 15.983999999999988Q 420.1518876189558 15.983999999999988 420.1518876189558 15.983999999999988L 420.1518876189558 15.983999999999988L 420.1518876189558 37.96199999999999L 420.1518876189558 37.96199999999999z" pathFrom="M 414.0182834201389 37.96199999999999L 414.0182834201389 37.96199999999999L 420.1518876189558 37.96199999999999L 420.1518876189558 37.96199999999999L 420.1518876189558 37.96199999999999L 420.1518876189558 37.96199999999999L 420.1518876189558 37.96199999999999L 414.0182834201389 37.96199999999999" cy="15.983999999999988" cx="420.1518876189558" j="34" val="11" barHeight="21.978" barWidth="6.133604198816873"></path><path id="SvgjsPath3024" d="M 426.28549181777265 107.892L 426.28549181777265 87.91199999999999Q 426.28549181777265 87.91199999999999 426.28549181777265 87.91199999999999L 432.41909601658955 87.91199999999999Q 432.41909601658955 87.91199999999999 432.41909601658955 87.91199999999999L 432.41909601658955 87.91199999999999L 432.41909601658955 107.892L 432.41909601658955 107.892z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 426.28549181777265 107.892L 426.28549181777265 87.91199999999999Q 426.28549181777265 87.91199999999999 426.28549181777265 87.91199999999999L 432.41909601658955 87.91199999999999Q 432.41909601658955 87.91199999999999 432.41909601658955 87.91199999999999L 432.41909601658955 87.91199999999999L 432.41909601658955 107.892L 432.41909601658955 107.892z" pathFrom="M 426.28549181777265 107.892L 426.28549181777265 107.892L 432.41909601658955 107.892L 432.41909601658955 107.892L 432.41909601658955 107.892L 432.41909601658955 107.892L 432.41909601658955 107.892L 426.28549181777265 107.892" cy="87.91199999999999" cx="432.41909601658955" j="35" val="10" barHeight="19.980000000000004" barWidth="6.133604198816873"></path><path id="SvgjsPath3025" d="M 438.5527002154064 187.812L 438.5527002154064 187.812Q 438.5527002154064 187.812 438.5527002154064 187.812L 444.6863044142233 187.812Q 444.6863044142233 187.812 444.6863044142233 187.812L 444.6863044142233 187.812L 444.6863044142233 187.812L 444.6863044142233 187.812z" fill="rgba(121,166,220,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="1" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 438.5527002154064 187.812L 438.5527002154064 187.812Q 438.5527002154064 187.812 438.5527002154064 187.812L 444.6863044142233 187.812Q 444.6863044142233 187.812 444.6863044142233 187.812L 444.6863044142233 187.812L 444.6863044142233 187.812L 444.6863044142233 187.812z" pathFrom="M 438.5527002154064 187.812L 438.5527002154064 187.812L 444.6863044142233 187.812L 444.6863044142233 187.812L 444.6863044142233 187.812L 444.6863044142233 187.812L 444.6863044142233 187.812L 438.5527002154064 187.812" cy="187.812" cx="444.6863044142233" j="36" val="0" barHeight="0" barWidth="6.133604198816873"></path></g><g id="SvgjsG3026" class="apexcharts-series" seriesName="Other" rel="3" data:realIndex="2"><path id="SvgjsPath3028" d="M -3.0668020994084366 193.806L -3.0668020994084366 189.81Q -3.0668020994084366 189.81 -3.0668020994084366 189.81L 3.0668020994084366 189.81Q 3.0668020994084366 189.81 3.0668020994084366 189.81L 3.0668020994084366 189.81L 3.0668020994084366 193.806L 3.0668020994084366 193.806z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M -3.0668020994084366 193.806L -3.0668020994084366 189.81Q -3.0668020994084366 189.81 -3.0668020994084366 189.81L 3.0668020994084366 189.81Q 3.0668020994084366 189.81 3.0668020994084366 189.81L 3.0668020994084366 189.81L 3.0668020994084366 193.806L 3.0668020994084366 193.806z" pathFrom="M -3.0668020994084366 193.806L -3.0668020994084366 193.806L 3.0668020994084366 193.806L 3.0668020994084366 193.806L 3.0668020994084366 193.806L 3.0668020994084366 193.806L 3.0668020994084366 193.806L -3.0668020994084366 193.806" cy="189.81" cx="3.066802099408437" j="0" val="2" barHeight="3.9960000000000004" barWidth="6.133604198816873"></path><path id="SvgjsPath3029" d="M 9.20040629822531 189.81L 9.20040629822531 171.828Q 9.20040629822531 171.828 9.20040629822531 171.828L 15.334010497042183 171.828Q 15.334010497042183 171.828 15.334010497042183 171.828L 15.334010497042183 171.828L 15.334010497042183 189.81L 15.334010497042183 189.81z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 9.20040629822531 189.81L 9.20040629822531 171.828Q 9.20040629822531 171.828 9.20040629822531 171.828L 15.334010497042183 171.828Q 15.334010497042183 171.828 15.334010497042183 171.828L 15.334010497042183 171.828L 15.334010497042183 189.81L 15.334010497042183 189.81z" pathFrom="M 9.20040629822531 189.81L 9.20040629822531 189.81L 15.334010497042183 189.81L 15.334010497042183 189.81L 15.334010497042183 189.81L 15.334010497042183 189.81L 15.334010497042183 189.81L 9.20040629822531 189.81" cy="171.828" cx="15.334010497042183" j="1" val="9" barHeight="17.982000000000003" barWidth="6.133604198816873"></path><path id="SvgjsPath3030" d="M 21.467614695859055 191.80800000000002L 21.467614695859055 189.81000000000003Q 21.467614695859055 189.81000000000003 21.467614695859055 189.81000000000003L 27.601218894675927 189.81000000000003Q 27.601218894675927 189.81000000000003 27.601218894675927 189.81000000000003L 27.601218894675927 189.81000000000003L 27.601218894675927 191.80800000000002L 27.601218894675927 191.80800000000002z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 21.467614695859055 191.80800000000002L 21.467614695859055 189.81000000000003Q 21.467614695859055 189.81000000000003 21.467614695859055 189.81000000000003L 27.601218894675927 189.81000000000003Q 27.601218894675927 189.81000000000003 27.601218894675927 189.81000000000003L 27.601218894675927 189.81000000000003L 27.601218894675927 191.80800000000002L 27.601218894675927 191.80800000000002z" pathFrom="M 21.467614695859055 191.80800000000002L 21.467614695859055 191.80800000000002L 27.601218894675927 191.80800000000002L 27.601218894675927 191.80800000000002L 27.601218894675927 191.80800000000002L 27.601218894675927 191.80800000000002L 27.601218894675927 191.80800000000002L 21.467614695859055 191.80800000000002" cy="189.81000000000003" cx="27.601218894675927" j="2" val="1" barHeight="1.9980000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3031" d="M 33.73482309349281 193.806L 33.73482309349281 179.82000000000002Q 33.73482309349281 179.82000000000002 33.73482309349281 179.82000000000002L 39.86842729230968 179.82000000000002Q 39.86842729230968 179.82000000000002 39.86842729230968 179.82000000000002L 39.86842729230968 179.82000000000002L 39.86842729230968 193.806L 39.86842729230968 193.806z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 33.73482309349281 193.806L 33.73482309349281 179.82000000000002Q 33.73482309349281 179.82000000000002 33.73482309349281 179.82000000000002L 39.86842729230968 179.82000000000002Q 39.86842729230968 179.82000000000002 39.86842729230968 179.82000000000002L 39.86842729230968 179.82000000000002L 39.86842729230968 193.806L 39.86842729230968 193.806z" pathFrom="M 33.73482309349281 193.806L 33.73482309349281 193.806L 39.86842729230968 193.806L 39.86842729230968 193.806L 39.86842729230968 193.806L 39.86842729230968 193.806L 39.86842729230968 193.806L 33.73482309349281 193.806" cy="179.82000000000002" cx="39.86842729230968" j="3" val="7" barHeight="13.986000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3032" d="M 46.00203149112655 193.806L 46.00203149112655 177.822Q 46.00203149112655 177.822 46.00203149112655 177.822L 52.13563568994343 177.822Q 52.13563568994343 177.822 52.13563568994343 177.822L 52.13563568994343 177.822L 52.13563568994343 193.806L 52.13563568994343 193.806z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 46.00203149112655 193.806L 46.00203149112655 177.822Q 46.00203149112655 177.822 46.00203149112655 177.822L 52.13563568994343 177.822Q 52.13563568994343 177.822 52.13563568994343 177.822L 52.13563568994343 177.822L 52.13563568994343 193.806L 52.13563568994343 193.806z" pathFrom="M 46.00203149112655 193.806L 46.00203149112655 193.806L 52.13563568994343 193.806L 52.13563568994343 193.806L 52.13563568994343 193.806L 52.13563568994343 193.806L 52.13563568994343 193.806L 46.00203149112655 193.806" cy="177.822" cx="52.13563568994343" j="4" val="8" barHeight="15.984000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3033" d="M 58.269239888760296 195.80400000000003L 58.269239888760296 189.81000000000003Q 58.269239888760296 189.81000000000003 58.269239888760296 189.81000000000003L 64.40284408757717 189.81000000000003Q 64.40284408757717 189.81000000000003 64.40284408757717 189.81000000000003L 64.40284408757717 189.81000000000003L 64.40284408757717 195.80400000000003L 64.40284408757717 195.80400000000003z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 58.269239888760296 195.80400000000003L 58.269239888760296 189.81000000000003Q 58.269239888760296 189.81000000000003 58.269239888760296 189.81000000000003L 64.40284408757717 189.81000000000003Q 64.40284408757717 189.81000000000003 64.40284408757717 189.81000000000003L 64.40284408757717 189.81000000000003L 64.40284408757717 195.80400000000003L 64.40284408757717 195.80400000000003z" pathFrom="M 58.269239888760296 195.80400000000003L 58.269239888760296 195.80400000000003L 64.40284408757717 195.80400000000003L 64.40284408757717 195.80400000000003L 64.40284408757717 195.80400000000003L 64.40284408757717 195.80400000000003L 64.40284408757717 195.80400000000003L 58.269239888760296 195.80400000000003" cy="189.81000000000003" cx="64.40284408757718" j="5" val="3" barHeight="5.994000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3034" d="M 70.53644828639405 189.81000000000003L 70.53644828639405 177.82200000000003Q 70.53644828639405 177.82200000000003 70.53644828639405 177.82200000000003L 76.67005248521092 177.82200000000003Q 76.67005248521092 177.82200000000003 76.67005248521092 177.82200000000003L 76.67005248521092 177.82200000000003L 76.67005248521092 189.81000000000003L 76.67005248521092 189.81000000000003z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 70.53644828639405 189.81000000000003L 70.53644828639405 177.82200000000003Q 70.53644828639405 177.82200000000003 70.53644828639405 177.82200000000003L 76.67005248521092 177.82200000000003Q 76.67005248521092 177.82200000000003 76.67005248521092 177.82200000000003L 76.67005248521092 177.82200000000003L 76.67005248521092 189.81000000000003L 76.67005248521092 189.81000000000003z" pathFrom="M 70.53644828639405 189.81000000000003L 70.53644828639405 189.81000000000003L 76.67005248521092 189.81000000000003L 76.67005248521092 189.81000000000003L 76.67005248521092 189.81000000000003L 76.67005248521092 189.81000000000003L 76.67005248521092 189.81000000000003L 70.53644828639405 189.81000000000003" cy="177.82200000000003" cx="76.67005248521092" j="6" val="6" barHeight="11.988000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3035" d="M 82.80365668402779 185.81400000000002L 82.80365668402779 175.824Q 82.80365668402779 175.824 82.80365668402779 175.824L 88.93726088284465 175.824Q 88.93726088284465 175.824 88.93726088284465 175.824L 88.93726088284465 175.824L 88.93726088284465 185.81400000000002L 88.93726088284465 185.81400000000002z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 82.80365668402779 185.81400000000002L 82.80365668402779 175.824Q 82.80365668402779 175.824 82.80365668402779 175.824L 88.93726088284465 175.824Q 88.93726088284465 175.824 88.93726088284465 175.824L 88.93726088284465 175.824L 88.93726088284465 185.81400000000002L 88.93726088284465 185.81400000000002z" pathFrom="M 82.80365668402779 185.81400000000002L 82.80365668402779 185.81400000000002L 88.93726088284465 185.81400000000002L 88.93726088284465 185.81400000000002L 88.93726088284465 185.81400000000002L 88.93726088284465 185.81400000000002L 88.93726088284465 185.81400000000002L 82.80365668402779 185.81400000000002" cy="175.824" cx="88.93726088284465" j="7" val="5" barHeight="9.990000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3036" d="M 95.07086508166154 189.81L 95.07086508166154 179.82Q 95.07086508166154 179.82 95.07086508166154 179.82L 101.2044692804784 179.82Q 101.2044692804784 179.82 101.2044692804784 179.82L 101.2044692804784 179.82L 101.2044692804784 189.81L 101.2044692804784 189.81z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 95.07086508166154 189.81L 95.07086508166154 179.82Q 95.07086508166154 179.82 95.07086508166154 179.82L 101.2044692804784 179.82Q 101.2044692804784 179.82 101.2044692804784 179.82L 101.2044692804784 179.82L 101.2044692804784 189.81L 101.2044692804784 189.81z" pathFrom="M 95.07086508166154 189.81L 95.07086508166154 189.81L 101.2044692804784 189.81L 101.2044692804784 189.81L 101.2044692804784 189.81L 101.2044692804784 189.81L 101.2044692804784 189.81L 95.07086508166154 189.81" cy="179.82" cx="101.2044692804784" j="8" val="5" barHeight="9.990000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3037" d="M 107.33807347929528 197.80200000000002L 107.33807347929528 189.81000000000003Q 107.33807347929528 189.81000000000003 107.33807347929528 189.81000000000003L 113.47167767811214 189.81000000000003Q 113.47167767811214 189.81000000000003 113.47167767811214 189.81000000000003L 113.47167767811214 189.81000000000003L 113.47167767811214 197.80200000000002L 113.47167767811214 197.80200000000002z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 107.33807347929528 197.80200000000002L 107.33807347929528 189.81000000000003Q 107.33807347929528 189.81000000000003 107.33807347929528 189.81000000000003L 113.47167767811214 189.81000000000003Q 113.47167767811214 189.81000000000003 113.47167767811214 189.81000000000003L 113.47167767811214 189.81000000000003L 113.47167767811214 197.80200000000002L 113.47167767811214 197.80200000000002z" pathFrom="M 107.33807347929528 197.80200000000002L 107.33807347929528 197.80200000000002L 113.47167767811214 197.80200000000002L 113.47167767811214 197.80200000000002L 113.47167767811214 197.80200000000002L 113.47167767811214 197.80200000000002L 113.47167767811214 197.80200000000002L 107.33807347929528 197.80200000000002" cy="189.81000000000003" cx="113.47167767811214" j="9" val="4" barHeight="7.992000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3038" d="M 119.60528187692903 191.808L 119.60528187692903 179.82Q 119.60528187692903 179.82 119.60528187692903 179.82L 125.7388860757459 179.82Q 125.7388860757459 179.82 125.7388860757459 179.82L 125.7388860757459 179.82L 125.7388860757459 191.808L 125.7388860757459 191.808z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 119.60528187692903 191.808L 119.60528187692903 179.82Q 119.60528187692903 179.82 119.60528187692903 179.82L 125.7388860757459 179.82Q 125.7388860757459 179.82 125.7388860757459 179.82L 125.7388860757459 179.82L 125.7388860757459 191.808L 125.7388860757459 191.808z" pathFrom="M 119.60528187692903 191.808L 119.60528187692903 191.808L 125.7388860757459 191.808L 125.7388860757459 191.808L 125.7388860757459 191.808L 125.7388860757459 191.808L 125.7388860757459 191.808L 119.60528187692903 191.808" cy="179.82" cx="125.7388860757459" j="10" val="6" barHeight="11.988000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3039" d="M 131.87249027456275 165.834L 131.87249027456275 157.842Q 131.87249027456275 157.842 131.87249027456275 157.842L 138.00609447337962 157.842Q 138.00609447337962 157.842 138.00609447337962 157.842L 138.00609447337962 157.842L 138.00609447337962 165.834L 138.00609447337962 165.834z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 131.87249027456275 165.834L 131.87249027456275 157.842Q 131.87249027456275 157.842 131.87249027456275 157.842L 138.00609447337962 157.842Q 138.00609447337962 157.842 138.00609447337962 157.842L 138.00609447337962 157.842L 138.00609447337962 165.834L 138.00609447337962 165.834z" pathFrom="M 131.87249027456275 165.834L 131.87249027456275 165.834L 138.00609447337962 165.834L 138.00609447337962 165.834L 138.00609447337962 165.834L 138.00609447337962 165.834L 138.00609447337962 165.834L 131.87249027456275 165.834" cy="157.842" cx="138.00609447337962" j="11" val="4" barHeight="7.992000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3040" d="M 144.13969867219652 183.816L 144.13969867219652 181.818Q 144.13969867219652 181.818 144.13969867219652 181.818L 150.27330287101339 181.818Q 150.27330287101339 181.818 150.27330287101339 181.818L 150.27330287101339 181.818L 150.27330287101339 183.816L 150.27330287101339 183.816z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 144.13969867219652 183.816L 144.13969867219652 181.818Q 144.13969867219652 181.818 144.13969867219652 181.818L 150.27330287101339 181.818Q 150.27330287101339 181.818 150.27330287101339 181.818L 150.27330287101339 181.818L 150.27330287101339 183.816L 150.27330287101339 183.816z" pathFrom="M 144.13969867219652 183.816L 144.13969867219652 183.816L 150.27330287101339 183.816L 150.27330287101339 183.816L 150.27330287101339 183.816L 150.27330287101339 183.816L 150.27330287101339 183.816L 144.13969867219652 183.816" cy="181.818" cx="150.27330287101339" j="12" val="1" barHeight="1.9980000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3041" d="M 156.40690706983025 179.82L 156.40690706983025 161.838Q 156.40690706983025 161.838 156.40690706983025 161.838L 162.54051126864712 161.838Q 162.54051126864712 161.838 162.54051126864712 161.838L 162.54051126864712 161.838L 162.54051126864712 179.82L 162.54051126864712 179.82z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 156.40690706983025 179.82L 156.40690706983025 161.838Q 156.40690706983025 161.838 156.40690706983025 161.838L 162.54051126864712 161.838Q 162.54051126864712 161.838 162.54051126864712 161.838L 162.54051126864712 161.838L 162.54051126864712 179.82L 162.54051126864712 179.82z" pathFrom="M 156.40690706983025 179.82L 156.40690706983025 179.82L 162.54051126864712 179.82L 162.54051126864712 179.82L 162.54051126864712 179.82L 162.54051126864712 179.82L 162.54051126864712 179.82L 156.40690706983025 179.82" cy="161.838" cx="162.54051126864712" j="13" val="9" barHeight="17.982000000000003" barWidth="6.133604198816873"></path><path id="SvgjsPath3042" d="M 168.674115467464 143.856L 168.674115467464 137.862Q 168.674115467464 137.862 168.674115467464 137.862L 174.80771966628086 137.862Q 174.80771966628086 137.862 174.80771966628086 137.862L 174.80771966628086 137.862L 174.80771966628086 143.856L 174.80771966628086 143.856z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 168.674115467464 143.856L 168.674115467464 137.862Q 168.674115467464 137.862 168.674115467464 137.862L 174.80771966628086 137.862Q 174.80771966628086 137.862 174.80771966628086 137.862L 174.80771966628086 137.862L 174.80771966628086 143.856L 174.80771966628086 143.856z" pathFrom="M 168.674115467464 143.856L 168.674115467464 143.856L 174.80771966628086 143.856L 174.80771966628086 143.856L 174.80771966628086 143.856L 174.80771966628086 143.856L 174.80771966628086 143.856L 168.674115467464 143.856" cy="137.862" cx="174.80771966628086" j="14" val="3" barHeight="5.994000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3043" d="M 180.94132386509773 173.82600000000002L 180.94132386509773 161.83800000000002Q 180.94132386509773 161.83800000000002 180.94132386509773 161.83800000000002L 187.0749280639146 161.83800000000002Q 187.0749280639146 161.83800000000002 187.0749280639146 161.83800000000002L 187.0749280639146 161.83800000000002L 187.0749280639146 173.82600000000002L 187.0749280639146 173.82600000000002z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 180.94132386509773 173.82600000000002L 180.94132386509773 161.83800000000002Q 180.94132386509773 161.83800000000002 180.94132386509773 161.83800000000002L 187.0749280639146 161.83800000000002Q 187.0749280639146 161.83800000000002 187.0749280639146 161.83800000000002L 187.0749280639146 161.83800000000002L 187.0749280639146 173.82600000000002L 187.0749280639146 173.82600000000002z" pathFrom="M 180.94132386509773 173.82600000000002L 180.94132386509773 173.82600000000002L 187.0749280639146 173.82600000000002L 187.0749280639146 173.82600000000002L 187.0749280639146 173.82600000000002L 187.0749280639146 173.82600000000002L 187.0749280639146 173.82600000000002L 180.94132386509773 173.82600000000002" cy="161.83800000000002" cx="187.0749280639146" j="15" val="6" barHeight="11.988000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3044" d="M 193.2085322627315 169.83L 193.2085322627315 155.84400000000002Q 193.2085322627315 155.84400000000002 193.2085322627315 155.84400000000002L 199.34213646154836 155.84400000000002Q 199.34213646154836 155.84400000000002 199.34213646154836 155.84400000000002L 199.34213646154836 155.84400000000002L 199.34213646154836 169.83L 199.34213646154836 169.83z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 193.2085322627315 169.83L 193.2085322627315 155.84400000000002Q 193.2085322627315 155.84400000000002 193.2085322627315 155.84400000000002L 199.34213646154836 155.84400000000002Q 199.34213646154836 155.84400000000002 199.34213646154836 155.84400000000002L 199.34213646154836 155.84400000000002L 199.34213646154836 169.83L 199.34213646154836 169.83z" pathFrom="M 193.2085322627315 169.83L 193.2085322627315 169.83L 199.34213646154836 169.83L 199.34213646154836 169.83L 199.34213646154836 169.83L 199.34213646154836 169.83L 199.34213646154836 169.83L 193.2085322627315 169.83" cy="155.84400000000002" cx="199.34213646154836" j="16" val="7" barHeight="13.986000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3045" d="M 205.47574066036523 185.81400000000002L 205.47574066036523 175.824Q 205.47574066036523 175.824 205.47574066036523 175.824L 211.6093448591821 175.824Q 211.6093448591821 175.824 211.6093448591821 175.824L 211.6093448591821 175.824L 211.6093448591821 185.81400000000002L 211.6093448591821 185.81400000000002z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 205.47574066036523 185.81400000000002L 205.47574066036523 175.824Q 205.47574066036523 175.824 205.47574066036523 175.824L 211.6093448591821 175.824Q 211.6093448591821 175.824 211.6093448591821 175.824L 211.6093448591821 175.824L 211.6093448591821 185.81400000000002L 211.6093448591821 185.81400000000002z" pathFrom="M 205.47574066036523 185.81400000000002L 205.47574066036523 185.81400000000002L 211.6093448591821 185.81400000000002L 211.6093448591821 185.81400000000002L 211.6093448591821 185.81400000000002L 211.6093448591821 185.81400000000002L 211.6093448591821 185.81400000000002L 205.47574066036523 185.81400000000002" cy="175.824" cx="211.6093448591821" j="17" val="5" barHeight="9.990000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3046" d="M 217.74294905799897 181.818L 217.74294905799897 177.822Q 217.74294905799897 177.822 217.74294905799897 177.822L 223.87655325681584 177.822Q 223.87655325681584 177.822 223.87655325681584 177.822L 223.87655325681584 177.822L 223.87655325681584 181.818L 223.87655325681584 181.818z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 217.74294905799897 181.818L 217.74294905799897 177.822Q 217.74294905799897 177.822 217.74294905799897 177.822L 223.87655325681584 177.822Q 223.87655325681584 177.822 223.87655325681584 177.822L 223.87655325681584 177.822L 223.87655325681584 181.818L 223.87655325681584 181.818z" pathFrom="M 217.74294905799897 181.818L 217.74294905799897 181.818L 223.87655325681584 181.818L 223.87655325681584 181.818L 223.87655325681584 181.818L 223.87655325681584 181.818L 223.87655325681584 181.818L 217.74294905799897 181.818" cy="177.822" cx="223.87655325681584" j="18" val="2" barHeight="3.9960000000000004" barWidth="6.133604198816873"></path><path id="SvgjsPath3047" d="M 230.01015745563274 187.812L 230.01015745563274 171.828Q 230.01015745563274 171.828 230.01015745563274 171.828L 236.1437616544496 171.828Q 236.1437616544496 171.828 236.1437616544496 171.828L 236.1437616544496 171.828L 236.1437616544496 187.812L 236.1437616544496 187.812z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 230.01015745563274 187.812L 230.01015745563274 171.828Q 230.01015745563274 171.828 230.01015745563274 171.828L 236.1437616544496 171.828Q 236.1437616544496 171.828 236.1437616544496 171.828L 236.1437616544496 171.828L 236.1437616544496 187.812L 236.1437616544496 187.812z" pathFrom="M 230.01015745563274 187.812L 230.01015745563274 187.812L 236.1437616544496 187.812L 236.1437616544496 187.812L 236.1437616544496 187.812L 236.1437616544496 187.812L 236.1437616544496 187.812L 230.01015745563274 187.812" cy="171.828" cx="236.1437616544496" j="19" val="8" barHeight="15.984000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3048" d="M 242.27736585326647 179.82L 242.27736585326647 171.828Q 242.27736585326647 171.828 242.27736585326647 171.828L 248.41097005208334 171.828Q 248.41097005208334 171.828 248.41097005208334 171.828L 248.41097005208334 171.828L 248.41097005208334 179.82L 248.41097005208334 179.82z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 242.27736585326647 179.82L 242.27736585326647 171.828Q 242.27736585326647 171.828 242.27736585326647 171.828L 248.41097005208334 171.828Q 248.41097005208334 171.828 248.41097005208334 171.828L 248.41097005208334 171.828L 248.41097005208334 179.82L 248.41097005208334 179.82z" pathFrom="M 242.27736585326647 179.82L 242.27736585326647 179.82L 248.41097005208334 179.82L 248.41097005208334 179.82L 248.41097005208334 179.82L 248.41097005208334 179.82L 248.41097005208334 179.82L 242.27736585326647 179.82" cy="171.828" cx="248.41097005208334" j="20" val="4" barHeight="7.992000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3049" d="M 254.5445742509002 127.87200000000001L 254.5445742509002 109.89000000000001Q 254.5445742509002 109.89000000000001 254.5445742509002 109.89000000000001L 260.6781784497171 109.89000000000001Q 260.6781784497171 109.89000000000001 260.6781784497171 109.89000000000001L 260.6781784497171 109.89000000000001L 260.6781784497171 127.87200000000001L 260.6781784497171 127.87200000000001z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 254.5445742509002 127.87200000000001L 254.5445742509002 109.89000000000001Q 254.5445742509002 109.89000000000001 254.5445742509002 109.89000000000001L 260.6781784497171 109.89000000000001Q 260.6781784497171 109.89000000000001 260.6781784497171 109.89000000000001L 260.6781784497171 109.89000000000001L 260.6781784497171 127.87200000000001L 260.6781784497171 127.87200000000001z" pathFrom="M 254.5445742509002 127.87200000000001L 254.5445742509002 127.87200000000001L 260.6781784497171 127.87200000000001L 260.6781784497171 127.87200000000001L 260.6781784497171 127.87200000000001L 260.6781784497171 127.87200000000001L 260.6781784497171 127.87200000000001L 254.5445742509002 127.87200000000001" cy="109.89000000000001" cx="260.6781784497171" j="21" val="9" barHeight="17.982000000000003" barWidth="6.133604198816873"></path><path id="SvgjsPath3050" d="M 266.81178264853395 133.866L 266.81178264853395 131.86800000000002Q 266.81178264853395 131.86800000000002 266.81178264853395 131.86800000000002L 272.94538684735085 131.86800000000002Q 272.94538684735085 131.86800000000002 272.94538684735085 131.86800000000002L 272.94538684735085 131.86800000000002L 272.94538684735085 133.866L 272.94538684735085 133.866z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 266.81178264853395 133.866L 266.81178264853395 131.86800000000002Q 266.81178264853395 131.86800000000002 266.81178264853395 131.86800000000002L 272.94538684735085 131.86800000000002Q 272.94538684735085 131.86800000000002 272.94538684735085 131.86800000000002L 272.94538684735085 131.86800000000002L 272.94538684735085 133.866L 272.94538684735085 133.866z" pathFrom="M 266.81178264853395 133.866L 266.81178264853395 133.866L 272.94538684735085 133.866L 272.94538684735085 133.866L 272.94538684735085 133.866L 272.94538684735085 133.866L 272.94538684735085 133.866L 266.81178264853395 133.866" cy="131.86800000000002" cx="272.94538684735085" j="22" val="1" barHeight="1.9980000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3051" d="M 279.0789910461677 85.914L 279.0789910461677 81.918Q 279.0789910461677 81.918 279.0789910461677 81.918L 285.2125952449846 81.918Q 285.2125952449846 81.918 285.2125952449846 81.918L 285.2125952449846 81.918L 285.2125952449846 85.914L 285.2125952449846 85.914z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 279.0789910461677 85.914L 279.0789910461677 81.918Q 279.0789910461677 81.918 279.0789910461677 81.918L 285.2125952449846 81.918Q 285.2125952449846 81.918 285.2125952449846 81.918L 285.2125952449846 81.918L 285.2125952449846 85.914L 285.2125952449846 85.914z" pathFrom="M 279.0789910461677 85.914L 279.0789910461677 85.914L 285.2125952449846 85.914L 285.2125952449846 85.914L 285.2125952449846 85.914L 285.2125952449846 85.914L 285.2125952449846 85.914L 279.0789910461677 85.914" cy="81.918" cx="285.2125952449846" j="23" val="2" barHeight="3.9960000000000004" barWidth="6.133604198816873"></path><path id="SvgjsPath3052" d="M 291.3461994438015 83.916L 291.3461994438015 71.928Q 291.3461994438015 71.928 291.3461994438015 71.928L 297.4798036426184 71.928Q 297.4798036426184 71.928 297.4798036426184 71.928L 297.4798036426184 71.928L 297.4798036426184 83.916L 297.4798036426184 83.916z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 291.3461994438015 83.916L 291.3461994438015 71.928Q 291.3461994438015 71.928 291.3461994438015 71.928L 297.4798036426184 71.928Q 297.4798036426184 71.928 297.4798036426184 71.928L 297.4798036426184 71.928L 297.4798036426184 83.916L 297.4798036426184 83.916z" pathFrom="M 291.3461994438015 83.916L 291.3461994438015 83.916L 297.4798036426184 83.916L 297.4798036426184 83.916L 297.4798036426184 83.916L 297.4798036426184 83.916L 297.4798036426184 83.916L 291.3461994438015 83.916" cy="71.928" cx="297.4798036426184" j="24" val="6" barHeight="11.988000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3053" d="M 303.6134078414352 99.9L 303.6134078414352 85.914Q 303.6134078414352 85.914 303.6134078414352 85.914L 309.7470120402521 85.914Q 309.7470120402521 85.914 309.7470120402521 85.914L 309.7470120402521 85.914L 309.7470120402521 99.9L 309.7470120402521 99.9z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 303.6134078414352 99.9L 303.6134078414352 85.914Q 303.6134078414352 85.914 303.6134078414352 85.914L 309.7470120402521 85.914Q 309.7470120402521 85.914 309.7470120402521 85.914L 309.7470120402521 85.914L 309.7470120402521 99.9L 309.7470120402521 99.9z" pathFrom="M 303.6134078414352 99.9L 303.6134078414352 99.9L 309.7470120402521 99.9L 309.7470120402521 99.9L 309.7470120402521 99.9L 309.7470120402521 99.9L 309.7470120402521 99.9L 303.6134078414352 99.9" cy="85.914" cx="309.7470120402521" j="25" val="7" barHeight="13.986000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3054" d="M 315.88061623906896 143.856L 315.88061623906896 133.86599999999999Q 315.88061623906896 133.86599999999999 315.88061623906896 133.86599999999999L 322.01422043788585 133.86599999999999Q 322.01422043788585 133.86599999999999 322.01422043788585 133.86599999999999L 322.01422043788585 133.86599999999999L 322.01422043788585 143.856L 322.01422043788585 143.856z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 315.88061623906896 143.856L 315.88061623906896 133.86599999999999Q 315.88061623906896 133.86599999999999 315.88061623906896 133.86599999999999L 322.01422043788585 133.86599999999999Q 322.01422043788585 133.86599999999999 322.01422043788585 133.86599999999999L 322.01422043788585 133.86599999999999L 322.01422043788585 143.856L 322.01422043788585 143.856z" pathFrom="M 315.88061623906896 143.856L 315.88061623906896 143.856L 322.01422043788585 143.856L 322.01422043788585 143.856L 322.01422043788585 143.856L 322.01422043788585 143.856L 322.01422043788585 143.856L 315.88061623906896 143.856" cy="133.86599999999999" cx="322.01422043788585" j="26" val="5" barHeight="9.990000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3055" d="M 328.1478246367027 143.856L 328.1478246367027 141.858Q 328.1478246367027 141.858 328.1478246367027 141.858L 334.2814288355196 141.858Q 334.2814288355196 141.858 334.2814288355196 141.858L 334.2814288355196 141.858L 334.2814288355196 143.856L 334.2814288355196 143.856z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 328.1478246367027 143.856L 328.1478246367027 141.858Q 328.1478246367027 141.858 328.1478246367027 141.858L 334.2814288355196 141.858Q 334.2814288355196 141.858 334.2814288355196 141.858L 334.2814288355196 141.858L 334.2814288355196 143.856L 334.2814288355196 143.856z" pathFrom="M 328.1478246367027 143.856L 328.1478246367027 143.856L 334.2814288355196 143.856L 334.2814288355196 143.856L 334.2814288355196 143.856L 334.2814288355196 143.856L 334.2814288355196 143.856L 328.1478246367027 143.856" cy="141.858" cx="334.2814288355196" j="27" val="1" barHeight="1.9980000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3056" d="M 340.41503303433643 73.92599999999999L 340.41503303433643 57.941999999999986Q 340.41503303433643 57.941999999999986 340.41503303433643 57.941999999999986L 346.54863723315333 57.941999999999986Q 346.54863723315333 57.941999999999986 346.54863723315333 57.941999999999986L 346.54863723315333 57.941999999999986L 346.54863723315333 73.92599999999999L 346.54863723315333 73.92599999999999z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 340.41503303433643 73.92599999999999L 340.41503303433643 57.941999999999986Q 340.41503303433643 57.941999999999986 340.41503303433643 57.941999999999986L 346.54863723315333 57.941999999999986Q 346.54863723315333 57.941999999999986 346.54863723315333 57.941999999999986L 346.54863723315333 57.941999999999986L 346.54863723315333 73.92599999999999L 346.54863723315333 73.92599999999999z" pathFrom="M 340.41503303433643 73.92599999999999L 340.41503303433643 73.92599999999999L 346.54863723315333 73.92599999999999L 346.54863723315333 73.92599999999999L 346.54863723315333 73.92599999999999L 346.54863723315333 73.92599999999999L 346.54863723315333 73.92599999999999L 340.41503303433643 73.92599999999999" cy="57.941999999999986" cx="346.54863723315333" j="28" val="8" barHeight="15.984000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3057" d="M 352.68224143197017 117.882L 352.68224143197017 111.888Q 352.68224143197017 111.888 352.68224143197017 111.888L 358.81584563078707 111.888Q 358.81584563078707 111.888 358.81584563078707 111.888L 358.81584563078707 111.888L 358.81584563078707 117.882L 358.81584563078707 117.882z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 352.68224143197017 117.882L 352.68224143197017 111.888Q 352.68224143197017 111.888 352.68224143197017 111.888L 358.81584563078707 111.888Q 358.81584563078707 111.888 358.81584563078707 111.888L 358.81584563078707 111.888L 358.81584563078707 117.882L 358.81584563078707 117.882z" pathFrom="M 352.68224143197017 117.882L 352.68224143197017 117.882L 358.81584563078707 117.882L 358.81584563078707 117.882L 358.81584563078707 117.882L 358.81584563078707 117.882L 358.81584563078707 117.882L 352.68224143197017 117.882" cy="111.888" cx="358.81584563078707" j="29" val="3" barHeight="5.994000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3058" d="M 364.9494498296039 77.922L 364.9494498296039 73.926Q 364.9494498296039 73.926 364.9494498296039 73.926L 371.0830540284208 73.926Q 371.0830540284208 73.926 371.0830540284208 73.926L 371.0830540284208 73.926L 371.0830540284208 77.922L 371.0830540284208 77.922z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 364.9494498296039 77.922L 364.9494498296039 73.926Q 364.9494498296039 73.926 364.9494498296039 73.926L 371.0830540284208 73.926Q 371.0830540284208 73.926 371.0830540284208 73.926L 371.0830540284208 73.926L 371.0830540284208 77.922L 371.0830540284208 77.922z" pathFrom="M 364.9494498296039 77.922L 364.9494498296039 77.922L 371.0830540284208 77.922L 371.0830540284208 77.922L 371.0830540284208 77.922L 371.0830540284208 77.922L 371.0830540284208 77.922L 364.9494498296039 77.922" cy="73.926" cx="371.0830540284208" j="30" val="2" barHeight="3.9960000000000004" barWidth="6.133604198816873"></path><path id="SvgjsPath3059" d="M 377.2166582272377 61.93799999999999L 377.2166582272377 55.94399999999999Q 377.2166582272377 55.94399999999999 377.2166582272377 55.94399999999999L 383.3502624260546 55.94399999999999Q 383.3502624260546 55.94399999999999 383.3502624260546 55.94399999999999L 383.3502624260546 55.94399999999999L 383.3502624260546 61.93799999999999L 383.3502624260546 61.93799999999999z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 377.2166582272377 61.93799999999999L 377.2166582272377 55.94399999999999Q 377.2166582272377 55.94399999999999 377.2166582272377 55.94399999999999L 383.3502624260546 55.94399999999999Q 383.3502624260546 55.94399999999999 383.3502624260546 55.94399999999999L 383.3502624260546 55.94399999999999L 383.3502624260546 61.93799999999999L 383.3502624260546 61.93799999999999z" pathFrom="M 377.2166582272377 61.93799999999999L 377.2166582272377 61.93799999999999L 383.3502624260546 61.93799999999999L 383.3502624260546 61.93799999999999L 383.3502624260546 61.93799999999999L 383.3502624260546 61.93799999999999L 383.3502624260546 61.93799999999999L 377.2166582272377 61.93799999999999" cy="55.94399999999999" cx="383.3502624260546" j="31" val="3" barHeight="5.994000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3060" d="M 389.48386662487144 71.928L 389.48386662487144 63.93599999999999Q 389.48386662487144 63.93599999999999 389.48386662487144 63.93599999999999L 395.61747082368834 63.93599999999999Q 395.61747082368834 63.93599999999999 395.61747082368834 63.93599999999999L 395.61747082368834 63.93599999999999L 395.61747082368834 71.928L 395.61747082368834 71.928z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 389.48386662487144 71.928L 389.48386662487144 63.93599999999999Q 389.48386662487144 63.93599999999999 389.48386662487144 63.93599999999999L 395.61747082368834 63.93599999999999Q 395.61747082368834 63.93599999999999 395.61747082368834 63.93599999999999L 395.61747082368834 63.93599999999999L 395.61747082368834 71.928L 395.61747082368834 71.928z" pathFrom="M 389.48386662487144 71.928L 389.48386662487144 71.928L 395.61747082368834 71.928L 395.61747082368834 71.928L 395.61747082368834 71.928L 395.61747082368834 71.928L 395.61747082368834 71.928L 389.48386662487144 71.928" cy="63.93599999999999" cx="395.61747082368834" j="32" val="4" barHeight="7.992000000000001" barWidth="6.133604198816873"></path><path id="SvgjsPath3061" d="M 401.7510750225052 75.924L 401.7510750225052 57.94200000000001Q 401.7510750225052 57.94200000000001 401.7510750225052 57.94200000000001L 407.8846792213221 57.94200000000001Q 407.8846792213221 57.94200000000001 407.8846792213221 57.94200000000001L 407.8846792213221 57.94200000000001L 407.8846792213221 75.924L 407.8846792213221 75.924z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 401.7510750225052 75.924L 401.7510750225052 57.94200000000001Q 401.7510750225052 57.94200000000001 401.7510750225052 57.94200000000001L 407.8846792213221 57.94200000000001Q 407.8846792213221 57.94200000000001 407.8846792213221 57.94200000000001L 407.8846792213221 57.94200000000001L 407.8846792213221 75.924L 407.8846792213221 75.924z" pathFrom="M 401.7510750225052 75.924L 401.7510750225052 75.924L 407.8846792213221 75.924L 407.8846792213221 75.924L 407.8846792213221 75.924L 407.8846792213221 75.924L 407.8846792213221 75.924L 401.7510750225052 75.924" cy="57.94200000000001" cx="407.8846792213221" j="33" val="9" barHeight="17.982000000000003" barWidth="6.133604198816873"></path><path id="SvgjsPath3062" d="M 414.0182834201389 15.983999999999988L 414.0182834201389 1.9979999999999851Q 414.0182834201389 1.9979999999999851 414.0182834201389 1.9979999999999851L 420.1518876189558 1.9979999999999851Q 420.1518876189558 1.9979999999999851 420.1518876189558 1.9979999999999851L 420.1518876189558 1.9979999999999851L 420.1518876189558 15.983999999999988L 420.1518876189558 15.983999999999988z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 414.0182834201389 15.983999999999988L 414.0182834201389 1.9979999999999851Q 414.0182834201389 1.9979999999999851 414.0182834201389 1.9979999999999851L 420.1518876189558 1.9979999999999851Q 420.1518876189558 1.9979999999999851 420.1518876189558 1.9979999999999851L 420.1518876189558 1.9979999999999851L 420.1518876189558 15.983999999999988L 420.1518876189558 15.983999999999988z" pathFrom="M 414.0182834201389 15.983999999999988L 414.0182834201389 15.983999999999988L 420.1518876189558 15.983999999999988L 420.1518876189558 15.983999999999988L 420.1518876189558 15.983999999999988L 420.1518876189558 15.983999999999988L 420.1518876189558 15.983999999999988L 414.0182834201389 15.983999999999988" cy="1.9979999999999851" cx="420.1518876189558" j="34" val="7" barHeight="13.986000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3063" d="M 426.28549181777265 87.91199999999999L 426.28549181777265 85.91399999999999Q 426.28549181777265 85.91399999999999 426.28549181777265 85.91399999999999L 432.41909601658955 85.91399999999999Q 432.41909601658955 85.91399999999999 432.41909601658955 85.91399999999999L 432.41909601658955 85.91399999999999L 432.41909601658955 87.91199999999999L 432.41909601658955 87.91199999999999z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 426.28549181777265 87.91199999999999L 426.28549181777265 85.91399999999999Q 426.28549181777265 85.91399999999999 426.28549181777265 85.91399999999999L 432.41909601658955 85.91399999999999Q 432.41909601658955 85.91399999999999 432.41909601658955 85.91399999999999L 432.41909601658955 85.91399999999999L 432.41909601658955 87.91199999999999L 432.41909601658955 87.91199999999999z" pathFrom="M 426.28549181777265 87.91199999999999L 426.28549181777265 87.91199999999999L 432.41909601658955 87.91199999999999L 432.41909601658955 87.91199999999999L 432.41909601658955 87.91199999999999L 432.41909601658955 87.91199999999999L 432.41909601658955 87.91199999999999L 426.28549181777265 87.91199999999999" cy="85.91399999999999" cx="432.41909601658955" j="35" val="1" barHeight="1.9980000000000002" barWidth="6.133604198816873"></path><path id="SvgjsPath3064" d="M 438.5527002154064 187.812L 438.5527002154064 175.824Q 438.5527002154064 175.824 438.5527002154064 175.824L 444.6863044142233 175.824Q 444.6863044142233 175.824 444.6863044142233 175.824L 444.6863044142233 175.824L 444.6863044142233 187.812L 444.6863044142233 187.812z" fill="rgba(191,227,153,1)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-bar-area" index="2" clip-path="url(#gridRectMasknf1c0i1uj)" pathTo="M 438.5527002154064 187.812L 438.5527002154064 175.824Q 438.5527002154064 175.824 438.5527002154064 175.824L 444.6863044142233 175.824Q 444.6863044142233 175.824 444.6863044142233 175.824L 444.6863044142233 175.824L 444.6863044142233 187.812L 444.6863044142233 187.812z" pathFrom="M 438.5527002154064 187.812L 438.5527002154064 187.812L 444.6863044142233 187.812L 444.6863044142233 187.812L 444.6863044142233 187.812L 444.6863044142233 187.812L 444.6863044142233 187.812L 438.5527002154064 187.812" cy="175.824" cx="444.6863044142233" j="36" val="6" barHeight="11.988000000000001" barWidth="6.133604198816873"></path></g><g id="SvgjsG2949" class="apexcharts-datalabels" data:realIndex="0"></g><g id="SvgjsG2988" class="apexcharts-datalabels" data:realIndex="1"></g><g id="SvgjsG3027" class="apexcharts-datalabels" data:realIndex="2"></g></g><line id="SvgjsLine3117" x1="-9.260561342592592" y1="0" x2="450.88006365740745" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" stroke-linecap="butt" class="apexcharts-ycrosshairs"></line><line id="SvgjsLine3118" x1="-9.260561342592592" y1="0" x2="450.88006365740745" y2="0" stroke-dasharray="0" stroke-width="0" stroke-linecap="butt" class="apexcharts-ycrosshairs-hidden"></line><g id="SvgjsG3119" class="apexcharts-yaxis-annotations"></g><g id="SvgjsG3120" class="apexcharts-xaxis-annotations"></g><g id="SvgjsG3121" class="apexcharts-point-annotations"></g><rect id="SvgjsRect3122" width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe" class="apexcharts-zoom-rect"></rect><rect id="SvgjsRect3123" width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe" class="apexcharts-selection-rect"></rect></g><g id="SvgjsG3082" class="apexcharts-yaxis" rel="0" transform="translate(14.859375, 0)"><g id="SvgjsG3083" class="apexcharts-yaxis-texts-g"><text id="SvgjsText3084" font-family="inherit" x="4" y="11.5" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: inherit;"><tspan id="SvgjsTspan3085">100</tspan><title>100</title></text><text id="SvgjsText3086" font-family="inherit" x="4" y="51.46" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: inherit;"><tspan id="SvgjsTspan3087">80</tspan><title>80</title></text><text id="SvgjsText3088" font-family="inherit" x="4" y="91.42" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: inherit;"><tspan id="SvgjsTspan3089">60</tspan><title>60</title></text><text id="SvgjsText3090" font-family="inherit" x="4" y="131.38" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: inherit;"><tspan id="SvgjsTspan3091">40</tspan><title>40</title></text><text id="SvgjsText3092" font-family="inherit" x="4" y="171.34" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: inherit;"><tspan id="SvgjsTspan3093">20</tspan><title>20</title></text><text id="SvgjsText3094" font-family="inherit" x="4" y="211.3" text-anchor="end" dominant-baseline="auto" font-size="11px" font-weight="400" fill="#373d3f" class="apexcharts-text apexcharts-yaxis-label " style="font-family: inherit;"><tspan id="SvgjsTspan3095">0</tspan><title>0</title></text></g></g><g id="SvgjsG2930" class="apexcharts-annotations"></g></svg><div class="apexcharts-legend" style="max-height: 120px;"></div><div class="apexcharts-tooltip apexcharts-theme-light"><div class="apexcharts-tooltip-title" style="font-family: inherit; font-size: 12px;"></div><div class="apexcharts-tooltip-series-group" style="order: 1;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(32, 107, 196);"></span><div class="apexcharts-tooltip-text" style="font-family: inherit; font-size: 12px;"><div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-y-label"></span><span class="apexcharts-tooltip-text-y-value"></span></div><div class="apexcharts-tooltip-goals-group"><span class="apexcharts-tooltip-text-goals-label"></span><span class="apexcharts-tooltip-text-goals-value"></span></div><div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div></div></div><div class="apexcharts-tooltip-series-group" style="order: 2;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(121, 166, 220);"></span><div class="apexcharts-tooltip-text" style="font-family: inherit; font-size: 12px;"><div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-y-label"></span><span class="apexcharts-tooltip-text-y-value"></span></div><div class="apexcharts-tooltip-goals-group"><span class="apexcharts-tooltip-text-goals-label"></span><span class="apexcharts-tooltip-text-goals-value"></span></div><div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div></div></div><div class="apexcharts-tooltip-series-group" style="order: 3;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(191, 227, 153);"></span><div class="apexcharts-tooltip-text" style="font-family: inherit; font-size: 12px;"><div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-y-label"></span><span class="apexcharts-tooltip-text-y-value"></span></div><div class="apexcharts-tooltip-goals-group"><span class="apexcharts-tooltip-text-goals-label"></span><span class="apexcharts-tooltip-text-goals-value"></span></div><div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div></div></div></div><div class="apexcharts-yaxistooltip apexcharts-yaxistooltip-0 apexcharts-yaxistooltip-left apexcharts-theme-light"><div class="apexcharts-yaxistooltip-text"></div></div></div></div>
                    <div class="resize-triggers"><div class="expand-trigger"><div style="width: 522px; height: 313px;"></div></div><div class="contract-trigger"></div></div></div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="card">
                    <div class="card-body">
                      <p class="mb-3">Using Storage <strong>6854.45 MB </strong>of 8 GB</p>
                      <div class="progress progress-separated mb-3">
                        <div class="progress-bar bg-primary" role="progressbar" style="width: 44%"></div>
                        <div class="progress-bar bg-info" role="progressbar" style="width: 19%"></div>
                        <div class="progress-bar bg-success" role="progressbar" style="width: 9%"></div>
                      </div>
                      <div class="row">
                        <div class="col-auto d-flex align-items-center pe-2">
                          <span class="legend me-2 bg-primary"></span>
                          <span>Regular</span>
                          <span class="d-none d-md-inline d-lg-none d-xxl-inline ms-2 text-muted">915MB</span>
                        </div>
                        <div class="col-auto d-flex align-items-center px-2">
                          <span class="legend me-2 bg-info"></span>
                          <span>System</span>
                          <span class="d-none d-md-inline d-lg-none d-xxl-inline ms-2 text-muted">415MB</span>
                        </div>
                        <div class="col-auto d-flex align-items-center px-2">
                          <span class="legend me-2 bg-success"></span>
                          <span>Shared</span>
                          <span class="d-none d-md-inline d-lg-none d-xxl-inline ms-2 text-muted">201MB</span>
                        </div>
                        <div class="col-auto d-flex align-items-center ps-2">
                          <span class="legend me-2"></span>
                          <span>Free</span>
                          <span class="d-none d-md-inline d-lg-none d-xxl-inline ms-2 text-muted">612MB</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="card">
                    <div class="card-body p-2 text-center">
                      <div class="text-end text-green">
                        <span class="text-green d-inline-flex align-items-center lh-1">
                          6% <!-- Download SVG icon from http://tabler-icons.io/i/trending-up -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="3 17 9 11 13 15 21 7"></polyline><polyline points="14 7 21 7 21 14"></polyline></svg>
                        </span>
                      </div>
                      <div class="h1 m-0">43</div>
                      <div class="text-muted mb-3">New Tickets</div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="card">
                    <div class="card-body p-2 text-center">
                      <div class="text-end text-red">
                        <span class="text-red d-inline-flex align-items-center lh-1">
                          -2% <!-- Download SVG icon from http://tabler-icons.io/i/trending-down -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="3 7 9 13 13 9 21 17"></polyline><polyline points="21 10 21 17 14 17"></polyline></svg>
                        </span>
                      </div>
                      <div class="h1 m-0">95</div>
                      <div class="text-muted mb-3">Daily Earnings</div>
                    </div>
                  </div>
                </div>
                <div class="col-sm-4">
                  <div class="card">
                    <div class="card-body p-2 text-center">
                      <div class="text-end text-green">
                        <span class="text-green d-inline-flex align-items-center lh-1">
                          9% <!-- Download SVG icon from http://tabler-icons.io/i/trending-up -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon ms-1" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="3 17 9 11 13 15 21 7"></polyline><polyline points="14 7 21 7 21 14"></polyline></svg>
                        </span>
                      </div>
                      <div class="h1 m-0">7</div>
                      <div class="text-muted mb-3">New Replies</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header border-0">
                  <div class="card-title">Development activity</div>
                </div>
                <div class="position-relative">
                  <div class="position-absolute top-0 left-0 px-3 mt-1 w-50">
                    <div class="row g-2">
                      <div class="col-auto" style="position: relative;">
                        <div class="chart-sparkline chart-sparkline-square" id="sparkline-activity" style="min-height: 41px;"><div id="apexchartste5sq6m9j" class="apexcharts-canvas apexchartste5sq6m9j apexcharts-theme-light" style="width: 40px; height: 41px;"><svg id="SvgjsSvg3124" width="40" height="41" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;"><g id="SvgjsG3126" class="apexcharts-inner apexcharts-graphical" transform="translate(0, 0)"><defs id="SvgjsDefs3125"><clipPath id="gridRectMaskte5sq6m9j"><rect id="SvgjsRect3128" width="46" height="42" x="-3" y="-1" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath><clipPath id="forecastMaskte5sq6m9j"></clipPath><clipPath id="nonForecastMaskte5sq6m9j"></clipPath><clipPath id="gridRectMarkerMaskte5sq6m9j"><rect id="SvgjsRect3129" width="44" height="44" x="-2" y="-2" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath></defs><g id="SvgjsG3130" class="apexcharts-radialbar"><g id="SvgjsG3131"><g id="SvgjsG3132" class="apexcharts-tracks"><g id="SvgjsG3133" class="apexcharts-radialbar-track apexcharts-track" rel="1"><path id="apexcharts-radialbarTrack-0" d="M 20 4.146341463414631 A 15.85365853658537 15.85365853658537 0 1 1 19.99723301461454 4.1463417048796565" fill="none" fill-opacity="1" stroke="rgba(242,242,242,0.85)" stroke-opacity="1" stroke-linecap="butt" stroke-width="2.3658536585365857" stroke-dasharray="0" class="apexcharts-radialbar-area" data:pathOrig="M 20 4.146341463414631 A 15.85365853658537 15.85365853658537 0 1 1 19.99723301461454 4.1463417048796565"></path></g></g><g id="SvgjsG3135"><g id="SvgjsG3137" class="apexcharts-series apexcharts-radial-series" seriesName="seriesx1" rel="1" data:realIndex="0"><path id="SvgjsPath3138" d="M 20 4.146341463414631 A 15.85365853658537 15.85365853658537 0 0 1 32.82587917911502 29.31854668268555" fill="none" fill-opacity="0.85" stroke="rgba(32,107,196,0.85)" stroke-opacity="1" stroke-linecap="butt" stroke-width="2.439024390243903" stroke-dasharray="0" class="apexcharts-radialbar-area apexcharts-radialbar-slice-0" data:angle="126" data:value="35" index="0" j="0" data:pathOrig="M 20 4.146341463414631 A 15.85365853658537 15.85365853658537 0 0 1 32.82587917911502 29.31854668268555"></path></g><circle id="SvgjsCircle3136" r="14.670731707317076" cx="20" cy="20" class="apexcharts-radialbar-hollow" fill="transparent"></circle></g></g></g><line id="SvgjsLine3139" x1="0" y1="0" x2="40" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" stroke-linecap="butt" class="apexcharts-ycrosshairs"></line><line id="SvgjsLine3140" x1="0" y1="0" x2="40" y2="0" stroke-dasharray="0" stroke-width="0" stroke-linecap="butt" class="apexcharts-ycrosshairs-hidden"></line></g><g id="SvgjsG3127" class="apexcharts-annotations"></g></svg><div class="apexcharts-legend"></div></div></div>
                      <div class="resize-triggers"><div class="expand-trigger"><div style="width: 49px; height: 61px;"></div></div><div class="contract-trigger"></div></div></div>
                      <div class="col">
                        <div>Today's Earning: $4,262.40</div>
                        <div class="text-muted"><!-- Download SVG icon from http://tabler-icons.io/i/trending-up -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-inline text-green" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="3 17 9 11 13 15 21 7"></polyline><polyline points="14 7 21 7 21 14"></polyline></svg>
                          +5% more than yesterday</div>
                      </div>
                    </div>
                  </div>
                  <div id="chart-development-activity" style="min-height: 192px;"><div id="apexchartsq3v93f19h" class="apexcharts-canvas apexchartsq3v93f19h apexcharts-theme-light" style="width: 521px; height: 192px;"><svg id="SvgjsSvg3142" width="521" height="192" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;"><g id="SvgjsG3144" class="apexcharts-inner apexcharts-graphical" transform="translate(0, 0)"><defs id="SvgjsDefs3143"><clipPath id="gridRectMaskq3v93f19h"><rect id="SvgjsRect3180" width="527" height="194" x="-3" y="-1" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath><clipPath id="forecastMaskq3v93f19h"></clipPath><clipPath id="nonForecastMaskq3v93f19h"></clipPath><clipPath id="gridRectMarkerMaskq3v93f19h"><rect id="SvgjsRect3181" width="525" height="196" x="-2" y="-2" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath></defs><line id="SvgjsLine3149" x1="0" y1="0" x2="0" y2="192" stroke="#b6b6b6" stroke-dasharray="3" stroke-linecap="butt" class="apexcharts-xcrosshairs" x="0" y="0" width="1" height="192" fill="#b1b9c4" filter="none" fill-opacity="0.9" stroke-width="1"></line><g id="SvgjsG3188" class="apexcharts-xaxis" transform="translate(0, 0)"><g id="SvgjsG3189" class="apexcharts-xaxis-texts-g" transform="translate(0, -4)"></g></g><g id="SvgjsG3201" class="apexcharts-grid"><g id="SvgjsG3202" class="apexcharts-gridlines-horizontal" style="display: none;"><line id="SvgjsLine3204" x1="0" y1="0" x2="521" y2="0" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3205" x1="0" y1="48" x2="521" y2="48" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3206" x1="0" y1="96" x2="521" y2="96" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3207" x1="0" y1="144" x2="521" y2="144" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3208" x1="0" y1="192" x2="521" y2="192" stroke="#e0e0e0" stroke-dasharray="4" stroke-linecap="butt" class="apexcharts-gridline"></line></g><g id="SvgjsG3203" class="apexcharts-gridlines-vertical" style="display: none;"></g><line id="SvgjsLine3210" x1="0" y1="192" x2="521" y2="192" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line><line id="SvgjsLine3209" x1="0" y1="1" x2="0" y2="192" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line></g><g id="SvgjsG3182" class="apexcharts-area-series apexcharts-plot-series"><g id="SvgjsG3183" class="apexcharts-series" seriesName="Purchases" data:longestSeries="true" rel="1" data:realIndex="0"><path id="SvgjsPath3186" d="M 0 192L 0 184.8C 6.287931034482758 184.8 11.677586206896551 180 17.96551724137931 180C 24.25344827586207 180 29.64310344827586 182.4 35.93103448275862 182.4C 42.21896551724138 182.4 47.60862068965517 177.6 53.89655172413793 177.6C 60.18448275862069 177.6 65.57413793103449 175.2 71.86206896551724 175.2C 78.14999999999999 175.2 83.53965517241379 180 89.82758620689654 180C 96.11551724137931 180 101.5051724137931 177.6 107.79310344827586 177.6C 114.08103448275861 177.6 119.47068965517241 172.8 125.75862068965516 172.8C 132.0465517241379 172.8 137.4362068965517 134.4 143.72413793103448 134.4C 150.01206896551724 134.4 155.401724137931 175.2 161.68965517241378 175.2C 167.97758620689655 175.2 173.36724137931031 163.2 179.65517241379308 163.2C 185.94310344827585 163.2 191.33275862068965 180 197.6206896551724 180C 203.90862068965518 180 209.29827586206895 177.6 215.58620689655172 177.6C 221.87413793103448 177.6 227.26379310344825 184.8 233.55172413793102 184.8C 239.83965517241379 184.8 245.22931034482755 172.8 251.51724137931032 172.8C 257.80517241379306 172.8 263.1948275862069 182.4 269.48275862068965 182.4C 275.7706896551724 182.4 281.1603448275862 158.4 287.44827586206895 158.4C 293.7362068965517 158.4 299.1258620689655 120 305.41379310344826 120C 311.701724137931 120 317.0913793103448 151.2 323.37931034482756 151.2C 329.6672413793103 151.2 335.0568965517241 146.4 341.34482758620686 146.4C 347.63275862068963 146.4 353.0224137931034 156 359.31034482758616 156C 365.59827586206893 156 370.98793103448276 158.4 377.2758620689655 158.4C 383.5637931034483 158.4 388.95344827586206 132 395.2413793103448 132C 401.5293103448276 132 406.91896551724136 115.2 413.2068965517241 115.2C 419.4948275862069 115.2 424.88448275862066 96 431.17241379310343 96C 437.4603448275862 96 442.84999999999997 60 449.13793103448273 60C 455.4258620689655 60 460.81551724137927 48 467.10344827586204 48C 473.3913793103448 48 478.78103448275857 76.80000000000001 485.06896551724134 76.80000000000001C 491.3568965517241 76.80000000000001 496.7465517241379 67.2 503.03448275862064 67.2C 509.3224137931034 67.2 514.7120689655172 24 521 24C 521 24 521 24 521 192M 521 24z" fill="rgba(32,107,196,0.16)" fill-opacity="1" stroke-opacity="1" stroke-linecap="round" stroke-width="0" stroke-dasharray="0" class="apexcharts-area" index="0" clip-path="url(#gridRectMaskq3v93f19h)" pathTo="M 0 192L 0 184.8C 6.287931034482758 184.8 11.677586206896551 180 17.96551724137931 180C 24.25344827586207 180 29.64310344827586 182.4 35.93103448275862 182.4C 42.21896551724138 182.4 47.60862068965517 177.6 53.89655172413793 177.6C 60.18448275862069 177.6 65.57413793103449 175.2 71.86206896551724 175.2C 78.14999999999999 175.2 83.53965517241379 180 89.82758620689654 180C 96.11551724137931 180 101.5051724137931 177.6 107.79310344827586 177.6C 114.08103448275861 177.6 119.47068965517241 172.8 125.75862068965516 172.8C 132.0465517241379 172.8 137.4362068965517 134.4 143.72413793103448 134.4C 150.01206896551724 134.4 155.401724137931 175.2 161.68965517241378 175.2C 167.97758620689655 175.2 173.36724137931031 163.2 179.65517241379308 163.2C 185.94310344827585 163.2 191.33275862068965 180 197.6206896551724 180C 203.90862068965518 180 209.29827586206895 177.6 215.58620689655172 177.6C 221.87413793103448 177.6 227.26379310344825 184.8 233.55172413793102 184.8C 239.83965517241379 184.8 245.22931034482755 172.8 251.51724137931032 172.8C 257.80517241379306 172.8 263.1948275862069 182.4 269.48275862068965 182.4C 275.7706896551724 182.4 281.1603448275862 158.4 287.44827586206895 158.4C 293.7362068965517 158.4 299.1258620689655 120 305.41379310344826 120C 311.701724137931 120 317.0913793103448 151.2 323.37931034482756 151.2C 329.6672413793103 151.2 335.0568965517241 146.4 341.34482758620686 146.4C 347.63275862068963 146.4 353.0224137931034 156 359.31034482758616 156C 365.59827586206893 156 370.98793103448276 158.4 377.2758620689655 158.4C 383.5637931034483 158.4 388.95344827586206 132 395.2413793103448 132C 401.5293103448276 132 406.91896551724136 115.2 413.2068965517241 115.2C 419.4948275862069 115.2 424.88448275862066 96 431.17241379310343 96C 437.4603448275862 96 442.84999999999997 60 449.13793103448273 60C 455.4258620689655 60 460.81551724137927 48 467.10344827586204 48C 473.3913793103448 48 478.78103448275857 76.80000000000001 485.06896551724134 76.80000000000001C 491.3568965517241 76.80000000000001 496.7465517241379 67.2 503.03448275862064 67.2C 509.3224137931034 67.2 514.7120689655172 24 521 24C 521 24 521 24 521 192M 521 24z" pathFrom="M -1 192L -1 192L 17.96551724137931 192L 35.93103448275862 192L 53.89655172413793 192L 71.86206896551724 192L 89.82758620689654 192L 107.79310344827586 192L 125.75862068965516 192L 143.72413793103448 192L 161.68965517241378 192L 179.65517241379308 192L 197.6206896551724 192L 215.58620689655172 192L 233.55172413793102 192L 251.51724137931032 192L 269.48275862068965 192L 287.44827586206895 192L 305.41379310344826 192L 323.37931034482756 192L 341.34482758620686 192L 359.31034482758616 192L 377.2758620689655 192L 395.2413793103448 192L 413.2068965517241 192L 431.17241379310343 192L 449.13793103448273 192L 467.10344827586204 192L 485.06896551724134 192L 503.03448275862064 192L 521 192"></path><path id="SvgjsPath3187" d="M 0 184.8C 6.287931034482758 184.8 11.677586206896551 180 17.96551724137931 180C 24.25344827586207 180 29.64310344827586 182.4 35.93103448275862 182.4C 42.21896551724138 182.4 47.60862068965517 177.6 53.89655172413793 177.6C 60.18448275862069 177.6 65.57413793103449 175.2 71.86206896551724 175.2C 78.14999999999999 175.2 83.53965517241379 180 89.82758620689654 180C 96.11551724137931 180 101.5051724137931 177.6 107.79310344827586 177.6C 114.08103448275861 177.6 119.47068965517241 172.8 125.75862068965516 172.8C 132.0465517241379 172.8 137.4362068965517 134.4 143.72413793103448 134.4C 150.01206896551724 134.4 155.401724137931 175.2 161.68965517241378 175.2C 167.97758620689655 175.2 173.36724137931031 163.2 179.65517241379308 163.2C 185.94310344827585 163.2 191.33275862068965 180 197.6206896551724 180C 203.90862068965518 180 209.29827586206895 177.6 215.58620689655172 177.6C 221.87413793103448 177.6 227.26379310344825 184.8 233.55172413793102 184.8C 239.83965517241379 184.8 245.22931034482755 172.8 251.51724137931032 172.8C 257.80517241379306 172.8 263.1948275862069 182.4 269.48275862068965 182.4C 275.7706896551724 182.4 281.1603448275862 158.4 287.44827586206895 158.4C 293.7362068965517 158.4 299.1258620689655 120 305.41379310344826 120C 311.701724137931 120 317.0913793103448 151.2 323.37931034482756 151.2C 329.6672413793103 151.2 335.0568965517241 146.4 341.34482758620686 146.4C 347.63275862068963 146.4 353.0224137931034 156 359.31034482758616 156C 365.59827586206893 156 370.98793103448276 158.4 377.2758620689655 158.4C 383.5637931034483 158.4 388.95344827586206 132 395.2413793103448 132C 401.5293103448276 132 406.91896551724136 115.2 413.2068965517241 115.2C 419.4948275862069 115.2 424.88448275862066 96 431.17241379310343 96C 437.4603448275862 96 442.84999999999997 60 449.13793103448273 60C 455.4258620689655 60 460.81551724137927 48 467.10344827586204 48C 473.3913793103448 48 478.78103448275857 76.80000000000001 485.06896551724134 76.80000000000001C 491.3568965517241 76.80000000000001 496.7465517241379 67.2 503.03448275862064 67.2C 509.3224137931034 67.2 514.7120689655172 24 521 24" fill="none" fill-opacity="1" stroke="#206bc4" stroke-opacity="1" stroke-linecap="round" stroke-width="2" stroke-dasharray="0" class="apexcharts-area" index="0" clip-path="url(#gridRectMaskq3v93f19h)" pathTo="M 0 184.8C 6.287931034482758 184.8 11.677586206896551 180 17.96551724137931 180C 24.25344827586207 180 29.64310344827586 182.4 35.93103448275862 182.4C 42.21896551724138 182.4 47.60862068965517 177.6 53.89655172413793 177.6C 60.18448275862069 177.6 65.57413793103449 175.2 71.86206896551724 175.2C 78.14999999999999 175.2 83.53965517241379 180 89.82758620689654 180C 96.11551724137931 180 101.5051724137931 177.6 107.79310344827586 177.6C 114.08103448275861 177.6 119.47068965517241 172.8 125.75862068965516 172.8C 132.0465517241379 172.8 137.4362068965517 134.4 143.72413793103448 134.4C 150.01206896551724 134.4 155.401724137931 175.2 161.68965517241378 175.2C 167.97758620689655 175.2 173.36724137931031 163.2 179.65517241379308 163.2C 185.94310344827585 163.2 191.33275862068965 180 197.6206896551724 180C 203.90862068965518 180 209.29827586206895 177.6 215.58620689655172 177.6C 221.87413793103448 177.6 227.26379310344825 184.8 233.55172413793102 184.8C 239.83965517241379 184.8 245.22931034482755 172.8 251.51724137931032 172.8C 257.80517241379306 172.8 263.1948275862069 182.4 269.48275862068965 182.4C 275.7706896551724 182.4 281.1603448275862 158.4 287.44827586206895 158.4C 293.7362068965517 158.4 299.1258620689655 120 305.41379310344826 120C 311.701724137931 120 317.0913793103448 151.2 323.37931034482756 151.2C 329.6672413793103 151.2 335.0568965517241 146.4 341.34482758620686 146.4C 347.63275862068963 146.4 353.0224137931034 156 359.31034482758616 156C 365.59827586206893 156 370.98793103448276 158.4 377.2758620689655 158.4C 383.5637931034483 158.4 388.95344827586206 132 395.2413793103448 132C 401.5293103448276 132 406.91896551724136 115.2 413.2068965517241 115.2C 419.4948275862069 115.2 424.88448275862066 96 431.17241379310343 96C 437.4603448275862 96 442.84999999999997 60 449.13793103448273 60C 455.4258620689655 60 460.81551724137927 48 467.10344827586204 48C 473.3913793103448 48 478.78103448275857 76.80000000000001 485.06896551724134 76.80000000000001C 491.3568965517241 76.80000000000001 496.7465517241379 67.2 503.03448275862064 67.2C 509.3224137931034 67.2 514.7120689655172 24 521 24" pathFrom="M -1 192L -1 192L 17.96551724137931 192L 35.93103448275862 192L 53.89655172413793 192L 71.86206896551724 192L 89.82758620689654 192L 107.79310344827586 192L 125.75862068965516 192L 143.72413793103448 192L 161.68965517241378 192L 179.65517241379308 192L 197.6206896551724 192L 215.58620689655172 192L 233.55172413793102 192L 251.51724137931032 192L 269.48275862068965 192L 287.44827586206895 192L 305.41379310344826 192L 323.37931034482756 192L 341.34482758620686 192L 359.31034482758616 192L 377.2758620689655 192L 395.2413793103448 192L 413.2068965517241 192L 431.17241379310343 192L 449.13793103448273 192L 467.10344827586204 192L 485.06896551724134 192L 503.03448275862064 192L 521 192"></path><g id="SvgjsG3184" class="apexcharts-series-markers-wrap" data:realIndex="0"><g class="apexcharts-series-markers"><circle id="SvgjsCircle3216" r="0" cx="0" cy="0" class="apexcharts-marker whibezto2 no-pointer-events" stroke="#ffffff" fill="#206bc4" fill-opacity="1" stroke-width="2" stroke-opacity="0.9" default-marker-size="0"></circle></g></g></g><g id="SvgjsG3185" class="apexcharts-datalabels" data:realIndex="0"></g></g><line id="SvgjsLine3211" x1="0" y1="0" x2="521" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" stroke-linecap="butt" class="apexcharts-ycrosshairs"></line><line id="SvgjsLine3212" x1="0" y1="0" x2="521" y2="0" stroke-dasharray="0" stroke-width="0" stroke-linecap="butt" class="apexcharts-ycrosshairs-hidden"></line><g id="SvgjsG3213" class="apexcharts-yaxis-annotations"></g><g id="SvgjsG3214" class="apexcharts-xaxis-annotations"></g><g id="SvgjsG3215" class="apexcharts-point-annotations"></g></g><rect id="SvgjsRect3148" width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe"></rect><g id="SvgjsG3200" class="apexcharts-yaxis" rel="0" transform="translate(-18, 0)"></g><g id="SvgjsG3145" class="apexcharts-annotations"></g></svg><div class="apexcharts-legend" style="max-height: 96px;"></div><div class="apexcharts-tooltip apexcharts-theme-light"><div class="apexcharts-tooltip-title" style="font-family: inherit; font-size: 12px;"></div><div class="apexcharts-tooltip-series-group" style="order: 1;"><span class="apexcharts-tooltip-marker" style="background-color: rgb(32, 107, 196);"></span><div class="apexcharts-tooltip-text" style="font-family: inherit; font-size: 12px;"><div class="apexcharts-tooltip-y-group"><span class="apexcharts-tooltip-text-y-label"></span><span class="apexcharts-tooltip-text-y-value"></span></div><div class="apexcharts-tooltip-goals-group"><span class="apexcharts-tooltip-text-goals-label"></span><span class="apexcharts-tooltip-text-goals-value"></span></div><div class="apexcharts-tooltip-z-group"><span class="apexcharts-tooltip-text-z-label"></span><span class="apexcharts-tooltip-text-z-value"></span></div></div></div></div><div class="apexcharts-yaxistooltip apexcharts-yaxistooltip-0 apexcharts-yaxistooltip-left apexcharts-theme-light"><div class="apexcharts-yaxistooltip-text"></div></div></div></div>
                <div class="resize-triggers"><div class="expand-trigger"><div style="width: 522px; height: 193px;"></div></div><div class="contract-trigger"></div></div></div>
                <div class="card-table table-responsive">
                  <table class="table table-vcenter">
                    <thead>
                      <tr>
                        <th>User</th>
                        <th>Commit</th>
                        <th>Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td class="w-1">
                          <span class="avatar avatar-sm" style="background-image: url(./static/avatars/000m.jpg)"></span>
                        </td>
                        <td class="td-truncate">
                          <div class="text-truncate">
                            Fix dart Sass compatibility (#29755)
                          </div>
                        </td>
                        <td class="text-nowrap text-muted">28 Nov 2019</td>
                      </tr>
                      <tr>
                        <td class="w-1">
                          <span class="avatar avatar-sm">JL</span>
                        </td>
                        <td class="td-truncate">
                          <div class="text-truncate">
                            Change deprecated html tags to text decoration classes (#29604)
                          </div>
                        </td>
                        <td class="text-nowrap text-muted">27 Nov 2019</td>
                      </tr>
                      <tr>
                        <td class="w-1">
                          <span class="avatar avatar-sm" style="background-image: url(./static/avatars/002m.jpg)"></span>
                        </td>
                        <td class="td-truncate">
                          <div class="text-truncate">
                            justify-content:between ⇒ justify-content:space-between (#29734)
                          </div>
                        </td>
                        <td class="text-nowrap text-muted">26 Nov 2019</td>
                      </tr>
                      <tr>
                        <td class="w-1">
                          <span class="avatar avatar-sm" style="background-image: url(./static/avatars/003m.jpg)"></span>
                        </td>
                        <td class="td-truncate">
                          <div class="text-truncate">
                            Update change-version.js (#29736)
                          </div>
                        </td>
                        <td class="text-nowrap text-muted">26 Nov 2019</td>
                      </tr>
                      <tr>
                        <td class="w-1">
                          <span class="avatar avatar-sm" style="background-image: url(./static/avatars/000f.jpg)"></span>
                        </td>
                        <td class="td-truncate">
                          <div class="text-truncate">
                            Regenerate package-lock.json (#29730)
                          </div>
                        </td>
                        <td class="text-nowrap text-muted">25 Nov 2019</td>
                      </tr>
                      <tr>
                        <td class="w-1">
                          <span class="avatar avatar-sm" style="background-image: url(./static/avatars/001f.jpg)"></span>
                        </td>
                        <td class="td-truncate">
                          <div class="text-truncate">
                            Some minor text tweaks
                          </div>
                        </td>
                        <td class="text-nowrap text-muted">24 Nov 2019</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div class="col-md-8">
              <div class="card" style="height: calc(24rem + 10px)">
                <div class="card-body card-body-scrollable card-body-scrollable-shadow">
                  <div class="divide-y">
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar">JL</span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Jeffie Lewzey</strong> commented on your <strong>"I'm not a witch."</strong> post.
                          </div>
                          <div class="text-muted">yesterday</div>
                        </div>
                        <div class="col-auto align-self-center">
                          <div class="badge bg-primary"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/002m.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            It's <strong>Mallory Hulme</strong>'s birthday. Wish him well!
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                        <div class="col-auto align-self-center">
                          <div class="badge bg-primary"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/003m.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Dunn Slane</strong> posted <strong>"Well, what do you want?"</strong>.
                          </div>
                          <div class="text-muted">today</div>
                        </div>
                        <div class="col-auto align-self-center">
                          <div class="badge bg-primary"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/000f.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Emmy Levet</strong> created a new project <strong>Morning alarm clock</strong>.
                          </div>
                          <div class="text-muted">4 days ago</div>
                        </div>
                        <div class="col-auto align-self-center">
                          <div class="badge bg-primary"></div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/001f.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Maryjo Lebarree</strong> liked your photo.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar">EP</span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Egan Poetz</strong> registered new client as <strong>Trilia</strong>.
                          </div>
                          <div class="text-muted">yesterday</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/002f.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Kellie Skingley</strong> closed a new deal on project <strong>Pen Pineapple Apple Pen</strong>.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/003f.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Christabel Charlwood</strong> created a new project for <strong>Wikibox</strong>.
                          </div>
                          <div class="text-muted">4 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar">HS</span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Haskel Shelper</strong> change status of <strong>Tabler Icons</strong> from <strong>open</strong> to <strong>closed</strong>.
                          </div>
                          <div class="text-muted">today</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/006m.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Lorry Mion</strong> liked <strong>Tabler UI Kit</strong>.
                          </div>
                          <div class="text-muted">yesterday</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/004f.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Leesa Beaty</strong> posted new video.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/007m.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Perren Keemar</strong> and 3 others followed you.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar">SA</span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Sunny Airey</strong> upload 3 new photos to category <strong>Inspirations</strong>.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/009m.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Geoffry Flaunders</strong> made a <strong>$10</strong> donation.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/010m.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Thatcher Keel</strong> created a profile.
                          </div>
                          <div class="text-muted">3 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/005f.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Dyann Escala</strong> hosted the event <strong>Tabler UI Birthday</strong>.
                          </div>
                          <div class="text-muted">4 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar" style="background-image: url(./static/avatars/006f.jpg)"></span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Avivah Mugleston</strong> mentioned you on <strong>Best of 2020</strong>.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                    <div>
                      <div class="row">
                        <div class="col-auto">
                          <span class="avatar">AA</span>
                        </div>
                        <div class="col">
                          <div class="text-truncate">
                            <strong>Arlie Armstead</strong> sent a Review Request to <strong>Amanda Blake</strong>.
                          </div>
                          <div class="text-muted">2 days ago</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="row row-cards">
                <div class="col-12">
                  <div class="card card-sm">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-auto">
                          <span class="bg-blue text-white avatar"><!-- Download SVG icon from http://tabler-icons.io/i/currency-dollar -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M16.7 8a3 3 0 0 0 -2.7 -2h-4a3 3 0 0 0 0 6h4a3 3 0 0 1 0 6h-4a3 3 0 0 1 -2.7 -2"></path><path d="M12 3v3m0 12v3"></path></svg>
                          </span>
                        </div>
                        <div class="col">
                          <div class="font-weight-medium">
                            132 Sales
                          </div>
                          <div class="text-muted">
                            12 waiting payments
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="card card-sm">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-auto">
                          <span class="bg-green text-white avatar"><!-- Download SVG icon from http://tabler-icons.io/i/shopping-cart -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><circle cx="6" cy="19" r="2"></circle><circle cx="17" cy="19" r="2"></circle><path d="M17 17h-11v-14h-2"></path><path d="M6 5l14 1l-1 7h-13"></path></svg>
                          </span>
                        </div>
                        <div class="col">
                          <div class="font-weight-medium">
                            78 Orders
                          </div>
                          <div class="text-muted">
                            32 shipped
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="card card-sm">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-auto">
                          <span class="bg-yellow text-white avatar"><!-- Download SVG icon from http://tabler-icons.io/i/users -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><circle cx="9" cy="7" r="4"></circle><path d="M3 21v-2a4 4 0 0 1 4 -4h4a4 4 0 0 1 4 4v2"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path><path d="M21 21v-2a4 4 0 0 0 -3 -3.85"></path></svg>
                          </span>
                        </div>
                        <div class="col">
                          <div class="font-weight-medium">
                            1352 Members
                          </div>
                          <div class="text-muted">
                            163 registered today
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="card card-sm">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-auto">
                          <span class="bg-twitter text-white avatar"><!-- Download SVG icon from http://tabler-icons.io/i/brand-twitter -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M22 4.01c-1 .49 -1.98 .689 -3 .99c-1.121 -1.265 -2.783 -1.335 -4.38 -.737s-2.643 2.06 -2.62 3.737v1c-3.245 .083 -6.135 -1.395 -8 -4c0 0 -4.182 7.433 4 11c-1.872 1.247 -3.739 2.088 -6 2c3.308 1.803 6.913 2.423 10.034 1.517c3.58 -1.04 6.522 -3.723 7.651 -7.742a13.84 13.84 0 0 0 .497 -3.753c-.002 -.249 1.51 -2.772 1.818 -4.013z"></path></svg>
                          </span>
                        </div>
                        <div class="col">
                          <div class="font-weight-medium">
                            623 Shares
                          </div>
                          <div class="text-muted">
                            16 today
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="card card-sm">
                    <div class="card-body">
                      <div class="row align-items-center">
                        <div class="col-auto">
                          <span class="bg-facebook text-white avatar"><!-- Download SVG icon from http://tabler-icons.io/i/brand-facebook -->
                            <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M7 10v4h3v7h4v-7h3l1 -4h-4v-2a1 1 0 0 1 1 -1h3v-4h-3a5 5 0 0 0 -5 5v2h-3"></path></svg>
                          </span>
                        </div>
                        <div class="col">
                          <div class="font-weight-medium">
                            132 Likes
                          </div>
                          <div class="text-muted">
                            21 today
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12 col-lg-8">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Most Visited Pages</h3>
                </div>
                <div class="card-table table-responsive">
                  <table class="table table-vcenter">
                    <thead>
                      <tr>
                        <th>Page name</th>
                        <th>Visitors</th>
                        <th>Unique</th>
                        <th colspan="2">Bounce rate</th>
                      </tr>
                    </thead>
                    <tbody><tr>
                      <td>
                        /about.html
                        <a href="#" class="ms-1" aria-label="Open website"><!-- Download SVG icon from http://tabler-icons.io/i/link -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M10 14a3.5 3.5 0 0 0 5 0l4 -4a3.5 3.5 0 0 0 -5 -5l-.5 .5"></path><path d="M14 10a3.5 3.5 0 0 0 -5 0l-4 4a3.5 3.5 0 0 0 5 5l.5 -.5"></path></svg>
                        </a>
                      </td>
                      <td class="text-muted">4,896</td>
                      <td class="text-muted">3,654</td>
                      <td class="text-muted">82.54%</td>
                      <td class="text-end w-1" style="position: relative;">
                        <div class="chart-sparkline chart-sparkline-sm" id="sparkline-bounce-rate-1" style="min-height: 24px;"><div id="apexcharts87u0y4mg" class="apexcharts-canvas apexcharts87u0y4mg apexcharts-theme-light" style="width: 64px; height: 24px;"><svg id="SvgjsSvg3217" width="64" height="24" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;"><g id="SvgjsG3219" class="apexcharts-inner apexcharts-graphical" transform="translate(0, 0)"><defs id="SvgjsDefs3218"><clipPath id="gridRectMask87u0y4mg"><rect id="SvgjsRect3224" width="70" height="26" x="-3" y="-1" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath><clipPath id="forecastMask87u0y4mg"></clipPath><clipPath id="nonForecastMask87u0y4mg"></clipPath><clipPath id="gridRectMarkerMask87u0y4mg"><rect id="SvgjsRect3225" width="68" height="28" x="-2" y="-2" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath></defs><line id="SvgjsLine3223" x1="0" y1="0" x2="0" y2="24" stroke="#b6b6b6" stroke-dasharray="3" stroke-linecap="butt" class="apexcharts-xcrosshairs" x="0" y="0" width="1" height="24" fill="#b1b9c4" filter="none" fill-opacity="0.9" stroke-width="1"></line><g id="SvgjsG3231" class="apexcharts-xaxis" transform="translate(0, 0)"><g id="SvgjsG3232" class="apexcharts-xaxis-texts-g" transform="translate(0, -4)"></g></g><g id="SvgjsG3243" class="apexcharts-grid"><g id="SvgjsG3244" class="apexcharts-gridlines-horizontal" style="display: none;"><line id="SvgjsLine3246" x1="0" y1="0" x2="64" y2="0" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3247" x1="0" y1="6" x2="64" y2="6" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3248" x1="0" y1="12" x2="64" y2="12" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3249" x1="0" y1="18" x2="64" y2="18" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3250" x1="0" y1="24" x2="64" y2="24" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line></g><g id="SvgjsG3245" class="apexcharts-gridlines-vertical" style="display: none;"></g><line id="SvgjsLine3252" x1="0" y1="24" x2="64" y2="24" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line><line id="SvgjsLine3251" x1="0" y1="1" x2="0" y2="24" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line></g><g id="SvgjsG3226" class="apexcharts-line-series apexcharts-plot-series"><g id="SvgjsG3227" class="apexcharts-series" seriesName="seriesx1" data:longestSeries="true" rel="1" data:realIndex="0"><path id="SvgjsPath3230" d="M 0 7L 8 0L 16 4L 24 14L 32 19L 40 23L 48 20L 56 6L 64 11" fill="none" fill-opacity="1" stroke="rgba(32,107,196,0.85)" stroke-opacity="1" stroke-linecap="round" stroke-width="2" stroke-dasharray="0" class="apexcharts-line" index="0" clip-path="url(#gridRectMask87u0y4mg)" pathTo="M 0 7L 8 0L 16 4L 24 14L 32 19L 40 23L 48 20L 56 6L 64 11" pathFrom="M -1 24L -1 24L 8 24L 16 24L 24 24L 32 24L 40 24L 48 24L 56 24L 64 24"></path><g id="SvgjsG3228" class="apexcharts-series-markers-wrap" data:realIndex="0"></g></g><g id="SvgjsG3229" class="apexcharts-datalabels" data:realIndex="0"></g></g><line id="SvgjsLine3253" x1="0" y1="0" x2="64" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" stroke-linecap="butt" class="apexcharts-ycrosshairs"></line><line id="SvgjsLine3254" x1="0" y1="0" x2="64" y2="0" stroke-dasharray="0" stroke-width="0" stroke-linecap="butt" class="apexcharts-ycrosshairs-hidden"></line><g id="SvgjsG3255" class="apexcharts-yaxis-annotations"></g><g id="SvgjsG3256" class="apexcharts-xaxis-annotations"></g><g id="SvgjsG3257" class="apexcharts-point-annotations"></g></g><rect id="SvgjsRect3222" width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe"></rect><g id="SvgjsG3242" class="apexcharts-yaxis" rel="0" transform="translate(-18, 0)"></g><g id="SvgjsG3220" class="apexcharts-annotations"></g></svg><div class="apexcharts-legend" style="max-height: 12px;"></div></div></div>
                      <div class="resize-triggers"><div class="expand-trigger"><div style="width: 89px; height: 41px;"></div></div><div class="contract-trigger"></div></div></td>
                    </tr>
                    <tr>
                      <td>
                        /special-promo.html
                        <a href="#" class="ms-1" aria-label="Open website"><!-- Download SVG icon from http://tabler-icons.io/i/link -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M10 14a3.5 3.5 0 0 0 5 0l4 -4a3.5 3.5 0 0 0 -5 -5l-.5 .5"></path><path d="M14 10a3.5 3.5 0 0 0 -5 0l-4 4a3.5 3.5 0 0 0 5 5l.5 -.5"></path></svg>
                        </a>
                      </td>
                      <td class="text-muted">3,652</td>
                      <td class="text-muted">3,215</td>
                      <td class="text-muted">76.29%</td>
                      <td class="text-end w-1" style="position: relative;">
                        <div class="chart-sparkline chart-sparkline-sm" id="sparkline-bounce-rate-2" style="min-height: 24px;"><div id="apexcharts4nf1a1bbj" class="apexcharts-canvas apexcharts4nf1a1bbj apexcharts-theme-light" style="width: 64px; height: 24px;"><svg id="SvgjsSvg3258" width="64" height="24" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;"><g id="SvgjsG3260" class="apexcharts-inner apexcharts-graphical" transform="translate(0, 0)"><defs id="SvgjsDefs3259"><clipPath id="gridRectMask4nf1a1bbj"><rect id="SvgjsRect3265" width="70" height="26" x="-3" y="-1" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath><clipPath id="forecastMask4nf1a1bbj"></clipPath><clipPath id="nonForecastMask4nf1a1bbj"></clipPath><clipPath id="gridRectMarkerMask4nf1a1bbj"><rect id="SvgjsRect3266" width="68" height="28" x="-2" y="-2" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath></defs><line id="SvgjsLine3264" x1="0" y1="0" x2="0" y2="24" stroke="#b6b6b6" stroke-dasharray="3" stroke-linecap="butt" class="apexcharts-xcrosshairs" x="0" y="0" width="1" height="24" fill="#b1b9c4" filter="none" fill-opacity="0.9" stroke-width="1"></line><g id="SvgjsG3272" class="apexcharts-xaxis" transform="translate(0, 0)"><g id="SvgjsG3273" class="apexcharts-xaxis-texts-g" transform="translate(0, -4)"></g></g><g id="SvgjsG3284" class="apexcharts-grid"><g id="SvgjsG3285" class="apexcharts-gridlines-horizontal" style="display: none;"><line id="SvgjsLine3287" x1="0" y1="0" x2="64" y2="0" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3288" x1="0" y1="4.8" x2="64" y2="4.8" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3289" x1="0" y1="9.6" x2="64" y2="9.6" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3290" x1="0" y1="14.399999999999999" x2="64" y2="14.399999999999999" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3291" x1="0" y1="19.2" x2="64" y2="19.2" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3292" x1="0" y1="24" x2="64" y2="24" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line></g><g id="SvgjsG3286" class="apexcharts-gridlines-vertical" style="display: none;"></g><line id="SvgjsLine3294" x1="0" y1="24" x2="64" y2="24" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line><line id="SvgjsLine3293" x1="0" y1="1" x2="0" y2="24" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line></g><g id="SvgjsG3267" class="apexcharts-line-series apexcharts-plot-series"><g id="SvgjsG3268" class="apexcharts-series" seriesName="seriesx1" data:longestSeries="true" rel="1" data:realIndex="0"><path id="SvgjsPath3271" d="M 0 11.520000000000001L 8 13.440000000000001L 16 5.760000000000002L 24 2.8800000000000026L 32 12.48L 40 17.28L 48 10.56L 56 21.12L 64 3.84" fill="none" fill-opacity="1" stroke="rgba(32,107,196,0.85)" stroke-opacity="1" stroke-linecap="round" stroke-width="2" stroke-dasharray="0" class="apexcharts-line" index="0" clip-path="url(#gridRectMask4nf1a1bbj)" pathTo="M 0 11.520000000000001L 8 13.440000000000001L 16 5.760000000000002L 24 2.8800000000000026L 32 12.48L 40 17.28L 48 10.56L 56 21.12L 64 3.84" pathFrom="M -1 24L -1 24L 8 24L 16 24L 24 24L 32 24L 40 24L 48 24L 56 24L 64 24"></path><g id="SvgjsG3269" class="apexcharts-series-markers-wrap" data:realIndex="0"></g></g><g id="SvgjsG3270" class="apexcharts-datalabels" data:realIndex="0"></g></g><line id="SvgjsLine3295" x1="0" y1="0" x2="64" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" stroke-linecap="butt" class="apexcharts-ycrosshairs"></line><line id="SvgjsLine3296" x1="0" y1="0" x2="64" y2="0" stroke-dasharray="0" stroke-width="0" stroke-linecap="butt" class="apexcharts-ycrosshairs-hidden"></line><g id="SvgjsG3297" class="apexcharts-yaxis-annotations"></g><g id="SvgjsG3298" class="apexcharts-xaxis-annotations"></g><g id="SvgjsG3299" class="apexcharts-point-annotations"></g></g><rect id="SvgjsRect3263" width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe"></rect><g id="SvgjsG3283" class="apexcharts-yaxis" rel="0" transform="translate(-18, 0)"></g><g id="SvgjsG3261" class="apexcharts-annotations"></g></svg><div class="apexcharts-legend" style="max-height: 12px;"></div></div></div>
                      <div class="resize-triggers"><div class="expand-trigger"><div style="width: 89px; height: 41px;"></div></div><div class="contract-trigger"></div></div></td>
                    </tr>
                    <tr>
                      <td>
                        /news/1,new-ui-kit.html
                        <a href="#" class="ms-1" aria-label="Open website"><!-- Download SVG icon from http://tabler-icons.io/i/link -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M10 14a3.5 3.5 0 0 0 5 0l4 -4a3.5 3.5 0 0 0 -5 -5l-.5 .5"></path><path d="M14 10a3.5 3.5 0 0 0 -5 0l-4 4a3.5 3.5 0 0 0 5 5l.5 -.5"></path></svg>
                        </a>
                      </td>
                      <td class="text-muted">3,256</td>
                      <td class="text-muted">2,865</td>
                      <td class="text-muted">72.65%</td>
                      <td class="text-end w-1" style="position: relative;">
                        <div class="chart-sparkline chart-sparkline-sm" id="sparkline-bounce-rate-3" style="min-height: 24px;"><div id="apexchartso1holi9ij" class="apexcharts-canvas apexchartso1holi9ij apexcharts-theme-light" style="width: 64px; height: 24px;"><svg id="SvgjsSvg3300" width="64" height="24" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;"><g id="SvgjsG3302" class="apexcharts-inner apexcharts-graphical" transform="translate(0, 0)"><defs id="SvgjsDefs3301"><clipPath id="gridRectMasko1holi9ij"><rect id="SvgjsRect3307" width="70" height="26" x="-3" y="-1" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath><clipPath id="forecastMasko1holi9ij"></clipPath><clipPath id="nonForecastMasko1holi9ij"></clipPath><clipPath id="gridRectMarkerMasko1holi9ij"><rect id="SvgjsRect3308" width="68" height="28" x="-2" y="-2" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath></defs><line id="SvgjsLine3306" x1="0" y1="0" x2="0" y2="24" stroke="#b6b6b6" stroke-dasharray="3" stroke-linecap="butt" class="apexcharts-xcrosshairs" x="0" y="0" width="1" height="24" fill="#b1b9c4" filter="none" fill-opacity="0.9" stroke-width="1"></line><g id="SvgjsG3314" class="apexcharts-xaxis" transform="translate(0, 0)"><g id="SvgjsG3315" class="apexcharts-xaxis-texts-g" transform="translate(0, -4)"></g></g><g id="SvgjsG3326" class="apexcharts-grid"><g id="SvgjsG3327" class="apexcharts-gridlines-horizontal" style="display: none;"><line id="SvgjsLine3329" x1="0" y1="0" x2="64" y2="0" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3330" x1="0" y1="4.8" x2="64" y2="4.8" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3331" x1="0" y1="9.6" x2="64" y2="9.6" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3332" x1="0" y1="14.399999999999999" x2="64" y2="14.399999999999999" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3333" x1="0" y1="19.2" x2="64" y2="19.2" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3334" x1="0" y1="24" x2="64" y2="24" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line></g><g id="SvgjsG3328" class="apexcharts-gridlines-vertical" style="display: none;"></g><line id="SvgjsLine3336" x1="0" y1="24" x2="64" y2="24" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line><line id="SvgjsLine3335" x1="0" y1="1" x2="0" y2="24" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line></g><g id="SvgjsG3309" class="apexcharts-line-series apexcharts-plot-series"><g id="SvgjsG3310" class="apexcharts-series" seriesName="seriesx1" data:longestSeries="true" rel="1" data:realIndex="0"><path id="SvgjsPath3313" d="M 0 14.4L 8 11.520000000000001L 16 14.4L 24 20.16L 32 7.68L 40 21.12L 48 1.9200000000000017L 56 2.8800000000000026L 64 5.760000000000002" fill="none" fill-opacity="1" stroke="rgba(32,107,196,0.85)" stroke-opacity="1" stroke-linecap="round" stroke-width="2" stroke-dasharray="0" class="apexcharts-line" index="0" clip-path="url(#gridRectMasko1holi9ij)" pathTo="M 0 14.4L 8 11.520000000000001L 16 14.4L 24 20.16L 32 7.68L 40 21.12L 48 1.9200000000000017L 56 2.8800000000000026L 64 5.760000000000002" pathFrom="M -1 24L -1 24L 8 24L 16 24L 24 24L 32 24L 40 24L 48 24L 56 24L 64 24"></path><g id="SvgjsG3311" class="apexcharts-series-markers-wrap" data:realIndex="0"></g></g><g id="SvgjsG3312" class="apexcharts-datalabels" data:realIndex="0"></g></g><line id="SvgjsLine3337" x1="0" y1="0" x2="64" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" stroke-linecap="butt" class="apexcharts-ycrosshairs"></line><line id="SvgjsLine3338" x1="0" y1="0" x2="64" y2="0" stroke-dasharray="0" stroke-width="0" stroke-linecap="butt" class="apexcharts-ycrosshairs-hidden"></line><g id="SvgjsG3339" class="apexcharts-yaxis-annotations"></g><g id="SvgjsG3340" class="apexcharts-xaxis-annotations"></g><g id="SvgjsG3341" class="apexcharts-point-annotations"></g></g><rect id="SvgjsRect3305" width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe"></rect><g id="SvgjsG3325" class="apexcharts-yaxis" rel="0" transform="translate(-18, 0)"></g><g id="SvgjsG3303" class="apexcharts-annotations"></g></svg><div class="apexcharts-legend" style="max-height: 12px;"></div></div></div>
                      <div class="resize-triggers"><div class="expand-trigger"><div style="width: 89px; height: 41px;"></div></div><div class="contract-trigger"></div></div></td>
                    </tr>
                    <tr>
                      <td>
                        /lorem-ipsum-dolor-sit-amet-very-long-url.html
                        <a href="#" class="ms-1" aria-label="Open website"><!-- Download SVG icon from http://tabler-icons.io/i/link -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M10 14a3.5 3.5 0 0 0 5 0l4 -4a3.5 3.5 0 0 0 -5 -5l-.5 .5"></path><path d="M14 10a3.5 3.5 0 0 0 -5 0l-4 4a3.5 3.5 0 0 0 5 5l.5 -.5"></path></svg>
                        </a>
                      </td>
                      <td class="text-muted">986</td>
                      <td class="text-muted">865</td>
                      <td class="text-muted">44.89%</td>
                      <td class="text-end w-1" style="position: relative;">
                        <div class="chart-sparkline chart-sparkline-sm" id="sparkline-bounce-rate-4" style="min-height: 24px;"><div id="apexchartsamgocdn6" class="apexcharts-canvas apexchartsamgocdn6 apexcharts-theme-light" style="width: 64px; height: 24px;"><svg id="SvgjsSvg3342" width="64" height="24" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;"><g id="SvgjsG3344" class="apexcharts-inner apexcharts-graphical" transform="translate(0, 0)"><defs id="SvgjsDefs3343"><clipPath id="gridRectMaskamgocdn6"><rect id="SvgjsRect3349" width="70" height="26" x="-3" y="-1" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath><clipPath id="forecastMaskamgocdn6"></clipPath><clipPath id="nonForecastMaskamgocdn6"></clipPath><clipPath id="gridRectMarkerMaskamgocdn6"><rect id="SvgjsRect3350" width="68" height="28" x="-2" y="-2" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath></defs><line id="SvgjsLine3348" x1="0" y1="0" x2="0" y2="24" stroke="#b6b6b6" stroke-dasharray="3" stroke-linecap="butt" class="apexcharts-xcrosshairs" x="0" y="0" width="1" height="24" fill="#b1b9c4" filter="none" fill-opacity="0.9" stroke-width="1"></line><g id="SvgjsG3356" class="apexcharts-xaxis" transform="translate(0, 0)"><g id="SvgjsG3357" class="apexcharts-xaxis-texts-g" transform="translate(0, -4)"></g></g><g id="SvgjsG3368" class="apexcharts-grid"><g id="SvgjsG3369" class="apexcharts-gridlines-horizontal" style="display: none;"><line id="SvgjsLine3371" x1="0" y1="0" x2="64" y2="0" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3372" x1="0" y1="6" x2="64" y2="6" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3373" x1="0" y1="12" x2="64" y2="12" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3374" x1="0" y1="18" x2="64" y2="18" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3375" x1="0" y1="24" x2="64" y2="24" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line></g><g id="SvgjsG3370" class="apexcharts-gridlines-vertical" style="display: none;"></g><line id="SvgjsLine3377" x1="0" y1="24" x2="64" y2="24" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line><line id="SvgjsLine3376" x1="0" y1="1" x2="0" y2="24" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line></g><g id="SvgjsG3351" class="apexcharts-line-series apexcharts-plot-series"><g id="SvgjsG3352" class="apexcharts-series" seriesName="seriesx1" data:longestSeries="true" rel="1" data:realIndex="0"><path id="SvgjsPath3355" d="M 0 21L 8 7.5L 16 10.5L 24 10.5L 32 22.5L 40 19.5L 48 4.5L 56 0L 64 1.5" fill="none" fill-opacity="1" stroke="rgba(32,107,196,0.85)" stroke-opacity="1" stroke-linecap="round" stroke-width="2" stroke-dasharray="0" class="apexcharts-line" index="0" clip-path="url(#gridRectMaskamgocdn6)" pathTo="M 0 21L 8 7.5L 16 10.5L 24 10.5L 32 22.5L 40 19.5L 48 4.5L 56 0L 64 1.5" pathFrom="M -1 30L -1 30L 8 30L 16 30L 24 30L 32 30L 40 30L 48 30L 56 30L 64 30"></path><g id="SvgjsG3353" class="apexcharts-series-markers-wrap" data:realIndex="0"></g></g><g id="SvgjsG3354" class="apexcharts-datalabels" data:realIndex="0"></g></g><line id="SvgjsLine3378" x1="0" y1="0" x2="64" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" stroke-linecap="butt" class="apexcharts-ycrosshairs"></line><line id="SvgjsLine3379" x1="0" y1="0" x2="64" y2="0" stroke-dasharray="0" stroke-width="0" stroke-linecap="butt" class="apexcharts-ycrosshairs-hidden"></line><g id="SvgjsG3380" class="apexcharts-yaxis-annotations"></g><g id="SvgjsG3381" class="apexcharts-xaxis-annotations"></g><g id="SvgjsG3382" class="apexcharts-point-annotations"></g></g><rect id="SvgjsRect3347" width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe"></rect><g id="SvgjsG3367" class="apexcharts-yaxis" rel="0" transform="translate(-18, 0)"></g><g id="SvgjsG3345" class="apexcharts-annotations"></g></svg><div class="apexcharts-legend" style="max-height: 12px;"></div></div></div>
                      <div class="resize-triggers"><div class="expand-trigger"><div style="width: 89px; height: 41px;"></div></div><div class="contract-trigger"></div></div></td>
                    </tr>
                    <tr>
                      <td>
                        /colors.html
                        <a href="#" class="ms-1" aria-label="Open website"><!-- Download SVG icon from http://tabler-icons.io/i/link -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M10 14a3.5 3.5 0 0 0 5 0l4 -4a3.5 3.5 0 0 0 -5 -5l-.5 .5"></path><path d="M14 10a3.5 3.5 0 0 0 -5 0l-4 4a3.5 3.5 0 0 0 5 5l.5 -.5"></path></svg>
                        </a>
                      </td>
                      <td class="text-muted">912</td>
                      <td class="text-muted">822</td>
                      <td class="text-muted">41.12%</td>
                      <td class="text-end w-1" style="position: relative;">
                        <div class="chart-sparkline chart-sparkline-sm" id="sparkline-bounce-rate-5" style="min-height: 24px;"><div id="apexchartskxq5j2y7" class="apexcharts-canvas apexchartskxq5j2y7 apexcharts-theme-light" style="width: 64px; height: 24px;"><svg id="SvgjsSvg3383" width="64" height="24" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;"><g id="SvgjsG3385" class="apexcharts-inner apexcharts-graphical" transform="translate(0, 0)"><defs id="SvgjsDefs3384"><clipPath id="gridRectMaskkxq5j2y7"><rect id="SvgjsRect3391" width="70" height="26" x="-3" y="-1" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath><clipPath id="forecastMaskkxq5j2y7"></clipPath><clipPath id="nonForecastMaskkxq5j2y7"></clipPath><clipPath id="gridRectMarkerMaskkxq5j2y7"><rect id="SvgjsRect3392" width="68" height="28" x="-2" y="-2" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath></defs><line id="SvgjsLine3390" x1="0" y1="0" x2="0" y2="24" stroke="#b6b6b6" stroke-dasharray="3" stroke-linecap="butt" class="apexcharts-xcrosshairs" x="0" y="0" width="1" height="24" fill="#b1b9c4" filter="none" fill-opacity="0.9" stroke-width="1"></line><g id="SvgjsG3398" class="apexcharts-xaxis" transform="translate(0, 0)"><g id="SvgjsG3399" class="apexcharts-xaxis-texts-g" transform="translate(0, 4)"></g></g><g id="SvgjsG3411" class="apexcharts-grid"><g id="SvgjsG3412" class="apexcharts-gridlines-horizontal" style="display: none;"><line id="SvgjsLine3414" x1="0" y1="0" x2="64" y2="0" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3415" x1="0" y1="4.8" x2="64" y2="4.8" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3416" x1="0" y1="9.6" x2="64" y2="9.6" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3417" x1="0" y1="14.399999999999999" x2="64" y2="14.399999999999999" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3418" x1="0" y1="19.2" x2="64" y2="19.2" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3419" x1="0" y1="24" x2="64" y2="24" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line></g><g id="SvgjsG3413" class="apexcharts-gridlines-vertical" style="display: none;"></g><line id="SvgjsLine3421" x1="0" y1="24" x2="64" y2="24" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line><line id="SvgjsLine3420" x1="0" y1="1" x2="0" y2="24" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line></g><g id="SvgjsG3393" class="apexcharts-line-series apexcharts-plot-series"><g id="SvgjsG3394" class="apexcharts-series" seriesName="seriesx1" data:longestSeries="true" rel="1" data:realIndex="0"><path id="SvgjsPath3397" d="M 0 22.08L 7.111111111111111 13.440000000000001L 14.222222222222221 9.600000000000001L 21.333333333333332 10.56L 28.444444444444443 3.84L 35.55555555555556 4.800000000000001L 42.666666666666664 16.32L 49.77777777777778 1.9200000000000017L 56.888888888888886 6.720000000000002L 64 10.56" fill="none" fill-opacity="1" stroke="rgba(32,107,196,0.85)" stroke-opacity="1" stroke-linecap="round" stroke-width="2" stroke-dasharray="0" class="apexcharts-line" index="0" clip-path="url(#gridRectMaskkxq5j2y7)" pathTo="M 0 22.08L 7.111111111111111 13.440000000000001L 14.222222222222221 9.600000000000001L 21.333333333333332 10.56L 28.444444444444443 3.84L 35.55555555555556 4.800000000000001L 42.666666666666664 16.32L 49.77777777777778 1.9200000000000017L 56.888888888888886 6.720000000000002L 64 10.56" pathFrom="M -1 24L -1 24L 7.111111111111111 24L 14.222222222222221 24L 21.333333333333332 24L 28.444444444444443 24L 35.55555555555556 24L 42.666666666666664 24L 49.77777777777778 24L 56.888888888888886 24L 64 24"></path><g id="SvgjsG3395" class="apexcharts-series-markers-wrap" data:realIndex="0"></g></g><g id="SvgjsG3396" class="apexcharts-datalabels" data:realIndex="0"></g></g><line id="SvgjsLine3422" x1="0" y1="0" x2="64" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" stroke-linecap="butt" class="apexcharts-ycrosshairs"></line><line id="SvgjsLine3423" x1="0" y1="0" x2="64" y2="0" stroke-dasharray="0" stroke-width="0" stroke-linecap="butt" class="apexcharts-ycrosshairs-hidden"></line><g id="SvgjsG3424" class="apexcharts-yaxis-annotations"></g><g id="SvgjsG3425" class="apexcharts-xaxis-annotations"></g><g id="SvgjsG3426" class="apexcharts-point-annotations"></g></g><rect id="SvgjsRect3389" width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe"></rect><g id="SvgjsG3410" class="apexcharts-yaxis" rel="0" transform="translate(-18, 0)"></g><g id="SvgjsG3386" class="apexcharts-annotations"></g></svg><div class="apexcharts-legend" style="max-height: 12px;"></div></div></div>
                      <div class="resize-triggers"><div class="expand-trigger"><div style="width: 89px; height: 41px;"></div></div><div class="contract-trigger"></div></div></td>
                    </tr>
                    <tr>
                      <td>
                        /docs/index.html
                        <a href="#" class="ms-1" aria-label="Open website"><!-- Download SVG icon from http://tabler-icons.io/i/link -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M10 14a3.5 3.5 0 0 0 5 0l4 -4a3.5 3.5 0 0 0 -5 -5l-.5 .5"></path><path d="M14 10a3.5 3.5 0 0 0 -5 0l-4 4a3.5 3.5 0 0 0 5 5l.5 -.5"></path></svg>
                        </a>
                      </td>
                      <td class="text-muted">855</td>
                      <td class="text-muted">798</td>
                      <td class="text-muted">32.65%</td>
                      <td class="text-end w-1" style="position: relative;">
                        <div class="chart-sparkline chart-sparkline-sm" id="sparkline-bounce-rate-6" style="min-height: 24px;"><div id="apexchartsz7mrvs3f" class="apexcharts-canvas apexchartsz7mrvs3f apexcharts-theme-light" style="width: 64px; height: 24px;"><svg id="SvgjsSvg3427" width="64" height="24" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.dev" class="apexcharts-svg" xmlns:data="ApexChartsNS" transform="translate(0, 0)" style="background: transparent;"><g id="SvgjsG3429" class="apexcharts-inner apexcharts-graphical" transform="translate(0, 0)"><defs id="SvgjsDefs3428"><clipPath id="gridRectMaskz7mrvs3f"><rect id="SvgjsRect3435" width="70" height="26" x="-3" y="-1" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath><clipPath id="forecastMaskz7mrvs3f"></clipPath><clipPath id="nonForecastMaskz7mrvs3f"></clipPath><clipPath id="gridRectMarkerMaskz7mrvs3f"><rect id="SvgjsRect3436" width="68" height="28" x="-2" y="-2" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fff"></rect></clipPath></defs><line id="SvgjsLine3434" x1="0" y1="0" x2="0" y2="24" stroke="#b6b6b6" stroke-dasharray="3" stroke-linecap="butt" class="apexcharts-xcrosshairs" x="0" y="0" width="1" height="24" fill="#b1b9c4" filter="none" fill-opacity="0.9" stroke-width="1"></line><g id="SvgjsG3442" class="apexcharts-xaxis" transform="translate(0, 0)"><g id="SvgjsG3443" class="apexcharts-xaxis-texts-g" transform="translate(0, 4)"></g></g><g id="SvgjsG3455" class="apexcharts-grid"><g id="SvgjsG3456" class="apexcharts-gridlines-horizontal" style="display: none;"><line id="SvgjsLine3458" x1="0" y1="0" x2="64" y2="0" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3459" x1="0" y1="4.8" x2="64" y2="4.8" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3460" x1="0" y1="9.6" x2="64" y2="9.6" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3461" x1="0" y1="14.399999999999999" x2="64" y2="14.399999999999999" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3462" x1="0" y1="19.2" x2="64" y2="19.2" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line><line id="SvgjsLine3463" x1="0" y1="24" x2="64" y2="24" stroke="#e0e0e0" stroke-dasharray="0" stroke-linecap="butt" class="apexcharts-gridline"></line></g><g id="SvgjsG3457" class="apexcharts-gridlines-vertical" style="display: none;"></g><line id="SvgjsLine3465" x1="0" y1="24" x2="64" y2="24" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line><line id="SvgjsLine3464" x1="0" y1="1" x2="0" y2="24" stroke="transparent" stroke-dasharray="0" stroke-linecap="butt"></line></g><g id="SvgjsG3437" class="apexcharts-line-series apexcharts-plot-series"><g id="SvgjsG3438" class="apexcharts-series" seriesName="seriesx1" data:longestSeries="true" rel="1" data:realIndex="0"><path id="SvgjsPath3441" d="M 0 2.8800000000000026L 7.111111111111111 12.48L 14.222222222222221 17.28L 21.333333333333332 10.56L 28.444444444444443 21.12L 35.55555555555556 3.84L 42.666666666666664 16.32L 49.77777777777778 1.9200000000000017L 56.888888888888886 6.720000000000002L 64 10.56" fill="none" fill-opacity="1" stroke="rgba(32,107,196,0.85)" stroke-opacity="1" stroke-linecap="round" stroke-width="2" stroke-dasharray="0" class="apexcharts-line" index="0" clip-path="url(#gridRectMaskz7mrvs3f)" pathTo="M 0 2.8800000000000026L 7.111111111111111 12.48L 14.222222222222221 17.28L 21.333333333333332 10.56L 28.444444444444443 21.12L 35.55555555555556 3.84L 42.666666666666664 16.32L 49.77777777777778 1.9200000000000017L 56.888888888888886 6.720000000000002L 64 10.56" pathFrom="M -1 24L -1 24L 7.111111111111111 24L 14.222222222222221 24L 21.333333333333332 24L 28.444444444444443 24L 35.55555555555556 24L 42.666666666666664 24L 49.77777777777778 24L 56.888888888888886 24L 64 24"></path><g id="SvgjsG3439" class="apexcharts-series-markers-wrap" data:realIndex="0"></g></g><g id="SvgjsG3440" class="apexcharts-datalabels" data:realIndex="0"></g></g><line id="SvgjsLine3466" x1="0" y1="0" x2="64" y2="0" stroke="#b6b6b6" stroke-dasharray="0" stroke-width="1" stroke-linecap="butt" class="apexcharts-ycrosshairs"></line><line id="SvgjsLine3467" x1="0" y1="0" x2="64" y2="0" stroke-dasharray="0" stroke-width="0" stroke-linecap="butt" class="apexcharts-ycrosshairs-hidden"></line><g id="SvgjsG3468" class="apexcharts-yaxis-annotations"></g><g id="SvgjsG3469" class="apexcharts-xaxis-annotations"></g><g id="SvgjsG3470" class="apexcharts-point-annotations"></g></g><rect id="SvgjsRect3433" width="0" height="0" x="0" y="0" rx="0" ry="0" opacity="1" stroke-width="0" stroke="none" stroke-dasharray="0" fill="#fefefe"></rect><g id="SvgjsG3454" class="apexcharts-yaxis" rel="0" transform="translate(-18, 0)"></g><g id="SvgjsG3430" class="apexcharts-annotations"></g></svg><div class="apexcharts-legend" style="max-height: 12px;"></div></div></div>
                      <div class="resize-triggers"><div class="expand-trigger"><div style="width: 89px; height: 41px;"></div></div><div class="contract-trigger"></div></div></td>
                    </tr>
                  </tbody></table>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4">
              <a href="https://github.com/sponsors/codecalm" class="card card-sponsor" target="_blank" rel="noopener" style="background-image: url(./static/sponsor-banner-homepage.svg)" aria-label="Sponsor Tabler!">
                <div class="card-body"></div>
              </a>
            </div>
            <div class="col-md-6 col-lg-4">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Social Media Traffic</h3>
                </div>
                <table class="table card-table table-vcenter">
                  <thead>
                    <tr>
                      <th>Network</th>
                      <th colspan="2">Visitors</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Instagram</td>
                      <td>3,550</td>
                      <td class="w-50">
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-primary" style="width: 71.0%"></div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>Twitter</td>
                      <td>1,798</td>
                      <td class="w-50">
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-primary" style="width: 35.96%"></div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>Facebook</td>
                      <td>1,245</td>
                      <td class="w-50">
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-primary" style="width: 24.9%"></div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>TikTok</td>
                      <td>986</td>
                      <td class="w-50">
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-primary" style="width: 19.72%"></div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>Pinterest</td>
                      <td>854</td>
                      <td class="w-50">
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-primary" style="width: 17.08%"></div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>VK</td>
                      <td>650</td>
                      <td class="w-50">
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-primary" style="width: 13.0%"></div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>Pinterest</td>
                      <td>420</td>
                      <td class="w-50">
                        <div class="progress progress-xs">
                          <div class="progress-bar bg-primary" style="width: 8.4%"></div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="col-md-12 col-lg-8">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Tasks</h3>
                </div>
                <div class="table-responsive">
                  <table class="table card-table table-vcenter">
                    <tbody><tr>
                      <td class="w-1 pe-0">
                        <input type="checkbox" class="form-check-input m-0 align-middle" aria-label="Select task" checked="">
                      </td>
                      <td class="w-100">
                        <a href="#" class="text-reset">Extend the data model.</a>
                      </td>
                      <td class="text-nowrap text-muted">
                        <!-- Download SVG icon from http://tabler-icons.io/i/calendar -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><rect x="4" y="5" width="16" height="16" rx="2"></rect><line x1="16" y1="3" x2="16" y2="7"></line><line x1="8" y1="3" x2="8" y2="7"></line><line x1="4" y1="11" x2="20" y2="11"></line><line x1="11" y1="15" x2="12" y2="15"></line><line x1="12" y1="15" x2="12" y2="18"></line></svg>
                        January 01, 2019
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/check -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M5 12l5 5l10 -10"></path></svg>
                          2/7
                        </a>
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/message -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4"></path><line x1="8" y1="9" x2="16" y2="9"></line><line x1="8" y1="13" x2="14" y2="13"></line></svg>
                          3</a>
                      </td>
                      <td>
                        <span class="avatar avatar-sm" style="background-image: url(./static/avatars/000m.jpg)"></span>
                      </td>
                    </tr>
                    <tr>
                      <td class="w-1 pe-0">
                        <input type="checkbox" class="form-check-input m-0 align-middle" aria-label="Select task">
                      </td>
                      <td class="w-100">
                        <a href="#" class="text-reset">Verify the event flow.</a>
                      </td>
                      <td class="text-nowrap text-muted">
                        <!-- Download SVG icon from http://tabler-icons.io/i/calendar -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><rect x="4" y="5" width="16" height="16" rx="2"></rect><line x1="16" y1="3" x2="16" y2="7"></line><line x1="8" y1="3" x2="8" y2="7"></line><line x1="4" y1="11" x2="20" y2="11"></line><line x1="11" y1="15" x2="12" y2="15"></line><line x1="12" y1="15" x2="12" y2="18"></line></svg>
                        January 01, 2019
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/check -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M5 12l5 5l10 -10"></path></svg>
                          3/10
                        </a>
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/message -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4"></path><line x1="8" y1="9" x2="16" y2="9"></line><line x1="8" y1="13" x2="14" y2="13"></line></svg>
                          6</a>
                      </td>
                      <td>
                        <span class="avatar avatar-sm">JL</span>
                      </td>
                    </tr>
                    <tr>
                      <td class="w-1 pe-0">
                        <input type="checkbox" class="form-check-input m-0 align-middle" aria-label="Select task">
                      </td>
                      <td class="w-100">
                        <a href="#" class="text-reset">Database backup and maintenance</a>
                      </td>
                      <td class="text-nowrap text-muted">
                        <!-- Download SVG icon from http://tabler-icons.io/i/calendar -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><rect x="4" y="5" width="16" height="16" rx="2"></rect><line x1="16" y1="3" x2="16" y2="7"></line><line x1="8" y1="3" x2="8" y2="7"></line><line x1="4" y1="11" x2="20" y2="11"></line><line x1="11" y1="15" x2="12" y2="15"></line><line x1="12" y1="15" x2="12" y2="18"></line></svg>
                        January 01, 2019
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/check -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M5 12l5 5l10 -10"></path></svg>
                          0/6
                        </a>
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/message -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4"></path><line x1="8" y1="9" x2="16" y2="9"></line><line x1="8" y1="13" x2="14" y2="13"></line></svg>
                          1</a>
                      </td>
                      <td>
                        <span class="avatar avatar-sm" style="background-image: url(./static/avatars/002m.jpg)"></span>
                      </td>
                    </tr>
                    <tr>
                      <td class="w-1 pe-0">
                        <input type="checkbox" class="form-check-input m-0 align-middle" aria-label="Select task" checked="">
                      </td>
                      <td class="w-100">
                        <a href="#" class="text-reset">Identify the implementation team.</a>
                      </td>
                      <td class="text-nowrap text-muted">
                        <!-- Download SVG icon from http://tabler-icons.io/i/calendar -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><rect x="4" y="5" width="16" height="16" rx="2"></rect><line x1="16" y1="3" x2="16" y2="7"></line><line x1="8" y1="3" x2="8" y2="7"></line><line x1="4" y1="11" x2="20" y2="11"></line><line x1="11" y1="15" x2="12" y2="15"></line><line x1="12" y1="15" x2="12" y2="18"></line></svg>
                        January 01, 2019
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/check -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M5 12l5 5l10 -10"></path></svg>
                          6/10
                        </a>
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/message -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4"></path><line x1="8" y1="9" x2="16" y2="9"></line><line x1="8" y1="13" x2="14" y2="13"></line></svg>
                          12</a>
                      </td>
                      <td>
                        <span class="avatar avatar-sm" style="background-image: url(./static/avatars/003m.jpg)"></span>
                      </td>
                    </tr>
                    <tr>
                      <td class="w-1 pe-0">
                        <input type="checkbox" class="form-check-input m-0 align-middle" aria-label="Select task">
                      </td>
                      <td class="w-100">
                        <a href="#" class="text-reset">Define users and workflow</a>
                      </td>
                      <td class="text-nowrap text-muted">
                        <!-- Download SVG icon from http://tabler-icons.io/i/calendar -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><rect x="4" y="5" width="16" height="16" rx="2"></rect><line x1="16" y1="3" x2="16" y2="7"></line><line x1="8" y1="3" x2="8" y2="7"></line><line x1="4" y1="11" x2="20" y2="11"></line><line x1="11" y1="15" x2="12" y2="15"></line><line x1="12" y1="15" x2="12" y2="18"></line></svg>
                        January 01, 2019
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/check -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M5 12l5 5l10 -10"></path></svg>
                          3/7
                        </a>
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/message -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4"></path><line x1="8" y1="9" x2="16" y2="9"></line><line x1="8" y1="13" x2="14" y2="13"></line></svg>
                          5</a>
                      </td>
                      <td>
                        <span class="avatar avatar-sm" style="background-image: url(./static/avatars/000f.jpg)"></span>
                      </td>
                    </tr>
                    <tr>
                      <td class="w-1 pe-0">
                        <input type="checkbox" class="form-check-input m-0 align-middle" aria-label="Select task" checked="">
                      </td>
                      <td class="w-100">
                        <a href="#" class="text-reset">Check Pull Requests</a>
                      </td>
                      <td class="text-nowrap text-muted">
                        <!-- Download SVG icon from http://tabler-icons.io/i/calendar -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><rect x="4" y="5" width="16" height="16" rx="2"></rect><line x1="16" y1="3" x2="16" y2="7"></line><line x1="8" y1="3" x2="8" y2="7"></line><line x1="4" y1="11" x2="20" y2="11"></line><line x1="11" y1="15" x2="12" y2="15"></line><line x1="12" y1="15" x2="12" y2="18"></line></svg>
                        January 01, 2019
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/check -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M5 12l5 5l10 -10"></path></svg>
                          2/9
                        </a>
                      </td>
                      <td class="text-nowrap">
                        <a href="#" class="text-muted">
                          <!-- Download SVG icon from http://tabler-icons.io/i/message -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><path d="M4 21v-13a3 3 0 0 1 3 -3h10a3 3 0 0 1 3 3v6a3 3 0 0 1 -3 3h-9l-4 4"></path><line x1="8" y1="9" x2="16" y2="9"></line><line x1="8" y1="13" x2="14" y2="13"></line></svg>
                          3</a>
                      </td>
                      <td>
                        <span class="avatar avatar-sm" style="background-image: url(./static/avatars/001f.jpg)"></span>
                      </td>
                    </tr>
                  </tbody></table>
                </div>
              </div>
            </div>
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">Invoices</h3>
                </div>
                <div class="card-body border-bottom py-3">
                  <div class="d-flex">
                    <div class="text-muted">
                      Show
                      <div class="mx-2 d-inline-block">
                        <input type="text" class="form-control form-control-sm" value="8" size="3" aria-label="Invoices count">
                      </div>
                      entries
                    </div>
                    <div class="ms-auto text-muted">
                      Search:
                      <div class="ms-2 d-inline-block">
                        <input type="text" class="form-control form-control-sm" aria-label="Search invoice">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table card-table table-vcenter text-nowrap datatable">
                    <thead>
                      <tr>
                        <th class="w-1"><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select all invoices"></th>
                        <th class="w-1">No. <!-- Download SVG icon from http://tabler-icons.io/i/chevron-up -->
                          <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-sm text-dark icon-thick" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="6 15 12 9 18 15"></polyline></svg>
                        </th>
                        <th>Invoice Subject</th>
                        <th>Client</th>
                        <th>VAT No.</th>
                        <th>Created</th>
                        <th>Status</th>
                        <th>Price</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001401</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">Design Works</a></td>
                        <td>
                          <span class="flag flag-country-us"></span>
                          Carlson Limited
                        </td>
                        <td>
                          87956621
                        </td>
                        <td>
                          15 Dec 2017
                        </td>
                        <td>
                          <span class="badge bg-success me-1"></span> Paid
                        </td>
                        <td>$887</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001402</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">UX Wireframes</a></td>
                        <td>
                          <span class="flag flag-country-gb"></span>
                          Adobe
                        </td>
                        <td>
                          87956421
                        </td>
                        <td>
                          12 Apr 2017
                        </td>
                        <td>
                          <span class="badge bg-warning me-1"></span> Pending
                        </td>
                        <td>$1200</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001403</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">New Dashboard</a></td>
                        <td>
                          <span class="flag flag-country-de"></span>
                          Bluewolf
                        </td>
                        <td>
                          87952621
                        </td>
                        <td>
                          23 Oct 2017
                        </td>
                        <td>
                          <span class="badge bg-warning me-1"></span> Pending
                        </td>
                        <td>$534</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001404</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">Landing Page</a></td>
                        <td>
                          <span class="flag flag-country-br"></span>
                          Salesforce
                        </td>
                        <td>
                          87953421
                        </td>
                        <td>
                          2 Sep 2017
                        </td>
                        <td>
                          <span class="badge bg-secondary me-1"></span> Due in 2 Weeks
                        </td>
                        <td>$1500</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001405</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">Marketing Templates</a></td>
                        <td>
                          <span class="flag flag-country-pl"></span>
                          Printic
                        </td>
                        <td>
                          87956621
                        </td>
                        <td>
                          29 Jan 2018
                        </td>
                        <td>
                          <span class="badge bg-danger me-1"></span> Paid Today
                        </td>
                        <td>$648</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001406</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">Sales Presentation</a></td>
                        <td>
                          <span class="flag flag-country-br"></span>
                          Tabdaq
                        </td>
                        <td>
                          87956621
                        </td>
                        <td>
                          4 Feb 2018
                        </td>
                        <td>
                          <span class="badge bg-secondary me-1"></span> Due in 3 Weeks
                        </td>
                        <td>$300</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001407</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">Logo &amp; Print</a></td>
                        <td>
                          <span class="flag flag-country-us"></span>
                          Apple
                        </td>
                        <td>
                          87956621
                        </td>
                        <td>
                          22 Mar 2018
                        </td>
                        <td>
                          <span class="badge bg-success me-1"></span> Paid Today
                        </td>
                        <td>$2500</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                      <tr>
                        <td><input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Select invoice"></td>
                        <td><span class="text-muted">001408</span></td>
                        <td><a href="invoice.html" class="text-reset" tabindex="-1">Icons</a></td>
                        <td>
                          <span class="flag flag-country-pl"></span>
                          Tookapic
                        </td>
                        <td>
                          87956621
                        </td>
                        <td>
                          13 May 2018
                        </td>
                        <td>
                          <span class="badge bg-success me-1"></span> Paid Today
                        </td>
                        <td>$940</td>
                        <td class="text-end">
                          <span class="dropdown">
                            <button class="btn dropdown-toggle align-text-top" data-bs-boundary="viewport" data-bs-toggle="dropdown">Actions</button>
                            <div class="dropdown-menu dropdown-menu-end">
                              <a class="dropdown-item" href="#">
                                Action
                              </a>
                              <a class="dropdown-item" href="#">
                                Another action
                              </a>
                            </div>
                          </span>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="card-footer d-flex align-items-center">
                  <p class="m-0 text-muted">Showing <span>1</span> to <span>8</span> of <span>16</span> entries</p>
                  <ul class="pagination m-0 ms-auto">
                    <li class="page-item disabled">
                      <a class="page-link" href="#" tabindex="-1" aria-disabled="true">
                        <!-- Download SVG icon from http://tabler-icons.io/i/chevron-left -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="15 6 9 12 15 18"></polyline></svg>
                        prev
                      </a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                    <li class="page-item active"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item"><a class="page-link" href="#">4</a></li>
                    <li class="page-item"><a class="page-link" href="#">5</a></li>
                    <li class="page-item">
                      <a class="page-link" href="#">
                        next <!-- Download SVG icon from http://tabler-icons.io/i/chevron-right -->
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round"><path stroke="none" d="M0 0h24v24H0z" fill="none"></path><polyline points="9 6 15 12 9 18"></polyline></svg>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH G:\laravelProject\cafetejarat\resources\views/admin/index.blade.php ENDPATH**/ ?>