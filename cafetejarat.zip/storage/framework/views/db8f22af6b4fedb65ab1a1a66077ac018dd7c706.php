<?php $__env->startSection('main_body'); ?>
<div class="content-box">
    <div class="main-title">
        <h3>پیامها</h3>
        <a href="<?php echo e(route('login')); ?>"></a>
    </div>

    <div class="box-content">
        <?php echo $__env->make('home.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('agent.submit.questions')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

        <div class="profile-top mb20">
            <div class="img">
                <img src="<?php echo e($user->avatar()); ?>" alt="">
            </div>
            <div class="lefts">
                <h4>
                    <?php echo e($user->name); ?>

                    <?php echo e($user->family); ?>

                </h4>
                
            </div>
        </div>
        <div class="messages">
                <ul id="qlist">
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <h4> <?php echo e($question->q); ?> </h4>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div>
                                        <input type="text" name="video_id"  hidden value="<?php echo e($video->id); ?>">
                                        <input type="text" name="q<?php echo e($loop->iteration); ?>"  hidden value="0">
                                        <input type="radio" value="a" name="q<?php echo e($loop->iteration); ?>" id="a<?php echo e($question->id); ?>">
                                        <label for="a<?php echo e($question->id); ?>"> <?php echo e($question->a); ?></label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div>
                                        <input type="radio" value="b" name="q<?php echo e($loop->iteration); ?>" id="b<?php echo e($question->id); ?>">
                                        <label for="b<?php echo e($question->id); ?>"> <?php echo e($question->b); ?></label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div>
                                        <input type="radio" value="c" name="q<?php echo e($loop->iteration); ?>" id="c<?php echo e($question->id); ?>">
                                        <label for="c<?php echo e($question->id); ?>"> <?php echo e($question->c); ?></label>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div>
                                        <input type="radio" value="d" name="q<?php echo e($loop->iteration); ?>" id="d<?php echo e($question->id); ?>">
                                        <label for="d<?php echo e($question->id); ?>"> <?php echo e($question->d); ?></label>
                                    </div>
                                </div>
                            </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </ul>
        </div>
        <div class="col-lg-12">
            <div>
                <div class="button-container" style="margin-top:20px">
                    <button class="green">  ثبت</button>
                    <a href="<?php echo e(route('agent.single.vcat',$video->vcat->id)); ?>">برگشت</a>
                </div>
            </div>
        </div>
    </form>



    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\cafetejarat\resources\views/home/agent/video_questions.blade.php ENDPATH**/ ?>