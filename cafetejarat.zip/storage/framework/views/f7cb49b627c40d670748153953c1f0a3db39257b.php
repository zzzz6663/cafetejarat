<?php if($errors->any()): ?>
    <div class="er">
        <?php echo implode('<br>', $errors->all('<span class="text text-danger">:message</span>')); ?>

    </div>
<?php endif; ?>
<?php /**PATH G:\laravelProject\cafetejarat\resources\views/home/error.blade.php ENDPATH**/ ?>