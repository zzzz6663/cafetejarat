<?php $__env->startSection('main_body'); ?>
<div class="content-box">
    <div class="main-title">
        <h3>پیامها</h3>
        <a href="<?php echo e(route('login')); ?>"></a>
    </div>

    <div class="box-content">
        <?php echo $__env->make('home.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="profile-top mb20">
            <div class="img">
                <img src="<?php echo e($user->avatar()); ?>" alt="">
            </div>
            <div class="lefts">
                <h4>
                    <?php echo e($user->name); ?>

                    <?php echo e($user->family); ?>

                </h4>
                
            </div>
        </div>
        <div class="messages">
            <video   class="js-player2" playsinline  data-poster="<?php echo e($video->cover()); ?>">
                <source src="<?php echo e($video->video()); ?>" type="video/mp4" />
            </video>
        </div>
        <div class="col-lg-12">
            <div>
                <div class="button-container" style="margin-top:20px">
                    <a href="<?php echo e(route('agent.single.vcat',$video->vcat->id)); ?>">برگشت</a>
                </div>
            </div>
        </div>



    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\cafetejarat\resources\views/home/agent/play_video.blade.php ENDPATH**/ ?>