<?php $__env->startSection('main_body'); ?>
<div class="content-box">
    <div class="main-title">
        <h3>پیامها</h3>
        <a href="<?php echo e(route('login')); ?>"></a>
    </div>

    <div class="box-content">


        <div class="profile-top mb20">
            <div class="img">
                <img src="<?php echo e($user->avatar()); ?>" alt="">
            </div>
            <div class="lefts">
                <h4>
                      <?php echo e($user->name); ?>

                      <?php echo e($user->family); ?>

                </h4>
                
            </div>
        </div>

        <div class="profile-tab">
            <div class="tab-nav">
                <ul>
                    <li class="active"><span>دیده نشده  </span></li>
                    <li><span>  دیده شده</span></li>
                </ul>
            </div>


                <div class="tab-container videos ">
                <ul>
                    <li class="active">
                        <div>
                            <?php
                                $i=1
                            ?>
                            <div class="row">
                                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $route='';
                                ?>
                                <?php if(   $user->videos->contains($video->id)): ?>
                                <?php continue; ?>
                                <?php else: ?>
                                <?php
                                if ($i==1   ) {
                                    $route=route('agent.check.video.status',$video->id);
                                }
                                       $i++;
                                ?>
                                <?php endif; ?>

                                <div class="video">

                                    <div class="right">
                                        <div class="img">
                                            <img src="/home/images/html.png" alt="">
                                        </div>
                                    </div>
                                    <div class="left">

                                        <h4><a href="<?php echo e($route); ?>"><?php echo e($video->title); ?>



                                            <?php if($video->type=='money'): ?>
                                            (<?php echo e(number_format($video->price)); ?>

                                            تومان
                                            )
                                            <?php else: ?>
                                            (رایگان)
                                            <?php endif; ?>
                                            <?php if($video->model=='close'): ?>
                                          (سوالی)
                                            <?php else: ?>

                                            <?php endif; ?>

                                        </a></h4>
                                        <p>
                                            <?php echo e($video->content); ?>



                                        </p>
                                        <span style="top:5px" class="con lock"></span>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div>
                            <div class="row">
                                <?php $__currentLoopData = $my_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $my): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="video">

                                    <div class="right">
                                        <div class="img">
                                            <img src="/home/images/html.png" alt="">
                                        </div>
                                    </div>
                                    <div class="left">

                                        <h4><a href="<?php echo e(route('agent.check.video.status',$my->id)); ?>"><?php echo e($my->title); ?>



                                            <?php if($my->type=='money'): ?>
                                            (<?php echo e(number_format($my->price)); ?>

                                            تومان
                                            )
                                            <?php else: ?>
                                            (رایگان)
                                            <?php endif; ?>
                                            <?php if($my->model=='close'): ?>
                                          (سوالی)
                                            <?php else: ?>

                                            <?php endif; ?>

                                        </a></h4>
                                        <p>
                                            <?php echo e($my->content); ?>



                                        </p>
                                        <span style="top:5px" class="con lock"></span>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                    </li>
                </ul>

            </div>
        </div>

        <div class="col-lg-12">
            <div>
                <div class="button-container">
                   <a href="<?php echo e(route('agent.panel')); ?>">برگشت</a>
                </div>
            </div>
        </div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\cafetejarat\resources\views/home/agent/single_vcat.blade.php ENDPATH**/ ?>