<?php $__env->startSection('main_body'); ?>
<div class="content-box">
    <div class="main-title">
        <h3>پیامها</h3>
        <a href="<?php echo e(route('login')); ?>"></a>
    </div>

    <div class="box-content">


        <div class="profile-top mb20">
            <div class="img">
                <img src="images/user3.png" alt="">
            </div>
            <div class="lefts">
                <h4>مقداد خداداد</h4>
                <span>تولید کننده پوشاک</span>
            </div>
        </div>
        <div class="messages">
            <?php $__currentLoopData = $payams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="message <?php echo e($payam->pivot->seen ?'':'bold'); ?>" style="border: none; ">
                <h4 style="display: inline-block; width:80%;"><?php echo e($payam->title); ?> </h4>
                <div  style="display: inline-block; width:20%;" class="button-container">
                  <a style="width: auto;padding:0 10px" href="<?php echo e(route('agent.single.payams' ,$payam->id)); ?>">بیشتر</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>



    </div>
    <div class="col-lg-12" style="margin-bottom: 20px">
        <div>
            <div class="button-container">
               <a href="<?php echo e(route('agent.panel')); ?>">برگشت</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\cafetejarat\resources\views/home/agent/payams.blade.php ENDPATH**/ ?>