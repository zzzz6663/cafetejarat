
<?php /**PATH G:\laravelProject\cafetejarat\resources\views/admin/section/navbar.blade.php ENDPATH**/ ?>