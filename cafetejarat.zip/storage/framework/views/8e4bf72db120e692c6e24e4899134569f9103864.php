<!DOCTYPE html>
<html lang="en" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="/manager/dist/css/tabler.rtl.min.css" rel="stylesheet"/>
    <link href="/manager/dist/css/tabler-flags.rtl.min.css" rel="stylesheet"/>
    <link href="/manager/dist/css/tabler-payments.rtl.min.css" rel="stylesheet"/>
    <link href="/manager/dist/css/tabler-vendors.rtl.min.css" rel="stylesheet"/>
    <link href="/manager/dist/css/demo.rtl.min.css" rel="stylesheet"/>
    <link href="/manager/dist/css/demo.rtl.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="/home/css/iziModal.min.css">
    <link rel="stylesheet" href="/home/css/lightbox.min.css">
    
    <link rel="stylesheet" href="/home/css/plyr.css">
    <link rel="stylesheet" href="/css/app.css">
    <script type="text/javascript" src="/home/js/jquery-2.2.0.min.js"></script>

</head>
<body class="antialiased theme-dark"

<div class="wrapper">

    <?php echo $__env->make('admin.section.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <?php echo $__env->make('admin.section.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="s">
            <?php echo $__env->yieldContent('content'); ?>

        </div>
        <?php echo $__env->make('admin.section.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<script src="/manager/dist/libs/apexcharts/dist/apexcharts.min.js"></script>
<script src="/manager/dist/js/tabler.min.js"></script>
<script src="/home/js/fun.js"></script>
<script type="text/javascript" src="/home/js/iziModal.min.js"></script>
<script type="text/javascript" src="/home/js/lightbox.min.js"></script>
<script type="text/javascript" src="/home/js/plyr.js"></script>

<script type="text/javascript" src="/home/js/home.js"></script>


<script src="<?php echo e(asset('/js/app.js')); ?>"></script>

</body>
<?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>
<?php /**PATH G:\laravelProject\cafetejarat\resources\views/masters/manager.blade.php ENDPATH**/ ?>