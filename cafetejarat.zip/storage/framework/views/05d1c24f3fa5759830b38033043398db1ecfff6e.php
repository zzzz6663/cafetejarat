<?php $__env->startComponent('admin.section.content',['title'=>' داشبورد']); ?>
<?php $__env->slot('bread'); ?>
<li class="breadcrumb-item">پنل مدیریت</li>
<?php $__env->endSlot(); ?>
<div class="container-xl">
    <!-- Page title -->
    <div class="page-header d-print-none">
        <div class="row align-items-center">
            <div class="col">
                <h2 class="page-title">
                    ویرایش ویدئو
                </h2>
            </div>
        </div>
    </div>
</div>

<div class="page-body">
    <div class="container-xl">
        <div class="row row-cards">
            <div class="col-12">
                <div class="card-header">
                    <h4 class="card-title"> ویدئو

                        <?php echo e($video->title); ?>

                    </h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-12">
                            <?php echo $__env->make('home.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <form action="<?php echo e(route('video.update',$video->id)); ?>" class="form-control" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                                <div class="mb-3">
                                    <label class="form-label">نام</label>
                                    <input type="text" name="title" value="<?php echo e(old('title',$video->title)); ?>" class="form-control" name="example-text-input" placeholder="نام      ">
                                </div>



                                <div class="mb-3">
                                    <label class="form-label">توضیحات <span class="form-label-description"></span></label>
                                    <textarea class="form-control" name="content" rows="6" placeholder="Content.."><?php echo e(old('content',$video->content)); ?></textarea>
                                </div>
                                <div class="mb-3">
                                    <div class="form-label"> تصویر کاور</div>
                                    <input style="color: red" type="file" name="cover" accept=".png, .jpg, .jpeg" class="form-control">
                                </div>
                                <div class="mb-3">
                                    <div class="form-label"> ویدئو</div>
                                    <input style="color: red" type="file" name="video" accept=".mp4" class="form-control">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">قیمت</label>
                                    <input type="number" name="price" value="<?php echo e(old('price',$video->price)); ?>" class="form-control" name="example-text-input" placeholder="نام دسته بندی  ">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">ترتیب</label>
                                    <input type="number" name="sort" value="<?php echo e(old('sort',$video->sort)); ?>" class="form-control" name="example-text-input" placeholder="ترتیب      ">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label" for="">دسته بندی</label>
                                    <select class="form-control" value="<?php echo e(old('vcat_id',$video->vcat_id)); ?>" name="vcat_id" id="vcat">
                                        <option selected disabled>دسته بندی</option>
                                        <?php $__currentLoopData = \App\Models\Vcat::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e(old('vcat_id',$video->vcat_id)==$vcat->id?'selected':''); ?> value="<?php echo e($vcat->id); ?>"><?php echo e($vcat->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label" for="type"> نوع قیمت</label>
                                    <select class="form-control" name="type" id="type">
                                        <option value="" disabled> نوع قیمت</option>
                                        <option <?php echo e(old('type',$video->type)=='free'?'selected':''); ?> value="free">رایگان </option>
                                        <option <?php echo e(old('type',$video->type)=='money'?'selected':''); ?> value="money">پولی</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label" for="model"> نوع پخش</label>
                                    <select class="form-control" name="model" id="model">
                                        <option value="" disabled> نوع پخش</option>
                                        <option <?php echo e(old('model',$video->model)=='close'?'selected':''); ?> value="close">بسته </option>
                                        <option <?php echo e(old('model',$video->model)=='open'?'selected':''); ?> value="open">باز</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <video   class="js-player" playsinline controls data-poster="<?php echo e($video->cover()); ?>">
                                        <source src="<?php echo e($video->video()); ?>" type="video/mp4" />

                                    </video>
                                </div>
                                <div class="mb-3">
                                    <button class="btn btn-success">ذخیره</button>
                                    <a class="btn btn-danger" href="<?php echo e(route('video.index')); ?>">برگشت</a>
                                </div>

                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\cafetejarat\resources\views/admin/videos/edit.blade.php ENDPATH**/ ?>