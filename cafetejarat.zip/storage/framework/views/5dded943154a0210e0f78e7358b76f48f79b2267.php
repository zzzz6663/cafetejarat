<?php $__env->startComponent('admin.section.content',['title'=>' داشبورد']); ?>
<?php $__env->slot('bread'); ?>
<li class="breadcrumb-item">پنل مدیریت</li>
<?php $__env->endSlot(); ?>
<div class="container-xl">
    <!-- Page title -->
    <div class="page-header d-print-none">
        <div class="row align-items-center">
            <div class="col">
                <h2 class="page-title">
                    ویرایش طرح
                </h2>
            </div>
        </div>
    </div>
</div>
<div class="page-body">
    <div class="container-xl">
        <div class="row row-cards">
            <div class="col-12">
                <div class="card-header">
                    <h4 class="card-title">  دسته بندی جدید</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-12">
                            <?php echo $__env->make('home.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <form action="<?php echo e(route('vcat.update',$vcat->id)); ?>" class="form-control" method="post"  enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                            <div class="mb-3">
                                <label class="form-label">نام</label>
                                <input type="text" name="title" value="<?php echo e(old('title',$vcat->title)); ?>" class="form-control" name="example-text-input" placeholder="نام دسته بندی  ">
                            </div>



                            <div class="mb-3">
                                <label class="form-label">توضیحات <span class="form-label-description"></span></label>
                                <textarea class="form-control" name="content" rows="6" placeholder="Content.."><?php echo e(old('content',$vcat->title)); ?></textarea>
                            </div>
                            <div class="mb-3">
                                <div class="form-label">    تصویر دسته بندی</div>
                                <input style="color: red" type="file" name="image" accept=".png, .jpg, .jpeg" class="form-control">
                                <a href="<?php echo e($vcat->image()); ?>" class="btn btn-primary  " data-lightbox="roadtrip">عکس</a>
                              </div>
                              <div class="mb-3">
                                <button class="btn btn-success">ذخیره</button>
                                <a  class="btn btn-danger" href="<?php echo e(route('vcat.index')); ?>">برگشت</a>
                              </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<?php echo $__env->renderComponent(); ?>
<?php /**PATH G:\laravelProject\cafetejarat\resources\views/admin/vcats/edit.blade.php ENDPATH**/ ?>