<?php $__env->startSection('main_body'); ?>
<div class="content-box">
    <div class="main-title">
        <h3>طرحها</h3>
        <a href="<?php echo e(route('login')); ?>"></a>
    </div>

    <div class="box-content">

        <a class="linky" href="<?php echo e(route('agent.panel')); ?>">
            بازگشت
            <img style="width: 20px" src="/home/images/back.png" alt="">
        </a>
        <div class="profile-top">
            <div class="img">
                <img src="<?php echo e($user->avatar()); ?>" alt="">
            </div>
            <div class="lefts">
                <h4>
                    <?php echo e($user->name); ?>

                    <?php echo e($user->family); ?>

                </h4>
            </div>
        </div>

        <div class="profile-tab">
            <div class="tab-nav ">
                <ul>
                    <li style="width: 33%" class="active"><span> پیش رو</span></li>
                    <li style="width: 33%" ><span>  در جریان </span></li>
                    <li style="width: 33%" ><span>  گذشته</span></li>
                </ul>
            </div>
            <div class="tab-container">
                <ul>
                    <li class="active">
                        <div>

                            <div class="row">

                                <?php $__currentLoopData = $future_reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $future_report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-12" style="margin-bottom:20px">
                                    <div>
                                        <div class="single-design">

                                            <h4>          <?php echo e($future_report->title); ?></h4>
                                            <?php if($future_report->content): ?>
                                            <p>
                                                <?php echo e($future_report->content); ?>

                                            </p>
                                            <?php endif; ?>
                                            <ul class="daty_i">
                                                <?php if($future_report->start): ?>
                                                <li>
                                                   <span class="title ">
                                                   : تاریخ شروع
                                                   </span>
                                                   <span class="content green">
                                                    <?php echo e(\Morilog\Jalali\Jalalian::forge($future_report->start)->format('Y-m-d')); ?>

                                                   </span>
                                                </li>
                                                <?php endif; ?>
                                                <?php if($future_report->end): ?>
                                                <li>
                                                    <span class="title ">
                                                        :تاریخ پایان
                                                       </span>
                                                       <span class="content red">
                                                        <?php echo e(\Morilog\Jalali\Jalalian::forge($future_report->end)->format('Y-m-d')); ?>

                                                       </span>
                                                </li>
                                                <?php endif; ?>
                                            </ul>
                                            <?php if($future_report->content): ?>
                                            <div class="messages">
                                                <video   class="js-player3" playsinline  data-poster="<?php echo e($future_report->cover()); ?>">
                                                    <source src="<?php echo e($future_report->video()); ?>" type="video/mp4" />
                                                </video>
                                            </div>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </li>
                    <li >
                        <div>

                            <div class="row">

                                <?php $__currentLoopData = $current_reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current_report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-12" style="margin-bottom:20px">
                                    <div>
                                        <div class="single-design">

                                            <h4>          <?php echo e($current_report->title); ?></h4>
                                            <?php if($current_report->content): ?>
                                            <p>
                                                <?php echo e($current_report->content); ?>

                                            </p>
                                            <?php endif; ?>
                                            <ul class="daty_i">
                                                <?php if($current_report->start): ?>
                                                <li>
                                                   <span class="title ">
                                                   : تاریخ شروع
                                                   </span>
                                                   <span class="content green">
                                                    <?php echo e(\Morilog\Jalali\Jalalian::forge($current_report->start)->format('Y-m-d')); ?>

                                                   </span>
                                                </li>
                                                <?php endif; ?>
                                                <?php if($current_report->end): ?>
                                                <li>
                                                    <span class="title ">
                                                        :تاریخ پایان
                                                       </span>
                                                       <span class="content red">
                                                        <?php echo e(\Morilog\Jalali\Jalalian::forge($current_report->end)->format('Y-m-d')); ?>

                                                       </span>
                                                </li>
                                                <?php endif; ?>
                                            </ul>
                                            <?php if($current_report->content): ?>
                                            <div class="messages">
                                                <video   class="js-player3" playsinline  data-poster="<?php echo e($current_report->cover()); ?>">
                                                    <source src="<?php echo e($current_report->video()); ?>" type="video/mp4" />
                                                </video>
                                            </div>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </li>

                    <li>
                        <div>

                            <div class="row">

                                <?php $__currentLoopData = $past_reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $past_report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-12" style="margin-bottom:20px">
                                    <div>
                                        <div class="single-design">

                                            <h4>          <?php echo e($past_report->title); ?></h4>
                                            <?php if($past_report->content): ?>
                                            <p>
                                                <?php echo e($past_report->content); ?>

                                            </p>
                                            <?php endif; ?>
                                            <ul class="daty_i">
                                                <?php if($past_report->start): ?>
                                                <li>
                                                   <span class="title ">
                                                   : تاریخ شروع
                                                   </span>
                                                   <span class="content green">
                                                    <?php echo e(\Morilog\Jalali\Jalalian::forge($past_report->start)->format('Y-m-d')); ?>

                                                   </span>
                                                </li>
                                                <?php endif; ?>
                                                <?php if($past_report->end): ?>
                                                <li>
                                                    <span class="title ">
                                                        :تاریخ پایان
                                                       </span>
                                                       <span class="content red">
                                                        <?php echo e(\Morilog\Jalali\Jalalian::forge($past_report->end)->format('Y-m-d')); ?>

                                                       </span>
                                                </li>
                                                <?php endif; ?>
                                            </ul>
                                            <?php if($past_report->content): ?>
                                            <div class="messages">
                                                <video   class="js-player3" playsinline  data-poster="<?php echo e($past_report->cover()); ?>">
                                                    <source src="<?php echo e($past_report->video()); ?>" type="video/mp4" />
                                                </video>
                                            </div>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>


        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\cafetejarat\resources\views/home/agent/reports.blade.php ENDPATH**/ ?>