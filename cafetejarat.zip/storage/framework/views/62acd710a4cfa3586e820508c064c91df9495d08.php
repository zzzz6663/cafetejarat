<?php $__env->startSection('content'); ?>


    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <!-- Small boxes (Stat box) -->
            <?php echo e($slot); ?>




        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.manager', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\naser\Desktop\c\resources\views/admin/section/content.blade.php ENDPATH**/ ?>