<option  value="" >شهر را انتخاب کنید </option>
<?php $__currentLoopData = $ostan->shahrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option  value="<?php echo e($sha->id); ?>"><?php echo e($sha->name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH G:\laravelProject\cafetejarat\resources\views/home/agent/get_shahr.blade.php ENDPATH**/ ?>