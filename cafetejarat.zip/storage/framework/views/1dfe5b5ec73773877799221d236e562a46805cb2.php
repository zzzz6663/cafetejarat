<?php $__env->startSection('main_body'); ?>

<div class="content-box">
    <div class="main-title">
        <h3>تکمیل اطلاعات</h3>
    </div>

    <div class="box-content">
        <div class="txt">
            <p>به جمع جهادی ما خوش اومدی!</p>
            <p>ان‌شاءالله با همت شما رفقا، به زودی حال اقتصاد ایران ما خوب می‌شه؛ لطفا اطلاعاتت رو خیلی دقیق و با حوصله تکمیل کن که بتونیم با شناخت بهتر نتیجه بیشتری بگیریم.</p>
        </div>

        <div class="process">
            <ul>
                <li class="step step1">
                    <div class="name active"><span>مرحله اول</span></div>
                </li>
                <li class="step step2">
                    <div class="name"><span>مرحله دوم</span></div>
                </li>
                <li class="step step3">
                    <div class="name"><span>مرحله سوم</span></div>
                </li>
            </ul>
        </div>


        <div class="info-form">
        <?php echo $__env->make('home.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form action="<?php echo e(route('agent.info1')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('post'); ?>
                <div class="row">
                    <div class="col-lg-6">
                        <div>
                            <div class="input-container gray">
                                <label for="">نام</label>
                                <input type="text"  value="<?php echo e(old('name')); ?>" name="name" placeholder="نام  ">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div>
                            <div class="input-container gray">
                                <label for="">نام خانوادگی</label>
                                <input type="text"  value="<?php echo e(old('family')); ?>" name="family" placeholder="نام خانوادگی">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div>
                            <div class="input-container gray">
                                <label for="">کد ملی</label>
                                <input type="tell"  value="<?php echo e(old('code')); ?>" name="code" placeholder="کد ملی">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div>
                            <div class="input-container gray">
                                <label for="">تلفن</label>
                                <input type="tell"  readonly value="<?php echo e(auth()->user()->mobile); ?>" name="tell" placeholder="تلفن به همراه کد">
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-6">
                        <div>
                            <div class="input-container gray">
                                <label for="">استان</label>
                                <select  value="<?php echo e(old('ostan_id')); ?>" name="ostan_id" id="ostan">
                                    <option value="">استان محل فعالیت</option>
                                    <?php $__currentLoopData = \App\Models\Ostan::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ostan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e(old('ostan_id')==$ostan->id?'selected':''); ?> value="<?php echo e($ostan->id); ?>"><?php echo e($ostan->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div>
                            <div class="input-container gray">
                                <label for="">شهرستان</label>
                                <select class="form-control"  value="<?php echo e(old('shahr_id')); ?>" name="shahr_id" id="shahr">
                                    <option value="">شهرستان </option>
                                    <?php if(old('shahr_id')): ?>
                                    <?php ($sh=\App\Models\Shahr::find(old('shahr_id'))); ?>

                                        <option selected value="<?php echo e($sh->id); ?>"><?php echo e($sh->name); ?></option>
                                    <?php endif; ?>

                                </select>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div>
                            <div class="input-container gray">
                                <label for="">تحصیلی</label>
                                <select    name="madrak" id="madrak">
                                    <option value="">مدرک تحصیلی</option>
                                    <option <?php echo e(old('madrak')=='base'?'selected':''); ?> value="base">پایه </option>
                                    <option <?php echo e(old('madrak')=='diploma'?'selected':''); ?> value="diploma">دیپلم</option>
                                    <option <?php echo e(old('madrak')=='associate'?'selected':''); ?> value="associate">فوق دیپلم
                                    </option>
                                    <option <?php echo e(old('madrak')=='masters'?'selected':''); ?> value="masters">کارشناسی</option>
                                    <option <?php echo e(old('madrak')=='upmasters'?'selected':''); ?> value="upmasters">کارشناسی ارشد
                                    </option>
                                    <option <?php echo e(old('madrak')=='phd'?'selected':''); ?> value="phd">دکتری</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div>
                            <div class="input-container gray">
                                <label for="">اشتغال</label>
                                <select    name="job" id="">
                                    <option value="">وضعیت اشتغال</option>
                                    <option <?php echo e(old('job')=='employee'?'selected':''); ?> value="employee">کارمند</option>
                                    <option <?php echo e(old('job')=='craftsman'?'selected':''); ?> value="craftsman">صنعتگر</option>
                                    <option <?php echo e(old('job')=='farmer'?'selected':''); ?> value="farmer">کشاورز</option>
                                    <option <?php echo e(old('job')=='service'?'selected':''); ?> value="service">سرویس</option>
                                    <option <?php echo e(old('job')=='unemployed'?'selected':''); ?> value="unemployed">بدون کار
                                    </option>
                                    <option <?php echo e(old('job')=='student'?'selected':''); ?> value="student">دانشجو</option>
                                    <option <?php echo e(old('job')=='talabe'?'selected':''); ?> value="talabe">طلبه</option>
                                    <option <?php echo e(old('job')=='entrepreneur'?'selected':''); ?> value="entrepreneur">کارآفرین</option>
                                    <option <?php echo e(old('job')=='other'?'selected':''); ?> value="other">سایر موارد</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div>
                            <div class="input-container gray">
                                <label for="">واتس آپ</label>
                                <input type="tell"  value="<?php echo e(old('wmobile')); ?>" name="wmobile" placeholder="شماره واتس اپ">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div>
                            <div class="input-container gray">
                                <label for="">اینستاگرام</label>
                                <input type="text"  value="<?php echo e(old('insta')); ?>" name="insta" placeholder="نشانی اینستاگرام">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div>
                            <div class="input-container gray">
                                <label for="">تلگرام</label>
                                <input type="text"  value="<?php echo e(old('telegram')); ?>" name="telegram" placeholder="تلگرام">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div>
                            <div class="input-container gray">
                                <label for="">معرف</label>
                                <input type="tell"    value="<?php echo e(old('introduced')); ?>" name="introduced" placeholder="تلفن معرف">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div>
                            <div class="button-container">
                                <button>مرحله بعدی</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('masters.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravelProject\cafetejarat\resources\views/home/agent/info1.blade.php ENDPATH**/ ?>